# Mawqifi+ Website V1

## Structure
- `index.html` — public one-page site
- `projects.html` — separate Projects page, intentionally hidden from public navigation
- `style.css` — responsive layout + cinematic/3D effects
- `script.js` — scroll reveal, parallax, tilt, active nav, mobile menu
- `assets/` — current approved Mawqifi+ imagery

## Run locally
Open `index.html` directly, or use VS Code Live Server for the best preview.

## Public navigation
Home / About Us / Solutions / Contact / Request a Service

## Projects
The page exists but has no navbar link yet.

## Important
The Request a Service form is currently front-end only. It is ready to connect later to your backend/email provider.
