#!/usr/bin/env python3
"""Builds dist/index.html (one self-contained page) from src/.

Usage:
  python3 build.py                                   # generic build
  python3 build.py --supabase-url https://x.supabase.co --team-code pk-xxxx   # pre-fill settings for your team
"""
import argparse, pathlib
root = pathlib.Path(__file__).resolve().parent
ap = argparse.ArgumentParser(); ap.add_argument('--supabase-url', default=''); ap.add_argument('--team-code', default=''); a = ap.parse_args()
src = root / 'src'
app = ''.join((src / 'app' / f).read_text(encoding='utf-8') for f in ('core_head.js', 'render_part.js', 'core_tail.js'))
body = (src / 'body.html').read_text(encoding='utf-8')
if a.supabase_url:
    body = body.replace('placeholder="https://xxxx.supabase.co">', f'placeholder="https://xxxx.supabase.co" value="{a.supabase_url}">')
if a.team_code:
    body = body.replace('placeholder="نفس الكود اللي في setup.sql">', f'placeholder="نفس الكود اللي في setup.sql" value="{a.team_code}">')
html = ((src / 'head.html').read_text(encoding='utf-8') + '<style>\n' + (src / 'ui.css').read_text(encoding='utf-8') + '\n</style>\n</head>\n<body>\n'
        + body + '\n<script>\n' + (src / 'engine.js').read_text(encoding='utf-8') + '\n</script>\n<script>\n' + app + '\n</script>\n</body>\n</html>')
out = root / 'dist' / 'index.html'; out.parent.mkdir(exist_ok=True); out.write_text(html, encoding='utf-8')
print('built', out, len(html.encode('utf-8')), 'bytes')
