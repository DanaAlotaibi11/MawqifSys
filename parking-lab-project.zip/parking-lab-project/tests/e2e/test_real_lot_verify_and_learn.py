import pathlib
HERE=pathlib.Path(__file__).resolve().parent
PAGE=(HERE.parent.parent/"dist"/"index.html").as_uri()
from playwright.sync_api import sync_playwright
import math, random
mock=(HERE/'mock-claude-db.js').read_text()
lat0,lon0=24.7136,46.6753; k=math.cos(math.radians(lat0))*111320
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844}, permissions=['geolocation'], geolocation={'latitude':lat0,'longitude':lon0,'accuracy':6})
    pg=ctx.new_page(); errs=[]; pg.add_init_script(mock); pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto(PAGE); pg.wait_for_timeout(1200)
    def setg(e,n,j=0.3,acc=6): ctx.set_geolocation({'latitude':lat0+(n+random.gauss(0,j)+0.6)/110540,'longitude':lon0+(e+random.gauss(0,j)+0.9)/k,'accuracy':acc})
    # --- add row lot quickly via manual coords
    pg.click('#addLotBtn'); pg.fill('#wName','اختبار'); pg.fill('#wPer','10')
    pg.evaluate("()=>document.querySelector('#wizard details').open=true")
    pg.fill('#wM1', f'{lat0}, {lon0}'); pg.fill('#wM2', f'{lat0}, {lon0+22.5/k}'); pg.click('#wManual'); pg.click('[data-side=right]'); pg.click('#wAdd'); pg.wait_for_timeout(1500)
    print('1 lot', pg.inner_text('#lotSel'), pg.is_visible('#realPanel'))
    # --- tap a spot -> ask card -> answer
    pg.dispatch_event('#map g.spot[data-id="A-03"]','click'); pg.wait_for_timeout(300)
    print('2 ask', pg.inner_text('#review').replace('\n',' | ')[:160])
    pg.click('#qOcc'); pg.wait_for_timeout(400)
    print('3 after', pg.inner_text('#review').replace('\n',' | ')[:260])
    fill=pg.evaluate("document.querySelector('#map g.spot[data-id=\"A-03\"] rect.base').getAttribute('fill')"); print('   A-03 fill', fill)
    # ask again same spot: prediction should be occ now; answer wrong -> free
    pg.dispatch_event('#map g.spot[data-id="A-03"]','click'); pg.wait_for_timeout(300)
    print('4 ask2', pg.inner_text('#review').replace('\n',' | ')[:120])
    pg.click('#qNo'); pg.wait_for_timeout(400)
    print('5 wrong', pg.inner_text('#review').replace('\n',' | ')[:330])
    # --- live: drive, park in A-05, then page hidden (phone locked) -> park via ended
    pg.evaluate("""()=>{window.__walk=false; let t=0; setInterval(()=>{t+=1/60; const z=9.8+(window.__walk?3*Math.sin(2*Math.PI*1.8*t):(window.__drive?0.4*Math.random():0.02*Math.random())); window.dispatchEvent(new DeviceMotionEvent('devicemotion',{accelerationIncludingGravity:{x:0,y:0,z}}));},16);}""")
    pg.click('#liveBtn'); pg.evaluate("window.__drive=true"); ay=-6; tx=4*2.5
    for i in range(14): setg(-15+i*(tx+15)/13, ay); pg.wait_for_timeout(1000)
    for i in range(5): setg(tx, ay+(i+1)*(0-ay)/5); pg.wait_for_timeout(1000)
    pg.evaluate("window.__drive=false")
    for i in range(6): setg(tx,0); pg.wait_for_timeout(1000)
    print('6 stages', pg.inner_text('#liveBox').replace('\n',' ')[:140])
    pg.evaluate("Object.defineProperty(document,'hidden',{configurable:true,get:()=>true}); document.dispatchEvent(new Event('visibilitychange'))")
    pg.wait_for_timeout(600)
    pg.evaluate("Object.defineProperty(document,'hidden',{configurable:true,get:()=>false})")
    print('7 review after lock', pg.inner_text('#review').replace('\n',' | ')[:200])
    pg.click('#aWrong'); pg.wait_for_timeout(200); pg.dispatch_event('#map g.spot[data-id="A-05"]','click'); pg.wait_for_timeout(500)
    print('8 explain', pg.inner_text('#review').replace('\n',' | ')[:330])
    # --- walk slowly near a spot -> auto ask
    pg.evaluate("window.__walk=true")
    for i in range(8): setg(16.25+random.uniform(-0.3,0.3), 1.0); pg.wait_for_timeout(1000)
    pg.evaluate("window.__walk=false")
    for i in range(6): setg(16.25, 1.0, j=0.2); pg.wait_for_timeout(1000)
    print('9 nearby ask', pg.inner_text('#review').replace('\n',' | ')[:140])
    print('10 log', pg.inner_text('#logBox').replace('\n',' | ')[:400])
    print('11 metrics', pg.inner_text('#metrics').replace('\n',' ')[:200])
    pg.screenshot(path='t13.png', full_page=True)
    # --- reload: rebuild must reproduce status & log
    n_log=pg.evaluate("document.querySelectorAll('.logrow').length")
    pg.reload(); pg.wait_for_timeout(2500)
    print('12 after reload log rows', pg.evaluate("document.querySelectorAll('.logrow').length"), 'was', n_log)
    print('errs', errs); b.close()
