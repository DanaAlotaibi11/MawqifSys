(function(){
  const docs = {}; const subs = [];
  const deepFreeze = o => { Object.freeze(o); Object.values(o).forEach(v => { if (v && typeof v === 'object' && !Object.isFrozen(v)) deepFreeze(v); }); return o; };
  const snapDoc = (p) => ({ id: p.split('/').pop(), exists: !!docs[p], data: () => docs[p], metadata: { fromCache: false, hasPendingWrites: false } });
  const notify = () => subs.forEach(s => setTimeout(s, 5));
  function coll(path){ const q = { path, limit(){ return q; }, where(){ return q; }, orderBy(){ return q; },
      async get(){ return mk(); },
      onSnapshot(next){ const f = () => next(mk()); subs.push(f); setTimeout(f, 10); return () => { const i = subs.indexOf(f); if (i >= 0) subs.splice(i, 1); }; } };
    function mk(){ const ds = Object.keys(docs).filter(p => p.startsWith(path + '/') && p.split('/').length === path.split('/').length + 1).map(snapDoc); return { docs: ds, size: ds.length, empty: !ds.length, docChanges: () => [], metadata: { fromCache: false } }; }
    return q; }
  function doc(path){ return { path, id: path.split('/').pop(), async get(){ return snapDoc(path); },
      async set(o){ if (JSON.stringify(o).length > 262144) throw { code: 'invalid_argument', message: 'too big' }; docs[path] = deepFreeze(JSON.parse(JSON.stringify(o))); notify(); },
      onSnapshot(next){ const f = () => next(snapDoc(path)); subs.push(f); setTimeout(f, 10); return () => {}; } }; }
  const db = Object.freeze({ doc, collection: coll });
  window.__mock = { docs, write(path, o){ docs[path] = deepFreeze(o); notify(); } };
  window.claude = { use: async (n) => n === 'db' ? db : null };
})();
