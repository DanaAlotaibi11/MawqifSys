import pathlib
HERE=pathlib.Path(__file__).resolve().parent
PAGE=(HERE.parent.parent/"dist"/"index.html").as_uri()
from playwright.sync_api import sync_playwright
import math, random
mock=(HERE/'mock-claude-db.js').read_text()
lat0,lon0=24.7136,46.6753; k=math.cos(math.radians(lat0))*111320
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844}, has_touch=False)
    ctx.add_init_script(mock)
    ctx.add_init_script("""(()=>{ let last={latitude:24.7136,longitude:46.6753,accuracy:6}; const ws=new Map(); let id=0;
      const pos=()=>({coords:{...last,speed:null,heading:null},timestamp:Date.now()});
      const geo={ watchPosition(ok){ const i=++id; ws.set(i,ok); setTimeout(()=>ok(pos()),30); return i; }, clearWatch(i){ ws.delete(i); }, getCurrentPosition(ok){ setTimeout(()=>ok(pos()),30); } };
      Object.defineProperty(navigator,'geolocation',{get:()=>geo,configurable:true});
      window.__setPos=(a,b)=>{ last={latitude:a,longitude:b,accuracy:6}; ws.forEach(f=>f(pos())); }; })()""")
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto(PAGE); pg.wait_for_timeout(1200)
    def setg(e,n,j=0.3): pg.evaluate('([a,b])=>__setPos(a,b)', [lat0+(n+random.gauss(0,j))/110540, lon0+(e+random.gauss(0,j))/k])
    def addlot(name):
        pg.click('#addLotBtn'); pg.fill('#wName',name); pg.fill('#wPer','10')
        pg.evaluate("()=>document.querySelector('#wizard details').open=true")
        pg.fill('#wM1', f'{lat0}, {lon0}'); pg.fill('#wM2', f'{lat0}, {lon0+22.5/k}'); pg.click('#wManual'); pg.click('[data-side=right]'); pg.click('#wAdd'); pg.wait_for_timeout(1500)
    addlot('باركنق 1')
    # map: zoom / fit / drag
    vb=lambda: pg.evaluate("document.getElementById('map').getAttribute('viewBox')")
    v0=vb(); pg.click('#zIn'); v1=vb(); pg.click('#zFit'); v2=vb()
    box=pg.locator('#map').bounding_box(); pg.mouse.move(box['x']+150,box['y']+80); pg.mouse.down(); pg.mouse.move(box['x']+100,box['y']+60, steps=5); pg.mouse.up(); v3=vb()
    print('map  fit:', v0, '| zoomed:', v1, '| back:', v2==v0, '| dragged:', v3!=v0)
    print('boundary drawn:', pg.evaluate("[...document.querySelectorAll('#map text')].some(t=>t.textContent.includes('حدود الرصد'))"))
    # train one event
    pg.evaluate("""()=>{window.__walk=false; let t=0; setInterval(()=>{t+=1/60; const z=9.8+(window.__walk?3*Math.sin(2*Math.PI*1.8*t):0.02*Math.random()); window.dispatchEvent(new DeviceMotionEvent('devicemotion',{accelerationIncludingGravity:{x:0,y:0,z}}));},16);}""")
    setg(-30,-6); pg.click('#liveBtn'); pg.wait_for_timeout(600)
    for i in range(14): setg(-30+i*(35/13), -6); pg.wait_for_timeout(1000)
    for i in range(5): setg(5, -6+(i+1)*1.2); pg.wait_for_timeout(1000)
    for i in range(8): setg(5,0); pg.wait_for_timeout(1000)
    pg.evaluate("window.__walk=true")
    for i in range(8): setg(6+i*1.2,-6); pg.wait_for_timeout(1000)
    pg.click('#aOk'); pg.wait_for_timeout(500); pg.click('#liveBtn'); pg.wait_for_timeout(300)
    st=pg.evaluate("(()=>{const S=__pkState(); return {trained:S.model.trained, w:S.model.w.map(x=>+x.toFixed(3)), eA:S.model.eA.length}})()")
    print('lot1 model:', st)
    # delete
    pg.click('#setBtn'); pg.click('#delBtn'); print('delete note shown:', pg.is_visible('#delNote')); pg.click('#delConfirm'); pg.wait_for_timeout(1500)
    print('after delete: list =', pg.inner_text('#lotSel'), '| empty state:', pg.is_visible('#emptyReal'))
    print('brain saved:', pg.evaluate("(()=>{const k=Object.keys(__mock.docs).filter(p=>p.startsWith('brain/')); return k.map(p=>[p,__mock.docs[p].trained,__mock.docs[p].eA.length])})()"))
    addlot('باركنق 2'); pg.wait_for_timeout(500)
    st2=pg.evaluate("(()=>{const S=__pkState(); return {name:S.name, trained:S.model.trained, w:S.model.w.map(x=>+x.toFixed(3)), eA:S.model.eA.length}})()")
    print('lot2 starts with learned knowledge:', st2['eA']==st['eA'] and st2['w']==st['w'], st2)
    print('errs', errs); b.close()
