import pathlib
HERE=pathlib.Path(__file__).resolve().parent
PAGE=(HERE.parent.parent/"dist"/"index.html").as_uri()
from playwright.sync_api import sync_playwright
import math, random
mock=(HERE/'mock-claude-db.js').read_text()
lat0,lon0=24.7136,46.6753; k=math.cos(math.radians(lat0))*111320
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':844})
    ctx.add_init_script(mock)
    ctx.add_init_script("""(()=>{ let last={latitude:24.7136,longitude:46.6753,accuracy:6}; const ws=new Map(); let id=0;
      const pos=()=>({coords:{...last,speed:null,heading:null},timestamp:Date.now()});
      const geo={ watchPosition(ok){ const i=++id; ws.set(i,ok); setTimeout(()=>ok(pos()),30); return i; }, clearWatch(i){ ws.delete(i); }, getCurrentPosition(ok){ setTimeout(()=>ok(pos()),30); } };
      Object.defineProperty(navigator,'geolocation',{get:()=>geo,configurable:true});
      window.__setPos=(a,b)=>{ last={latitude:a,longitude:b,accuracy:6}; ws.forEach(f=>f(pos())); }; })()""")
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto(PAGE); pg.wait_for_timeout(1200)
    def setg(e,n,j=0.3): pg.evaluate('([a,b])=>__setPos(a,b)', [lat0+(n+random.gauss(0,j))/110540, lon0+(e+random.gauss(0,j))/k])
    pg.click('#addLotBtn'); pg.fill('#wName','اختبار الجيوفنس'); pg.fill('#wPer','10')
    pg.evaluate("()=>document.querySelector('#wizard details').open=true")
    pg.fill('#wM1', f'{lat0}, {lon0}'); pg.fill('#wM2', f'{lat0}, {lon0+22.5/k}'); pg.click('#wManual'); pg.click('[data-side=right]'); pg.click('#wAdd'); pg.wait_for_timeout(1500)
    print('lot:', pg.inner_text('#lotSel'), '| wizard lets me choose count/size freely:', pg.is_visible('#realPanel'))
    pg.evaluate("""()=>{window.__walk=false; let t=0; setInterval(()=>{t+=1/60; const z=9.8+(window.__walk?3*Math.sin(2*Math.PI*1.8*t):0.02*Math.random()); window.dispatchEvent(new DeviceMotionEvent('devicemotion',{accelerationIncludingGravity:{x:0,y:0,z}}));},16);}""")
    toasts=[]
    pg.expose_function('__toastLog', lambda t: toasts.append(t))
    pg.evaluate("()=>{ const el=document.getElementById('toast'); new MutationObserver(()=>{ if(el.textContent) __toastLog(el.textContent); }).observe(el,{childList:true,characterData:true,subtree:true}); }")
    # 1) start far outside, drive and park OUTSIDE the lot (street), walk away -> must NOT prompt
    setg(-80,-30); pg.click('#liveBtn'); pg.wait_for_timeout(800)
    for i in range(12): setg(-140+i*5,-30); pg.wait_for_timeout(1000)
    for i in range(8): setg(-80,-30); pg.wait_for_timeout(1000)
    pg.evaluate("window.__walk=true")
    for i in range(8): setg(-80+i*1.2,-31); pg.wait_for_timeout(1000)
    print('1 outside park prompted?', 'رُصد وقوف' in pg.inner_text('#review'), '| geofence:', [l for l in pg.inner_text('#liveBox').split('\n') if 'داخل' in l or 'خارج' in l][:1])
    # 2) drive into the lot, park in A-03 (center e=5,n=0), walk -> prompt
    pg.evaluate("window.__walk=false")
    for i in range(16): setg(-40+i*(45/15), -6); pg.wait_for_timeout(1000)
    for i in range(5): setg(5, -6+(i+1)*1.2); pg.wait_for_timeout(1000)
    for i in range(8): setg(5,0); pg.wait_for_timeout(1000)
    pg.evaluate("window.__walk=true")
    for i in range(8): setg(6+i*1.2,-6); pg.wait_for_timeout(1000)
    rv=pg.inner_text('#review'); print('2 inside park prompted:', 'رُصد وقوف' in rv, rv.split('\n')[3:6])
    pg.click('#aWrong'); pg.wait_for_timeout(200); pg.dispatch_event('#map g.spot[data-id="A-03"]','click'); pg.wait_for_timeout(500)
    # 3) walk out of the lot -> walking exit toast
    for i in range(30): setg(16+i*1.5,-6-i*0.8); pg.wait_for_timeout(1000)
    print('3 toasts:', [t for t in toasts if 'الباركنق' in t][-3:])
    # 4) come back walking, then drive out WITHOUT a clean stop pattern (jump into fast driving) -> exit question
    for i in range(20): setg(60-i*2.5,-25+i*1.0); pg.wait_for_timeout(1000)
    pg.evaluate("window.__walk=false")
    for i in range(12): setg(10+i*6,-6); pg.wait_for_timeout(1000)
    print('4 review:', pg.inner_text('#review').replace('\n',' | ')[:160])
    print('toasts:', toasts[-4:])
    print('errs', errs); b.close()
