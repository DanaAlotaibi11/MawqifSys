import pathlib
HERE=pathlib.Path(__file__).resolve().parent
PAGE=(HERE.parent.parent/"dist"/"index.html").as_uri()
from playwright.sync_api import sync_playwright
import math, random, time
mock=(HERE/'mock-claude-db.js').read_text()
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':1300,'height':1000}, permissions=['geolocation'], geolocation={'latitude':24.7136,'longitude':46.6753})
    pg=ctx.new_page(); errs=[]; pg.add_init_script(mock)
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto(PAGE); pg.wait_for_timeout(1200)
    vis=lambda s: pg.is_visible(s)
    print('empty', vis('#emptyReal'), 'main', vis('#mainArea'), 'loading', vis('#loading'), 'sel', pg.inner_text('#lotSel'))
    pg.screenshot(path='t9a.png')
    pg.click('#addLotBtn'); pg.wait_for_timeout(200); print('wizard', vis('#wizard'))
    lat0,lon0=24.7136,46.6753; k=math.cos(math.radians(lat0))*111320
    def setg(e,n,j=0.3):
        ctx.set_geolocation({'latitude':lat0+(n+random.gauss(0,j))/110540,'longitude':lon0+(e+random.gauss(0,j))/k,'accuracy':5})
    pg.fill('#wName','باركنق الكلية'); pg.fill('#wPer','10'); pg.fill('#wRows','2')
    pg.click('#wFp1')
    for i in range(27): setg(0,0); pg.wait_for_timeout(1000)
    print('fp1', pg.inner_text('#wFp1s'))
    pg.click('#wFp2')
    for i in range(27): setg(22.5,0); pg.wait_for_timeout(1000)
    print('fp2', pg.inner_text('#wFp2s'))
    pg.click('[data-side=right]'); pg.wait_for_timeout(200)
    print('out', pg.inner_text('#wOut'), 'addEnabled', pg.is_enabled('#wAdd'))
    pg.click('#wAdd'); pg.wait_for_timeout(1500)
    print('after add main', vis('#mainArea'), 'realPanel', vis('#realPanel'), 'sim', vis('#simPanel'), 'sel', pg.inner_text('#lotSel'))
    print('fps', pg.evaluate("document.querySelectorAll('#map circle').length"))
    pg.screenshot(path='t9b.png', full_page=True)
    pg.click('[data-mode=sim]'); pg.wait_for_timeout(1500)
    print('sim banner', vis('#simBanner'), 'simPanel', vis('#simPanel'), 'sel', pg.inner_text('#lotSel'))
    pg.click('[data-mode=real]'); pg.wait_for_timeout(1500)
    print('back real', pg.inner_text('#lotSel'), vis('#realPanel'))
    # single spot wizard
    pg.click('#addLotBtn'); pg.click('[data-wt=one]'); pg.fill('#wName','موقف البيت')
    pg.click('#wFp1')
    for i in range(27): setg(100,50); pg.wait_for_timeout(1000)
    pg.click('#wDir'); pg.wait_for_timeout(3000)
    print('dir', pg.inner_text('#wDirs'), pg.inner_text('#wOut'))
    pg.click('#wAdd'); pg.wait_for_timeout(1500)
    print('single', pg.inner_text('#lotSel'), vis('#mainArea'))
    print('errs', errs); b.close()
