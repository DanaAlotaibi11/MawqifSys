import pathlib
HERE=pathlib.Path(__file__).resolve().parent
PAGE=(HERE.parent.parent/"dist"/"index.html").as_uri()
from playwright.sync_api import sync_playwright
import json, math, random, urllib.parse, datetime, itertools
DB={}; clock=itertools.count(1)
def now(): return '2026-09-30T10:00:%09.6f+00:00' % (next(clock)/1000)
def like(pat, s):
    import fnmatch; return fnmatch.fnmatchcase(s, pat)
def handle(route, req):
    h=req.headers
    if h.get('x-team-key')!='TEAM1': return route.fulfill(status=401, body='{"message":"denied"}')
    if req.method=='OPTIONS': return route.fulfill(status=200)
    if req.method=='POST':
        for row in json.loads(req.post_data):
            DB[row['path']]={'data':row['data'],'updated_at':now()}
        return route.fulfill(status=201, body='')
    q=urllib.parse.urlparse(req.url).query; params=urllib.parse.parse_qsl(q)
    rows=[{'path':p, **v} for p,v in DB.items()]
    limit=1000; order=None
    for k,v in params:
        if k=='path':
            op,val=v.split('.',1)
            if op=='like': rows=[r for r in rows if like(val,r['path'])]
            elif op=='eq': rows=[r for r in rows if r['path']==val]
            elif op=='not': _,val2=val.split('.',1); rows=[r for r in rows if not like(val2,r['path'])]
        elif k=='updated_at': op,val=v.split('.',1); rows=[r for r in rows if r['updated_at']>val]
        elif k=='limit': limit=int(v)
        elif k=='order': order=v
    if order: rows.sort(key=lambda r:r['updated_at'])
    rows=rows[:limit]
    return route.fulfill(status=200, content_type='application/json', body=json.dumps(rows))
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':1300,'height':1000}, permissions=['geolocation'], geolocation={'latitude':24.7136,'longitude':46.6753})
    ctx.route('https://mock.supabase.co/**', handle)
    ctx.route('https://server.arcgisonline.com/**', lambda r,q: r.fulfill(status=200, content_type='image/png', body=b''))
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto(PAGE); pg.wait_for_timeout(1000)
    print('note', pg.inner_text('#modeNote'))
    pg.click('#setBtn'); pg.fill('#sUrl','https://mock.supabase.co'); pg.fill('#sKey','x'*40); pg.fill('#sTeam','WRONG'); pg.click('#sSave'); pg.wait_for_timeout(800); print('wrong', pg.inner_text('#sMsg'))
    pg.fill('#sTeam','TEAM1'); pg.click('#sSave'); pg.wait_for_timeout(2500)
    print('after connect save', pg.inner_text('#saveText'), '| note hidden', pg.is_hidden('#modeNote'))
    lat0,lon0=24.7136,46.6753; k=math.cos(math.radians(lat0))*111320
    def setg(e,n,j=0.3): ctx.set_geolocation({'latitude':lat0+(n+random.gauss(0,j))/110540,'longitude':lon0+(e+random.gauss(0,j))/k,'accuracy':5})
    pg.click('#addLotBtn'); pg.fill('#wName','باركنق'); pg.fill('#wPer','10')
    pg.click('#wFp1'); [ (setg(0,0), pg.wait_for_timeout(1000)) for i in range(27)]
    pg.click('#wFp2'); [ (setg(22.5,0), pg.wait_for_timeout(1000)) for i in range(27)]
    pg.click('[data-side=left]'); pg.click('#wAdd'); pg.wait_for_timeout(6000)
    print('lot', pg.inner_text('#lotSel'), 'main', pg.is_visible('#mainArea'), 'tiles', pg.evaluate("document.querySelectorAll('#map image').length"), 'fps', pg.evaluate("document.querySelectorAll('#map circle').length"))
    pg.dispatch_event('#map g.spot[data-id="A-03"]','click'); pg.wait_for_timeout(300); pg.click('#qFree'); pg.wait_for_timeout(2000)
    print('db keys', list(DB.keys()))
    # second device: new context same DB
    ctx2=b.new_context(viewport={'width':390,'height':844}); ctx2.route('https://mock.supabase.co/**', handle); ctx2.route('https://server.arcgisonline.com/**', lambda r,q: r.fulfill(status=200, content_type='image/png', body=b''))
    import base64
    cfg=base64.b64encode(json.dumps({'url':'https://mock.supabase.co','key':'x'*40,'team':'TEAM1'}).encode()).decode()
    pg2=ctx2.new_page(); pg2.on('pageerror',lambda e: errs.append(str(e)))
    pg2.goto(PAGE+'#supa='+urllib.parse.quote(cfg)); pg2.wait_for_timeout(5000)
    fill=pg2.evaluate("document.querySelector('#map g.spot[data-id=\"A-03\"] rect.base')?.getAttribute('fill')")
    print('device2 lot', pg2.inner_text('#lotSel'), 'A-03', fill, 'save', pg2.inner_text('#saveText'))
    pg.screenshot(path='t11.png')
    print('errs', errs); b.close()
