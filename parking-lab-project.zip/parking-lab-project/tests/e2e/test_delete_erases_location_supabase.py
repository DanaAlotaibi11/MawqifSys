import pathlib
HERE=pathlib.Path(__file__).resolve().parent
PAGE=(HERE.parent.parent/"dist"/"index.html").as_uri()
from playwright.sync_api import sync_playwright
import json, math, urllib.parse, itertools, fnmatch, base64
DB={}; clock=itertools.count(1)
def now(): return '2026-10-02T10:00:%09.6f+00:00' % (next(clock)/1000)
def handle(route, req):
    if req.headers.get('x-team-key')!='TEAM1': return route.fulfill(status=401, body='{}')
    if req.method=='POST':
        for row in json.loads(req.post_data): DB[row['path']]={'data':row['data'],'updated_at':now()}
        return route.fulfill(status=201, body='')
    rows=[{'path':p, **v} for p,v in DB.items()]; limit=1000
    for k,v in urllib.parse.parse_qsl(urllib.parse.urlparse(req.url).query):
        if k=='path':
            op,val=v.split('.',1)
            if op=='like': rows=[r for r in rows if fnmatch.fnmatchcase(r['path'],val)]
            elif op=='eq': rows=[r for r in rows if r['path']==val]
            elif op=='not': rows=[r for r in rows if not fnmatch.fnmatchcase(r['path'],val.split('.',1)[1])]
        elif k=='updated_at': rows=[r for r in rows if r['updated_at']>v.split('.',1)[1]]
        elif k=='limit': limit=int(v)
        elif k=='order': rows.sort(key=lambda r:r['updated_at'])
    return route.fulfill(status=200, content_type='application/json', body=json.dumps(rows[:limit]))
lat0,lon0=24.7136,46.6753; k=math.cos(math.radians(lat0))*111320
cfg=base64.b64encode(json.dumps({'url':'https://mock.supabase.co','key':'x'*40,'team':'TEAM1'}).encode()).decode()
url=PAGE+'#supa='+urllib.parse.quote(cfg)
with sync_playwright() as p:
    b=p.chromium.launch()
    def page():
        ctx=b.new_context(viewport={'width':390,'height':844}); ctx.route('https://mock.supabase.co/**', handle); ctx.route('https://server.arcgisonline.com/**', lambda r,q: r.fulfill(status=200, content_type='image/png', body=b''))
        pg=ctx.new_page(); pg.goto(url); pg.wait_for_timeout(2500); return pg
    pg=page(); errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.click('#addLotBtn'); pg.fill('#wName','بيتي'); pg.fill('#wPer','4')
    pg.evaluate("()=>document.querySelector('#wizard details').open=true")
    pg.fill('#wM1', f'{lat0}, {lon0}'); pg.fill('#wM2', f'{lat0}, {lon0+7.5/k}'); pg.click('#wManual'); pg.click('[data-side=right]'); pg.click('#wAdd'); pg.wait_for_timeout(5000)
    lotpath=[x for x in DB if x.startswith('lots/') and '/chunks/' not in x][0]
    has=lambda s: [x for x in DB if s in json.dumps(DB[x]['data'])]
    print('before: lot', lotpath, '| docs containing my latitude:', len(has('24.7136')))
    pg.click('#setBtn'); pg.click('#delBtn'); pg.click('#delConfirm'); pg.wait_for_timeout(3000)
    print('after delete UI: list =', pg.inner_text('#lotSel'), '| empty:', pg.is_visible('#emptyReal'), '| map hidden:', pg.is_hidden('#mainArea'))
    print('DB lot doc:', DB[lotpath]['data'])
    print('docs still containing my latitude:', has('24.7136'), '| brain:', [x for x in DB if x.startswith('brain/')])
    pg2=page(); print('teammate sees:', pg2.inner_text('#lotSel'), '| empty:', pg2.is_visible('#emptyReal'))
    # legacy: a lot deleted by the old version (flag only) gets scrubbed on load
    DB['lots/lot-old']={'data':{'name':'قديم','real':True,'deleted':True,'cfg':{'A':{'lat':24.7,'lon':46.6}},'createdAt':1},'updated_at':now()}
    pg3=page(); pg3.wait_for_timeout(2500); print('legacy deleted lot scrubbed:', DB['lots/lot-old']['data'].get('cfg') is None, DB['lots/lot-old']['data'].get('name'))
    print('errs', errs); b.close()
