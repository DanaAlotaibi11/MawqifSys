import pathlib
HERE=pathlib.Path(__file__).resolve().parent
PAGE=(HERE.parent.parent/"dist"/"index.html").as_uri()
from playwright.sync_api import sync_playwright
import json
mock=(HERE/'mock-claude-db.js').read_text()
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1300,'height':900}); errs=[]
    pg.add_init_script(mock)
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto(PAGE); pg.wait_for_timeout(1000)
    print('save', pg.inner_text('#saveText')); pg.click('[data-mode=sim]'); pg.wait_for_timeout(1500)
    pg.select_option('#autoN','50'); pg.click('#autoBtn'); pg.wait_for_timeout(6000)
    print('trained', pg.inner_text('#hTrained'), pg.inner_text('#saveText'))
    info=pg.evaluate("()=>{const k=Object.keys(__mock.docs); return {n:k.length, keys:k.slice(0,5)}}")
    print(info)
    # another client adds a labeled session: copy an existing item with new sid & later time
    pg.evaluate("""()=>{const k=Object.keys(__mock.docs).find(p=>p.includes('/chunks/')); const lotPath=k.split('/chunks/')[0];
      const it=JSON.parse(JSON.stringify(__mock.docs[k].items[3])); it.sid='other-1'; it.at=Date.now(); it.lat=Date.now();
      __mock.write(lotPath+'/chunks/otherclient-1',{client:'other',items:[it],updatedAt:Date.now()});}""")
    pg.wait_for_timeout(1500)
    print('after foreign write trained', pg.inner_text('#hTrained'))
    pg.click('#simBtns [data-kind=walker]'); pg.wait_for_timeout(200); pg.click('#aOk'); pg.wait_for_timeout(1500)
    print('after manual', pg.inner_text('#hTrained'), pg.inner_text('#saveText'))
    pg.click('#replayBtn'); pg.wait_for_timeout(1500)
    print(pg.inner_text('#replayOut')[:300].replace('\n',' | '))
    pg.screenshot(path='t4.png')
    print('errs',errs); b.close()
