const PE=require('../src/engine.js');
function run(sim, N=400){
const lot=PE.buildLot({rows:4,perRow:16,W:2.5,L:5.5,aisle:6.5,margin:5});
const world=PE.makeWorld(lot,sim);
let truthOcc=lot.spots.map(()=>Math.random()<0.45);
let belief=truthOcc.map(o=>o?'occ':'free');
const m=PE.freshModel(); const devTruth={}; let devN=0;
let stats=[];
for(let i=0;i<N;i++){
  let r=Math.random(), kind;
  const free=lot.spots.filter(s=>!truthOcc[s.idx]), occ=lot.spots.filter(s=>truthOcc[s.idx]);
  if(r<0.35&&free.length) kind='park'; else if(r<0.42&&free.length) kind='cruise'; else if(r<0.72&&occ.length) kind='depart'; else if(r<0.92) kind='walker'; else kind='dropoff';
  let spot=null, dev=null;
  if(kind==='park'||kind==='cruise'){spot=PE.pick(free); dev='d'+(devN++);}
  if(kind==='depart'){spot=PE.pick(occ); dev=Object.keys(devTruth).find(d=>devTruth[d]===spot.id)||null;}
  const {path,truth}=PE.simulateTruth(lot,kind,{spot});
  const samples=PE.sense(world,path);
  const sess={id:i,samples,deviceId:dev};
  sess.result=PE.analyze(m,lot,sess,belief,m.dev);
  const res=sess.result;
  const tt=truth.type==='cruise'?'park':truth.type;
  const truthId= tt==='none'?'none':truth.spot;
  let o={kind,event:res.event,auto:res.auto,ok: res.event? res.decision===truthId : tt==='none', conf:res.conf};
  stats.push(o);
  // label
  PE.learn(m,lot,sess,{type:tt,spot:truth.spot});
  if(tt==='park'){truthOcc[spot.idx]=true;belief[spot.idx]='occ';devTruth[dev]=spot.id;}
  if(tt==='depart'){truthOcc[spot.idx]=false;belief[spot.idx]='free'; if(dev) delete devTruth[dev];}
}
function summ(a){const ev=a.filter(x=>x.event);const au=ev.filter(x=>x.auto);const walkFP=a.filter(x=>(x.kind==='walker')&&x.event).length;
const miss=a.filter(x=>(x.kind==='park'||x.kind==='cruise'||x.kind==='depart')&&!x.event).length;
return `events ${ev.length} auto ${au.length} autoAcc ${(au.filter(x=>x.ok).length/au.length*100).toFixed(1)} autoRate ${(au.length/ev.length*100).toFixed(0)} topAcc ${(ev.filter(x=>x.ok).length/ev.length*100).toFixed(0)} walkerEvents ${walkFP} missed ${miss} dropEv ${a.filter(x=>x.kind==='dropoff'&&x.event).length}/${a.filter(x=>x.kind==='dropoff').length}`;}
for(let k=0;k<N;k+=100) console.log(k, summ(stats.slice(k,k+100)));
console.log('tau',m.tau.toFixed(3),'sig',JSON.stringify(PE.sigmas(m)),'w',m.w.map(x=>x.toFixed(2)).join(','));
const byKind={};stats.forEach(s=>{byKind[s.kind]=byKind[s.kind]||[];byKind[s.kind].push(s)});
for(const k in byKind){const a=byKind[k];console.log(k,a.length,'ev',a.filter(x=>x.event).length,'ok',a.filter(x=>x.ok).length)}
}
for (const sim of [{biasStrength:2,gpsSigma:2.2},{biasStrength:1,gpsSigma:1.0}]) {console.log('SIM',JSON.stringify(sim)); run(sim);}
