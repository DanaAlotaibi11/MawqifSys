/* ===================== Parking accuracy engine ===================== */
const PE = (function () {
  'use strict';
  const TAU = Math.PI * 2;
  function gauss() { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(TAU * v); }
  function sigmoid(z) { return 1 / (1 + Math.exp(-z)); }
  function erf(x) { const s = Math.sign(x); x = Math.abs(x); const t = 1 / (1 + 0.3275911 * x); const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return s * y; }
  function Phi(x) { return 0.5 * (1 + erf(x / Math.SQRT2)); }
  function angDiff(a, b) { let d = (a - b) % TAU; if (d > Math.PI) d -= TAU; if (d < -Math.PI) d += TAU; return Math.abs(d); }
  function rr(a, b) { return a + Math.random() * (b - a); }
  function ri(a, b) { return Math.floor(rr(a, b + 1)); }
  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function r2(v) { return Math.round(v * 100) / 100; }
  function circMean(angles) { let s = 0, c = 0; for (const a of angles) { s += Math.sin(a); c += Math.cos(a); } return Math.atan2(s, c); }

  /* ---------- Lot geometry ---------- */
  const LETTERS = 'ABCDEFGHIJKLMNOP';
  function buildLot(cfg) {
    const W = cfg.W, L = cfg.L, A = cfg.aisle, M = cfg.margin || 5;
    const width = M * 2 + cfg.perRow * W;
    const spots = [], aisles = [];
    let y = 0;
    for (let r = 0; r < cfg.rows; r++) {
      const dir = r % 2 === 0 ? 1 : -1;
      if (dir === 1) { aisles.push({ x0: 0, x1: width, y0: y, y1: y + A }); y += A; }
      const aisleY = dir === 1 ? y - A / 2 : y + L + A / 2;
      for (let j = 0; j < cfg.perRow; j++) {
        const x0 = M + j * W;
        spots.push({ id: LETTERS[r] + '-' + String(j + 1).padStart(2, '0'), row: r, col: j, dir, x0, x1: x0 + W, y0: y, y1: y + L, cx: x0 + W / 2, cy: y + L / 2, aisleY });
      }
      y += L;
      if (dir === -1 && r === cfg.rows - 1) { aisles.push({ x0: 0, x1: width, y0: y, y1: y + A }); y += A; }
    }
    const height = y;
    // end strips (drivable/walkable) beside the rows
    const drive = aisles.slice();
    drive.push({ x0: 0, x1: M, y0: 0, y1: height }, { x0: width - M, x1: width, y0: 0, y1: height });
    const driveArea = drive.reduce((s, r) => s + (r.x1 - r.x0) * (r.y1 - r.y0), 0);
    const byId = {}; spots.forEach((s, i) => { s.idx = i; byId[s.id] = s; });
    return { cfg, spots, aisles, drive, driveArea, width, height, byId };
  }

  /* ---------- Simulated world (hidden truth, simulation only) ---------- */
  function makeWorld(lot, sim) {
    const S = sim.biasStrength;
    const ca = rr(0, TAU);
    const bumps = [];
    for (let k = 0; k < 4; k++) bumps.push({ x: rr(0, lot.width), y: rr(0, lot.height), ax: gauss() * S * 0.9, ay: gauss() * S * 0.9, s: rr(9, 20) });
    return { c: { x: Math.cos(ca) * S * 0.7, y: Math.sin(ca) * S * 0.7 }, bumps, bld: S * 1.1, H: lot.height, sigma: sim.gpsSigma, rho: 0.8 };
  }
  function trueBias(w, x, y) {
    let bx = w.c.x, by = w.c.y;
    for (const b of w.bumps) { const e = Math.exp(-((x - b.x) ** 2 + (y - b.y) ** 2) / (2 * b.s * b.s)); bx += b.ax * e; by += b.ay * e; }
    by -= w.bld * Math.exp(-(w.H - y) / 12); // building along the top edge pushes fixes away
    return { x: bx, y: by };
  }

  // Build a truth path by moving along polyline legs at given speeds, 1 Hz
  function drivePath(pts, speeds, mode) {
    const out = [];
    let x = pts[0].x, y = pts[0].y;
    for (let k = 1; k < pts.length; k++) {
      const tx = pts[k].x, ty = pts[k].y, hdg = Math.atan2(ty - y, tx - x);
      let guard = 0;
      while (guard++ < 400) {
        const rem = Math.hypot(tx - x, ty - y);
        if (rem < 0.05) break;
        const v = Math.min(speeds(k, rem), rem);
        x += Math.cos(hdg) * v; y += Math.sin(hdg) * v;
        out.push({ x, y, mode, v, hdg });
      }
    }
    return out;
  }
  function still(n, x, y, hdg) { const o = []; for (let i = 0; i < n; i++) o.push({ x, y, mode: 'S', v: 0, hdg }); return o; }

  function aisleEndX(lot, fromLeft) { return fromLeft ? 1.5 : lot.width - 1.5; }

  function simulateTruth(lot, kind, ctx) {
    // ctx: {spot} ; returns {path, truth}
    let path = [], truth;
    if (kind === 'park' || kind === 'cruise') {
      const s = ctx.spot, fromLeft = Math.random() < 0.5, vmax = kind === 'cruise' ? rr(1.4, 2.0) : rr(4, 6.5);
      const start = { x: aisleEndX(lot, fromLeft), y: s.aisleY };
      const turn = { x: s.cx, y: s.aisleY };
      const car = { x: s.cx + gauss() * 0.2, y: s.cy + gauss() * 0.3 };
      path = drivePath([start, turn, car], (k, rem) => k === 1 ? Math.min(vmax, 0.9 + 0.45 * rem) : 1.0, 'D');
      const hdg = path.length ? path[path.length - 1].hdg : 0;
      path = path.concat(still(ri(8, 25), car.x, car.y, hdg));
      const side = Math.random() < 0.5 ? -1 : 1;
      const door = { x: car.x + side * 1.1, y: car.y };
      const out = { x: car.x + side * 1.3, y: s.aisleY };
      const exit = { x: aisleEndX(lot, Math.random() < 0.5), y: s.aisleY + gauss() * 0.8 };
      const wv = rr(1.1, 1.5);
      const walk = drivePath([door, out, exit], () => wv, 'W').slice(0, ri(20, 38));
      path = path.concat(walk);
      truth = { type: 'park', spot: s.id };
    } else if (kind === 'depart') {
      const s = ctx.spot, side = Math.random() < 0.5 ? -1 : 1;
      const car = { x: s.cx + gauss() * 0.2, y: s.cy + gauss() * 0.3 };
      const door = { x: car.x + side * 1.1, y: car.y };
      const inA = { x: car.x + side * 1.3, y: s.aisleY };
      const from = { x: Math.min(lot.width - 1, Math.max(1, inA.x + (Math.random() < 0.5 ? -1 : 1) * rr(15, 35))), y: s.aisleY };
      const wv = rr(1.1, 1.5);
      let walk = drivePath([from, inA, door], () => wv, 'W');
      walk = walk.slice(Math.max(0, walk.length - ri(20, 34)));
      path = walk.concat(still(ri(5, 15), car.x, car.y, s.dir * Math.PI / 2));
      const back = drivePath([car, { x: car.x, y: s.aisleY }], () => 0.8, 'D');
      const away = drivePath([{ x: car.x, y: s.aisleY }, { x: aisleEndX(lot, Math.random() < 0.5), y: s.aisleY }], (k, rem) => Math.min(rr(4, 6), 1 + rem * 0.4), 'D').slice(0, ri(16, 26));
      path = path.concat(back, away);
      truth = { type: 'depart', spot: s.id };
    } else if (kind === 'walker') {
      const n = ri(4, 7), pts = [];
      for (let k = 0; k < n; k++) {
        if (Math.random() < 0.55) { const a = pick(lot.aisles); pts.push({ x: rr(1, lot.width - 1), y: (a.y0 + a.y1) / 2 + gauss() * 1.2 }); }
        else { const s = pick(lot.spots); pts.push({ x: s.x0 + rr(-0.3, 0.3), y: rr(s.y0 + 0.5, s.y1 - 0.5) }); } // squeezing between cars
      }
      const wv = rr(1.1, 1.6);
      let p = [];
      for (let k = 1; k < pts.length; k++) {
        p = p.concat(drivePath([pts[k - 1], pts[k]], () => wv, 'W'));
        if (Math.random() < 0.35 && p.length) { const l = p[p.length - 1]; p = p.concat(still(ri(4, 14), l.x, l.y, l.hdg)); }
      }
      if (Math.random() < 0.2 && p.length) { const l = p[p.length - 1]; p = p.concat(still(ri(25, 45), l.x, l.y, l.hdg)); p = p.concat(drivePath([l, { x: l.x + 8, y: l.y }], () => wv, 'W')); }
      path = p.slice(0, 110);
      truth = { type: 'none', note: 'walker' };
    } else if (kind === 'dropoff') {
      const a = pick(lot.aisles), ay = (a.y0 + a.y1) / 2, fromLeft = Math.random() < 0.5;
      const stopX = rr(lot.width * 0.25, lot.width * 0.75);
      const start = { x: aisleEndX(lot, fromLeft), y: ay }, stop = { x: stopX, y: ay + gauss() * 0.5 };
      path = drivePath([start, stop], (k, rem) => Math.min(rr(4, 6), 0.9 + rem * 0.45), 'D');
      const h = path.length ? path[path.length - 1].hdg : 0;
      path = path.concat(still(ri(3, 7), stop.x, stop.y, h));
      const side = Math.random() < 0.5 ? -1 : 1;
      const wv = rr(1.1, 1.5);
      path = path.concat(drivePath([{ x: stop.x, y: stop.y + side * 1 }, { x: stop.x + rr(-6, 6), y: stop.y + side * 3 }, { x: aisleEndX(lot, Math.random() < 0.5), y: stop.y + side * 3 }], () => wv, 'W').slice(0, ri(18, 30)));
      truth = { type: 'none', note: 'dropoff' };
    }
    return { path, truth };
  }

  // Sensor layer: turns a truth path into what a phone would report
  function sense(world, path) {
    const out = []; let ex = 0, ey = 0; const s = world.sigma, rho = world.rho, k = Math.sqrt(1 - rho * rho);
    ex = gauss() * s; ey = gauss() * s;
    const walkHdgBias = gauss() * 0.14;
    let lastH = 0;
    path.forEach((p, t) => {
      ex = rho * ex + k * s * gauss(); ey = rho * ey + k * s * gauss();
      const b = trueBias(world, p.x, p.y);
      const truthAct = p.mode === 'D' ? 'automotive' : p.mode === 'W' ? 'walking' : 'still';
      let act = truthAct; if (Math.random() < 0.15) act = pick(['automotive', 'walking', 'still', 'unknown'].filter(a => a !== truthAct));
      let cad = p.mode === 'W' ? 1.75 + gauss() * 0.15 : p.mode === 'D' ? Math.max(0, gauss() * 0.12 + (Math.random() < 0.05 ? 0.8 : 0)) : Math.max(0, gauss() * 0.08);
      let hdg = p.mode === 'S' ? lastH : p.hdg + (p.mode === 'W' ? walkHdgBias + gauss() * 0.15 : gauss() * 0.1);
      lastH = p.mode === 'S' ? lastH : hdg;
      const vib = p.mode === 'W' ? 1.8 + gauss() * 0.4 : p.mode === 'D' ? 0.35 + Math.abs(gauss()) * 0.15 : Math.abs(gauss()) * 0.03;
      out.push({ t, gx: r2(p.x + b.x + ex), gy: r2(p.y + b.y + ey), acc: r2(s * 1.6), speed: r2(Math.max(0, p.v + gauss() * 0.3)), cad: r2(Math.max(0, cad)), act, hdg: r2(hdg), vib: r2(Math.max(0, vib)), _m: p.mode, _x: r2(p.x), _y: r2(p.y) });
    });
    return out;
  }

  /* ---------- Model ---------- */
  const W0 = [1.0, -4.0, 1.0, -0.8, 0.0, 1.0]; // speed, steps, osDrive, osWalk, vibration, bias
  function freshModel() {
    return {
      w: W0.slice(), // speed, cadence, osAutomotive, osWalking, bias
      res: [],       // learned GPS offset points {x,y,rx,ry,sid}
      eA: [], eB: [], eF: [], // squared errors (per estimate)
      calib: [],     // {c, ok}
      tau: 0.97,
      dev: {},       // deviceId -> spotId (confirmed parking)
      fp: [],        // spot fingerprints: GPS-as-seen centre of a spot {spot,x,y,rx,ry,w}
      trained: 0,
      P: { minDrive: 8, minDwell: 3, minWalk: 5, parkDwell: 25, h: 9, lambda: 1, pNone: 0.12, stepLen: 0.7, target: 0.98 }
    };
  }
  function feats(s) { return [Math.min(s.speed, 10) / 5, s.cad, s.act === 'automotive' ? 1 : 0, s.act === 'walking' ? 1 : 0, Math.min(s.vib || 0, 4) / 2, 1]; }
  function pDrive(m, s) { const f = feats(s); let z = 0; for (let i = 0; i < f.length; i++) z += (m.w[i] || 0) * f[i]; return sigmoid(z); }
  function sigmaFrom(arr, prior, n0) { let s = 0; for (const e of arr) s += e; return Math.max(0.6, Math.sqrt((n0 * prior * prior + s / 2) / (n0 + arr.length))); }
  function sigmas(m) { return { A: sigmaFrom(m.eA, 2.8, 6), B: sigmaFrom(m.eB, 3.6, 6), F: sigmaFrom(m.eF, 2.6, 6) }; }
  function correction(m, x, y, excludeSid) {
    const h2 = 2 * m.P.h * m.P.h; let sx = 0, sy = 0, sw = 0;
    for (const r of m.res) { if (r.sid === excludeSid) continue; const w = Math.exp(-((x - r.x) ** 2 + (y - r.y) ** 2) / h2); sx += w * r.rx; sy += w * r.ry; sw += w; }
    for (const r of (m.fp || [])) { const w = r.w * Math.exp(-((x - r.x) ** 2 + (y - r.y) ** 2) / h2); sx += w * r.rx; sy += w * r.ry; sw += w; }
    const d = sw + m.P.lambda; return { x: sx / d, y: sy / d, support: sw };
  }

  function classify(m, samples) {
    const pD = samples.map(s => pDrive(m, s));
    let raw = samples.map((s, i) => (s.speed < 0.6 && s.cad < 0.4) ? 'S' : (pD[i] > 0.5 ? 'D' : 'W'));
    // mode filter (window 5)
    const lab = raw.map((_, i) => { const c = { D: 0, S: 0, W: 0 }; for (let k = i - 2; k <= i + 2; k++) if (k >= 0 && k < raw.length) c[raw[k]]++; let best = raw[i]; for (const q of ['D', 'S', 'W']) if (c[q] > c[best]) best = q; return best; });
    // runs, merging tiny ones
    let runs = [];
    lab.forEach((l, i) => { if (runs.length && runs[runs.length - 1].m === l) runs[runs.length - 1].i1 = i; else runs.push({ m: l, i0: i, i1: i }); });
    let changed = true;
    while (changed && runs.length > 1) {
      changed = false;
      for (let k = 0; k < runs.length; k++) {
        const r = runs[k]; if (r.i1 - r.i0 + 1 >= 3) continue;
        const into = k > 0 ? k - 1 : k + 1; runs[into].i0 = Math.min(runs[into].i0, r.i0); runs[into].i1 = Math.max(runs[into].i1, r.i1); runs.splice(k, 1); changed = true;
        // merge equal neighbours
        for (let q = runs.length - 1; q > 0; q--) if (runs[q].m === runs[q - 1].m) { runs[q - 1].i1 = runs[q].i1; runs.splice(q, 1); }
        break;
      }
    }
    // a car that briefly stops (traffic, reversing out) is still driving: D,S(short),D -> D
    for (let k = 1; k + 1 < runs.length; k++) {
      if (runs[k].m === 'S' && len(runs[k]) < 5 && runs[k - 1].m === 'D' && runs[k + 1].m === 'D') { runs[k - 1].i1 = runs[k + 1].i1; runs.splice(k, 2); k--; }
    }
    const labels = new Array(samples.length); runs.forEach(r => { for (let i = r.i0; i <= r.i1; i++) labels[i] = r.m; });
    return { pD, labels, runs };
  }

  function len(r) { return r.i1 - r.i0 + 1; }
  // opts.ended: the recording stopped (phone locked / page closed); opts.atStart: window begins where recording began
  function detect(m, runs, opts) {
    const P = m.P; opts = opts || {};
    // newest first: in a long recording an older event must not hide the latest one
    for (let k = runs.length - 3; k >= 0; k--) {
      const a = runs[k], b = runs[k + 1], c = runs[k + 2];
      if (a.m === 'D' && b.m === 'S' && c.m === 'W' && len(a) >= P.minDrive && len(b) >= P.minDwell && len(c) >= P.minWalk) return { type: 'park', drive: a, dwell: b, walk: c, how: 'walk' };
      if (a.m === 'W' && b.m === 'S' && c.m === 'D' && len(a) >= P.minWalk && len(b) >= 2 && len(c) >= P.minDrive) return { type: 'depart', walk: a, dwell: b, drive: c, how: 'walk' };
    }
    const n = runs.length;
    // drove, stopped, and then either stayed still long enough or the signal ended (person left with the phone locked)
    if (n >= 2) {
      const a = runs[n - 2], b = runs[n - 1];
      if (a.m === 'D' && b.m === 'S' && len(a) >= P.minDrive && (len(b) >= P.parkDwell || (opts.ended && len(b) >= P.minDwell))) return { type: 'park', drive: a, dwell: b, walk: null, how: opts.ended ? 'ended' : 'dwell' };
    }
    // recording began inside a parked car, then it drove away
    if (opts.atStart && n >= 2 && runs[0].m === 'S' && runs[1].m === 'D' && len(runs[0]) >= 2 && len(runs[1]) >= P.minDrive) return { type: 'depart', walk: null, dwell: runs[0], drive: runs[1], how: 'start' };
    return null;
  }

  function rectMass(mx, my, sg, r) { return (Phi((r.x1 - mx) / sg) - Phi((r.x0 - mx) / sg)) * (Phi((r.y1 - my) / sg) - Phi((r.y0 - my) / sg)); }

  // belief: array of 'free'|'occ'|'unk' by spot idx
  function analyze(m, lot, sess, belief, devMap, excludeSid, opts) {
    const smp = sess.samples;
    const { pD, labels, runs } = classify(m, smp);
    const ev = detect(m, runs, opts || { ended: !!sess.ended, atStart: sess.atStart !== false });
    const res = { labels, pD, event: ev ? ev.type : null };
    if (!ev) { res.decision = null; res.auto = true; res.conf = 1; return res; }
    const sg = sigmas(m);
    // A: averaged, corrected fixes during dwell
    let ax = 0, ay = 0, rawx = 0, rawy = 0, n = 0;
    for (let i = ev.dwell.i0; i <= ev.dwell.i1; i++) { const s = smp[i], c = correction(m, s.gx, s.gy, excludeSid); ax += s.gx - c.x; ay += s.gy - c.y; rawx += s.gx; rawy += s.gy; n++; }
    ax /= n; ay /= n; rawx /= n; rawy /= n;
    // B: dead-reckoning from the walk (back-projected for park, forward-projected for depart)
    let bx = 0, by = 0, nb = 0;
    const w = ev.walk, L = m.P.stepLen;
    let hasHdg = !!w; if (w) for (let i = w.i0; i <= w.i1; i++) if (smp[i].hdg === null || smp[i].hdg === undefined) { hasHdg = false; break; }
    if (!hasHdg) { bx = ax; by = ay; nb = 1; }
    else if (ev.type === 'park') {
      let dx = 0, dy = 0;
      for (let i = w.i0; i <= Math.min(w.i1, w.i0 + 24); i++) { const s = smp[i]; dx += s.cad * L * Math.cos(s.hdg); dy += s.cad * L * Math.sin(s.hdg); const c = correction(m, s.gx, s.gy, excludeSid); bx += s.gx - c.x - dx; by += s.gy - c.y - dy; nb++; }
    } else {
      // walk towards the car: position at end = fix_j + remaining displacement from j to end
      const idx = []; for (let i = Math.max(w.i0, w.i1 - 24); i <= w.i1; i++) idx.push(i);
      let rx = 0, ry = 0; const rem = [];
      for (let q = idx.length - 1; q >= 0; q--) { rem[q] = { x: rx, y: ry }; const s = smp[idx[q]]; rx += s.cad * L * Math.cos(s.hdg); ry += s.cad * L * Math.sin(s.hdg); }
      idx.forEach((i, q) => { const s = smp[i], c = correction(m, s.gx, s.gy, excludeSid); bx += s.gx - c.x + rem[q].x; by += s.gy - c.y + rem[q].y; nb++; });
    }
    if (hasHdg) { bx /= nb; by /= nb; }
    const wa = 1 / (sg.A * sg.A), wb = hasHdg ? 1 / (sg.B * sg.B) : 0;
    const fx = (ax * wa + bx * wb) / (wa + wb), fy = (ay * wa + by * wb) / (wa + wb);
    const sigma = hasHdg ? sg.F : Math.max(sg.F, sg.A);
    // vehicle heading when entering the spot (park only)
    let heading = null;
    if (ev.type === 'park') { const hs = []; for (let i = Math.max(ev.drive.i0, ev.drive.i1 - 2); i <= ev.drive.i1; i++) if (smp[i].hdg !== null && smp[i].hdg !== undefined) hs.push(smp[i].hdg); heading = hs.length ? circMean(hs) : null; }
    const dwell = len(ev.dwell);
    const P = m.P, N = lot.spots.length;
    const post = []; let Z = 0;
    const known = ev.type === 'depart' && sess.deviceId && devMap[sess.deviceId] ? devMap[sess.deviceId] : null;
    for (const s of lot.spots) {
      const st = belief[s.idx];
      let occ = ev.type === 'park' ? (st === 'free' ? 1 : st === 'unk' ? 0.6 : 0.03) : (st === 'occ' ? 1 : st === 'unk' ? 0.6 : 0.03);
      let head = 1;
      if (heading !== null) { const d = angDiff(heading, s.dir * Math.PI / 2); head = d < 0.87 ? 1 : d < 1.57 ? 0.3 : 0.03; }
      if (known && known === s.id) occ *= 60;
      const d2 = (fx - s.cx) ** 2 + (fy - s.cy) ** 2;
      const lik = Math.exp(-d2 / (2 * sigma * sigma)) / (TAU * sigma * sigma);
      const v = (1 - P.pNone) / N * occ * head * lik; post.push({ id: s.id, p: v }); Z += v;
    }
    let massDrive = 0; for (const r of lot.drive) massDrive += rectMass(fx, fy, sigma, r);
    let noneF = 1;
    if (heading !== null) noneF *= Math.abs(Math.cos(heading)) > 0.8 ? 1.4 : 0.35;
    if (ev.type === 'park') noneF *= dwell < 8 ? 2.2 : dwell > 15 ? 0.4 : 1;
    const vNone = P.pNone * noneF * (massDrive + 0.01) / lot.driveArea;
    Z += vNone;
    post.forEach(p => p.p /= Z);
    post.push({ id: 'none', p: vNone / Z });
    post.sort((a, b) => b.p - a.p);
    const top = post[0];
    Object.assign(res, { bMissing: !hasHdg, est: { x: fx, y: fy }, estA: { x: ax, y: ay }, estB: { x: bx, y: by }, raw: { x: rawx, y: rawy }, sigma, heading, dwell, post: post.slice(0, 6), decision: top.id, conf: top.p, auto: top.p >= m.tau, known, ev: { type: ev.type, how: ev.how, dwell: [ev.dwell.i0, ev.dwell.i1] }, runs });
    return res;
  }

  /* ---------- Learning from a trainer's label ---------- */
  // label: {type:'park'|'depart'|'none', spot?:id}
  function learn(m, lot, sess, label) {
    const r = sess.result, smp = sess.samples;
    // 1) motion classifier (logistic regression, SGD) using labelled phases
    const ys = [];
    if (r.event && label.type !== 'none' && label.type === r.event) {
      smp.forEach((s, i) => { const l = r.labels[i]; if (l === 'D') ys.push([s, 1]); else if (l === 'W') ys.push([s, 0]); });
    } else if (label.type === 'none') {
      if (r.event === 'park' || r.event === 'depart') smp.forEach((s, i) => { const l = r.labels[i]; if (l === 'D') ys.push([s, 1]); else if (l === 'W') ys.push([s, 0]); }); // e.g. drop-off: the driving part was real
      else smp.forEach((s, i) => { if (r.labels[i] !== 'S') ys.push([s, 0]); });
    }
    for (let ep = 0; ep < 2; ep++) for (const [s, y] of ys) {
      const f = feats(s), p = pDrive(m, s), g = p - y;
      for (let i = 0; i < f.length; i++) m.w[i] -= 0.03 * (g * f[i] + 0.02 * (m.w[i] - W0[i]));
    }
    // 2) position errors, GPS offset map, calibration
    if (r.event && r.decision) {
      const truthId = label.type === 'none' ? 'none' : label.spot;
      m.calib.push({ c: r.conf, ok: r.decision === truthId }); if (m.calib.length > 300) m.calib.shift();
      if (label.type !== 'none' && label.type === r.event && lot.byId[label.spot]) {
        const s = lot.byId[label.spot];
        const e = (p) => (p.x - s.cx) ** 2 + (p.y - s.cy) ** 2;
        m.eA.push(e(r.estA)); if (!r.bMissing) { m.eB.push(e(r.estB)); m.eF.push(e(r.est)); }
        ['eA', 'eB', 'eF'].forEach(k => { if (m[k].length > 200) m[k].shift(); });
        m.res.push({ x: s.cx, y: s.cy, rx: r.raw.x - s.cx, ry: r.raw.y - s.cy, sid: sess.id });
        if (m.res.length > 400) m.res.shift();
      }
      recalibrate(m);
    }
    if (sess.deviceId && label.type === 'park') m.dev[sess.deviceId] = label.spot;
    if (sess.deviceId && label.type === 'depart') delete m.dev[sess.deviceId];
    m.trained++;
  }
  function recalibrate(m) {
    const arr = m.calib.slice().sort((a, b) => b.c - a.c);
    let ok = 0, best = null;
    for (let k = 0; k < arr.length; k++) { ok += arr[k].ok ? 1 : 0; const n = k + 1; if (n >= 15 && ok / (n + 2) >= m.P.target) best = arr[k].c; }
    m.tau = best === null ? 0.97 : Math.min(0.995, Math.max(0.6, best));
  }

  /* ---------- Real-data import helpers ---------- */
  // Real lots: A = aisle-side corner of the first spot in the first row, B = same corner at the row's far end,
  // side = +1 when the rows extend to the left of A->B, -1 to the right.
  function realFrame(cfg) {
    const k = Math.cos(cfg.A.lat * Math.PI / 180) * 111320;
    const be = (cfg.B.lon - cfg.A.lon) * k, bn = (cfg.B.lat - cfg.A.lat) * 110540, d = Math.hypot(be, bn) || 1;
    const u = { e: be / d, n: bn / d }, v = { e: -u.n * cfg.side, n: u.e * cfg.side };
    return { k, u, v, len: d };
  }
  function geoToLocal(cfg, lat, lon) {
    if (cfg.real) {
      const f = realFrame(cfg), de = (lon - cfg.A.lon) * f.k, dn = (lat - cfg.A.lat) * 110540;
      return { x: (cfg.margin || 5) + de * f.u.e + dn * f.u.n, y: cfg.aisle + de * f.v.e + dn * f.v.n };
    }
    const dx = (lon - cfg.lon0) * Math.cos(cfg.lat0 * Math.PI / 180) * 111320, dy = (lat - cfg.lat0) * 110540;
    const a = -cfg.rot * Math.PI / 180;
    return { x: dx * Math.cos(a) - dy * Math.sin(a), y: dx * Math.sin(a) + dy * Math.cos(a) };
  }
  function localToGeo(cfg, x, y) {
    const f = realFrame(cfg), a = x - (cfg.margin || 5), b = y - cfg.aisle;
    const de = a * f.u.e + b * f.v.e, dn = a * f.u.n + b * f.v.n;
    return { lat: cfg.A.lat + dn / 110540, lon: cfg.A.lon + de / f.k };
  }
  function headingToLocal(cfg, deg) {
    const t = (90 - deg) * Math.PI / 180, de = Math.cos(t), dn = Math.sin(t);
    if (cfg.real) { const f = realFrame(cfg); return Math.atan2(de * f.v.e + dn * f.v.n, de * f.u.e + dn * f.u.n); }
    return t - cfg.rot * Math.PI / 180;
  }
  function importSamples(cfg, arr) {
    return arr.map((s, t) => {
      let x = s.x, y = s.y;
      if (x === undefined && s.lat !== undefined) { const p = geoToLocal(cfg, s.lat, s.lon); x = p.x; y = p.y; }
      const act = s.activity === 'stationary' ? 'still' : (s.activity || 'unknown');
      const hdg = s.heading === undefined || s.heading === null || s.heading < 0 ? null : r2(headingToLocal(cfg, s.heading));
      return { t, gx: r2(x), gy: r2(y), acc: s.acc || 5, speed: Math.max(0, s.speed || 0), cad: s.cadence || 0, act, hdg, vib: s.vibration || 0 };
    });
  }

  return { buildLot, makeWorld, trueBias, simulateTruth, sense, freshModel, analyze, learn, sigmas, correction, pDrive, recalibrate, importSamples, realFrame, geoToLocal, localToGeo, headingToLocal, gauss, rr, pick };
})();
if (typeof module !== 'undefined') module.exports = PE;
