/* ---------------- storage (shared db, or this device as fallback) ---------------- */
let lotsLoaded = false, store = null, lotsById = {}, currentLot = null, unsubChunks = null, wantedLot = null;
let chunkDocs = {}, knownKeys = new Set(), myChunk = null, firstChunkLoad = true;
const dirty = new Set(); let flushing = false, flushTimer = null;
const keyOf = it => it.k + ':' + it.sid + ':' + it.at;

function makeLocalStore(){
  const K = 'parking-trainer-v2-local'; let D = null;
  try { D = JSON.parse(localStorage.getItem(K)); } catch (e) {}
  if (!D) D = { meta: null, lots: {}, chunks: {} };
  const w = { meta: [], lots: [], chunks: {} };
  const persist = () => { try { localStorage.setItem(K, JSON.stringify(D)); } catch (e) { toast('مساحة التخزين في هذا الجهاز امتلأت. نزّل نسخة احتياطية.'); } };
  const lotsArr = () => Object.keys(D.lots).map(id => Object.assign({ id }, D.lots[id]));
  const chunksArr = l => Object.keys(D.chunks[l] || {}).map(id => Object.assign({ id }, D.chunks[l][id]));
  return {
    mode: 'local',
    watchMeta(cb){ w.meta.push(cb); setTimeout(() => cb(D.meta), 0); },
    watchLots(cb){ w.lots.push(cb); setTimeout(() => cb(lotsArr()), 0); },
    watchChunks(l, cb){ const f = () => cb(chunksArr(l)); (w.chunks[l] = w.chunks[l] || []).push(f); setTimeout(f, 0); return () => { w.chunks[l] = w.chunks[l].filter(x => x !== f); }; },
    async getChunks(l){ return chunksArr(l); },
    async getBrain(m){ return (D.brain || {})[m] || null; },
    async setBrain(m, b){ D.brain = D.brain || {}; D.brain[m] = clone(b); persist(); },
    async setMeta(m){ D.meta = clone(m); persist(); w.meta.forEach(cb => cb(D.meta)); },
    async setLot(id, o){ D.lots[id] = clone(o); persist(); w.lots.forEach(cb => cb(lotsArr())); },
    async setChunk(l, id, o){ (D.chunks[l] = D.chunks[l] || {})[id] = clone(o); persist(); (w.chunks[l] || []).forEach(f => f()); }
  };
}
function makeSharedStore(db){
  const retry = async fn => { try { return await fn(); } catch (e) { if (e && e.code === 'unavailable') { await sleep(400 + Math.random() * 800); return fn(); } throw e; } };
  const onErr = e => { if (e && e.code === 'revoked') { setSave('offline'); } };
  return {
    mode: 'shared',
    watchMeta(cb){ db.doc('meta/current').onSnapshot(s => cb(s.exists ? s.data() : null, !!(s.metadata && s.metadata.fromCache)), onErr); },
    watchLots(cb){ db.collection('lots').onSnapshot(q => cb(q.docs.map(d => Object.assign({ id: d.id }, d.data()))), onErr); },
    watchChunks(l, cb){ return db.collection('lots/' + l + '/chunks').limit(1000).onSnapshot(q => cb(q.docs.map(d => Object.assign({ id: d.id }, d.data()))), onErr); },
    async getChunks(l){ const q = await retry(() => db.collection('lots/' + l + '/chunks').limit(1000).get()); return q.docs.map(d => Object.assign({ id: d.id }, d.data())); },
    async getBrain(m){ const s = await retry(() => db.doc('brain/' + m).get()); return s.exists ? s.data() : null; },
    setBrain(m, b){ return retry(() => db.doc('brain/' + m).set(b)); },
    setMeta(m){ return retry(() => db.doc('meta/current').set(m)); },
    setLot(id, o){ return retry(() => db.doc('lots/' + id).set(o)); },
    setChunk(l, id, o){ return retry(() => db.doc('lots/' + l + '/chunks/' + id).set(o)); }
  };
}

function makeSupaStore(sc){
  const base = sc.url.replace(/\/+$/, '') + '/rest/v1/pk_docs';
  const H = { apikey: sc.key, 'Content-Type': 'application/json', 'x-team-key': sc.team || '' };
  if (!/^sb_/.test(sc.key)) H.Authorization = 'Bearer ' + sc.key; // legacy anon JWT; new publishable keys go in apikey only
  const enc = encodeURIComponent;
  async function req(url, opts){
    opts = opts || {}; let r;
    try { r = await fetch(url, Object.assign({}, opts, { headers: Object.assign({}, H, opts.headers || {}) })); }
    catch (e) { const er = new Error('network'); er.code = 'unavailable'; throw er; }
    if (!r.ok) { const txt = await r.text().catch(() => ''); const er = new Error(txt || ('HTTP ' + r.status)); er.status = r.status; er.code = (r.status === 401 || r.status === 403) ? 'not_granted' : r.status === 413 ? 'quota_exceeded' : r.status >= 500 ? 'unavailable' : 'invalid_argument'; throw er; }
    if (r.status === 204 || r.status === 201) return null;
    const txt = await r.text(); return txt ? JSON.parse(txt) : null;
  }
  const upsert = (path, data) => req(base, { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify([{ path, data }]) });
  const pollErr = e => { if (e.code === 'not_granted') showNote('قاعدة البيانات رفضت الاتصال. تأكد من المفتاح وكود الفريق في الإعدادات.'); else setSave('offline'); };
  async function listChunks(l, since){
    let url = `${base}?select=path,data,updated_at&path=like.${enc('lots/' + l + '/chunks/*')}&order=updated_at.asc&limit=200`;
    if (since) url += `&updated_at=gt.${enc(since)}`;
    return req(url);
  }
  return {
    mode: 'shared',
    test: () => req(`${base}?select=path&limit=1`),
    async getBrain(m){ const rows = await req(`${base}?select=data&path=eq.${enc('brain/' + m)}`); return rows && rows[0] ? rows[0].data : null; },
    setBrain: (m, b) => upsert('brain/' + m, b),
    watchLots(cb){
      const run = async () => { try { const rows = await req(`${base}?select=path,data&path=like.${enc('lots/*')}&path=not.like.${enc('*/chunks/*')}&limit=1000`); cb(rows.map(r => Object.assign({ id: r.path.split('/')[1] }, r.data))); } catch (e) { pollErr(e); } };
      run(); setInterval(() => { if (!document.hidden) run(); }, 15000);
    },
    watchChunks(l, cb){
      let alive = true, since = null, first = true, busy = false; const docs = {};
      const run = async () => {
        if (!alive || busy) return; busy = true;
        try {
          let changed = false, rows;
          do { rows = await listChunks(l, since) || []; rows.forEach(r => { docs[r.path.split('/').pop()] = r.data; since = r.updated_at; }); if (rows.length) changed = true; } while (rows.length === 200 && alive);
          if (alive && (first || changed)) { first = false; cb(Object.keys(docs).map(id => Object.assign({ id }, docs[id]))); }
        } catch (e) { pollErr(e); }
        busy = false;
      };
      run(); const tm = setInterval(() => { if (!document.hidden) run(); }, 4000);
      return () => { alive = false; clearInterval(tm); };
    },
    async getChunks(l){ const out = []; let since = null, rows; do { rows = await listChunks(l, since) || []; rows.forEach(r => { out.push(Object.assign({ id: r.path.split('/').pop() }, r.data)); since = r.updated_at; }); } while (rows.length === 200); return out; },
    setLot: (id, o) => upsert('lots/' + id, o),
    setChunk: (l, id, o) => upsert('lots/' + l + '/chunks/' + id, o),
    setChunkUrgent: (l, id, o) => req(base, { method: 'POST', keepalive: true, headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify([{ path: 'lots/' + l + '/chunks/' + id, data: o }]) })
  };
}
function supaCfg(){ try { const c = JSON.parse(localStorage.getItem('pk-supa') || 'null'); return c && c.url && c.key ? c : null; } catch (e) { return null; } }
function readHashCfg(){
  const m = location.hash.match(/supa=([^&]+)/); if (!m) return;
  try { const c = JSON.parse(decodeURIComponent(escape(atob(decodeURIComponent(m[1]))))); if (c.url && c.key) localStorage.setItem('pk-supa', JSON.stringify(c)); } catch (e) {}
  try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
}

function setSave(st){
  const map = {
    loading: ['#868C94', 'جاري التحميل'],
    pending: ['#E6B52E', 'جاري الحفظ'],
    saved: ['#2F9D6A', store && store.mode === 'shared' ? 'محفوظ للفريق' : 'محفوظ في هذا الجهاز فقط'],
    error: ['#C9463D', 'ما انحفظ بعد، بنعيد المحاولة'],
    readonly: ['#868C94', 'عرض فقط'],
    offline: ['#C9463D', 'انقطع الاتصال بقاعدة البيانات']
  };
  const m = map[st] || map.loading; $('saveDot').style.background = m[0]; $('saveText').textContent = m[1];
}
function handleWriteError(e){
  const code = e && e.code;
  if (code === 'invalid_argument' || code === 'not_granted') {
    readOnly = true; setSave('readonly');
    showNote('عندك صلاحية عرض فقط، فالتدريب اللي تسويه ما ينحفظ. اطلب من صاحب الصفحة يعطيك صلاحية مساهم (Contributor).');
    renderAll(); return false;
  }
  if (code === 'quota_exceeded') { setSave('error'); showNote('قاعدة البيانات وصلت حدها الأعلى. نزّل نسخة احتياطية وتواصل مع صاحب الصفحة.'); return false; }
  setSave('error'); return true;
}
function showNote(t){ const n = $('modeNote'); n.hidden = false; n.className = 'small note-warn'; n.textContent = t; }

function appendItem(it){
  knownKeys.add(keyOf(it));
  if (!myChunk || myChunk.lot !== currentLot || myChunk.items.length >= 60 || myChunk.bytes > 170000) {
    myChunk = { id: clientId + '-' + rid(), lot: currentLot, items: [], bytes: 0 };
    chunkDocs[myChunk.id] = myChunk;
  }
  myChunk.items.push(it); myChunk.bytes += JSON.stringify(it).length;
  dirty.add(myChunk); scheduleFlush();
}
function scheduleFlush(delay){ setSave('pending'); clearTimeout(flushTimer); flushTimer = setTimeout(flush, delay !== undefined ? delay : (autoRunning ? 1500 : 250)); }
async function flush(){
  if (readOnly) return;
  if (flushing) { scheduleFlush(600); return; }
  flushing = true;
  try {
    while (dirty.size) {
      const ch = dirty.values().next().value; dirty.delete(ch);
      try { await store.setChunk(ch.lot, ch.id, { client: clientId, items: ch.items.slice(), updatedAt: Date.now() }); }
      catch (e) { dirty.add(ch); if (handleWriteError(e)) scheduleFlush(5000); return; }
    }
    setSave('saved');
  } finally { flushing = false; }
}
document.addEventListener('visibilitychange', () => { if (document.hidden) { finalizeOnHide(); if (dirty.size) flush(); } });
window.addEventListener('pagehide', () => { finalizeOnHide(); });
window.addEventListener('beforeunload', e => { if (dirty.size || flushing) { e.preventDefault(); e.returnValue = ''; } });

async function writeItemsAsChunks(lotId, items){
  let batch = [], bytes = 0;
  const out = async () => { if (!batch.length) return; await store.setChunk(lotId, clientId + '-imp-' + rid(), { client: clientId, items: batch, updatedAt: Date.now() }); batch = []; bytes = 0; };
  for (const it of items) { const sz = JSON.stringify(it).length; if (batch.length >= 60 || bytes + sz > 170000) await out(); batch.push(it); bytes += sz; }
  await out();
}

/* ---------------- occupancy knowledge: last known state, learned rates, learned trust window ---------------- */
function newOcc(real){ return { real, know: [], cnt: {}, g: { o: 5, n: 10 }, tau: 20 }; }
function occBase(O, idx){ const c = O.cnt[idx] || { o: 0, n: 0 }, g = O.g.o / O.g.n; return (c.o + 5 * g) / (c.n + 5); }
function occProb(O, idx, t){
  const k = O.know[idx], base = occBase(O, idx);
  if (!k) { const c = O.cnt[idx] || { n: 0 }; return { p: base, base, last: null, age: null, w: 0, weak: c.n + O.g.n - 10 < 10 }; }
  if (!O.real) return { p: k.st === 'occ' ? 0.99 : 0.01, base, last: k.st, age: 0, w: 1 };
  const age = Math.max(0, (t - k.t) / 60000), w = Math.exp(-age / O.tau), I = k.st === 'occ' ? 1 : 0;
  return { p: base + (I - base) * w, base, last: k.st, age, w };
}
function stOf(p){ return p >= 0.65 ? 'occ' : p <= 0.35 ? 'free' : 'unk'; }
function predOf(pr){ return pr.weak ? 'unk' : stOf(pr.p); }
function beliefAt(O, t){ return lot.spots.map(s => predOf(occProb(O, s.idx, t))); }
function occObserve(O, idx, st){ const c = O.cnt[idx] || (O.cnt[idx] = { o: 0, n: 0 }); c.n++; O.g.n++; if (st === 'occ') { c.o++; O.g.o++; } }
function occSet(O, idx, st, t){ if (st === 'unk') delete O.know[idx]; else O.know[idx] = { st, t }; }
const ST_AR = { occ: 'مشغول', free: 'فاضي', unk: 'مو متأكد' };
function ageAr(min){ if (min < 1) return 'أقل من دقيقة'; if (min < 60) return Math.round(min) + ' دقيقة'; const h = min / 60; return (h < 10 ? h.toFixed(1) : Math.round(h)) + ' ساعة'; }

// A person confirms or corrects the predicted state of one spot
function applyVerify(O, it){
  const s = lot.byId[it.spot]; if (!s) return null;
  const pr = occProb(O, s.idx, it.at), pred = predOf(pr), conf = Math.max(pr.p, 1 - pr.p);
  const truth = it.truth, ok = pred === 'unk' ? null : pred === truth;
  const tauOld = O.tau, baseOld = pr.base;
  if (O.real && pr.last) {
    const bSame = pr.last === 'occ' ? pr.base : 1 - pr.base, pSame = bSame + (1 - bSame) * pr.w;
    const dp = (1 - bSame) * pr.w * (pr.age / O.tau), same = truth === pr.last ? 1 : 0;
    const grad = (same - pSame) / Math.max(0.05, pSame * (1 - pSame)) * dp;
    O.tau = Math.min(240, Math.max(3, O.tau * Math.exp(0.35 * Math.max(-2, Math.min(2, grad)))));
  }
  occObserve(O, s.idx, truth); occSet(O, s.idx, truth, it.at);
  const baseNew = occBase(O, s.idx);
  let why;
  if (pr.last) why = `آخر معلومة عندي عن ${it.spot}: ${ST_AR[pr.last]} قبل ${ageAr(pr.age)}` + (ok === false ? (pr.last === pred ? '، وافترضت إنه ما تغيّر، لكنه تغيّر.' : '، وتوقعت إنه تغيّر، لكنه ما تغيّر.') : ok === null ? '، وصارت قديمة فما قدرت أحكم.' : '.');
  else why = `ما عندي أي معلومة عن ${it.spot}، فاعتمدت على نسبة الإشغال (${Math.round(baseOld * 100)}%).`;
  const learned = [];
  if (Math.abs(O.tau - tauOld) >= 0.5) learned.push(`${O.tau < tauOld ? 'قصّرت' : 'طوّلت'} مدة ثقتي بآخر معلومة من ${Math.round(tauOld)} إلى ${Math.round(O.tau)} دقيقة.`);
  if (Math.abs(baseNew - baseOld) >= 0.02) learned.push(`نسبة إشغال ${it.spot} المتوقعة صارت ${Math.round(baseNew * 100)}% (كانت ${Math.round(baseOld * 100)}%).`);
  learned.push(`سجلت ${it.spot} ${ST_AR[truth]} الحين.`);
  return { kind: 'status', at: it.at, spot: it.spot, pred, truth, conf, ok, title: `توقع حالة ${it.spot}: ${ST_AR[pred]}${pred !== 'unk' ? ` (${Math.round(conf * 100)}%)` : ''}، والصح ${ST_AR[truth]}`, why: ok === true ? `✓ توقع صحيح. ${why}` : why, learned: learned.join(' ') };
}

function runsText(labels){
  const out = []; let cur = null, n = 0;
  labels.forEach(l => { if (l === cur) n++; else { if (cur) out.push([cur, n]); cur = l; n = 1; } });
  if (cur) out.push([cur, n]);
  return out.map(([l, k]) => ({ D: 'قيادة', S: 'توقف', W: 'مشي' }[l] + ' ' + k + 'ث')).join('، ');
}
// Why an event decision was right or wrong, before the model learns from it
function explainEvent(sess, r, label, belief){
  const truthId = label.type === 'none' ? 'none' : label.spot, tS = lot.byId[label.spot];
  const typeAr = { park: 'وقوف', depart: 'مغادرة' };
  if (!r.event) {
    if (label.type === 'none') return { ok: true, why: '✓ ما لوّنت أي موقف، لأن الحركة ما فيها وقوف ولا مغادرة.', learned: 'ثبّت إن هالنوع من الحركة ما يغيّر المواقف.' };
    return { ok: false, why: `فاتني ${typeAr[label.type]} في ${label.spot}. ما شفت التسلسل الكامل (قيادة ثم توقف ثم نزول)، اللي شفته: ${runsText(r.labels)}.`, learned: 'دربت مصنّف الحركة على هالجلسة عشان ما يفوته مثلها، وحدّثت حالة الموقف.' };
  }
  if (label.type === 'none') {
    if (r.decision === 'none') return { ok: true, why: '✓ عرفت إنه توقف مؤقت مو وقوف، فما غيّرت شي.', learned: '' };
    return { ok: false, why: `حسبت إنه ${typeAr[r.event]} في ${r.decision}، لكن ما كان فيه ${typeAr[r.event]}.`, learned: 'دربت مصنّف الحركة ومعايرة الثقة على هالجلسة، ورجّعت الموقف لحالته.' };
  }
  if (label.type !== r.event) return { ok: false, why: `حسبته ${typeAr[r.event]} وهو ${typeAr[label.type]}.`, learned: 'دربت مصنّف الحركة على هالجلسة.' };
  if (r.decision === 'none') return { ok: false, why: `حسبته توقف مؤقت (مدة التوقف ${r.dwell} ثانية${r.heading !== null && Math.abs(Math.cos(r.heading)) > 0.8 ? '، والسيارة كانت على طول الممر' : ''})، وهو ${typeAr[label.type]} في ${label.spot}.`, learned: 'عدّلت معايرة الثقة عشان التوقف بهالشكل ينحسب وقوف.' };
  const ok = r.decision === truthId;
  const dx = r.est.x - tS.cx, dy = r.est.y - tS.cy, d = Math.hypot(dx, dy);
  const parts = [];
  if (Math.abs(dx) >= 1) parts.push(`${Math.abs(dx).toFixed(1)} م ${dx > 0 ? 'باتجاه آخر الصف' : 'باتجاه أول الصف'}`);
  if (Math.abs(dy) >= 1) parts.push(`${Math.abs(dy).toFixed(1)} م ${dy * tS.dir > 0 ? 'لداخل الصف' : 'جهة الممر'}`);
  const rawOff = Math.hypot(r.raw.x - tS.cx, r.raw.y - tS.cy);
  if (ok) return { ok: true, why: `✓ حددت ${label.spot} صح (ثقة ${Math.round(r.conf * 100)}%).`, learned: rawOff >= 1 ? `سجلت إن GPS هنا مزاح ${rawOff.toFixed(1)} م، والمرة الجاية أصححه تلقائياً.` : 'زادت ثقتي في هالمنطقة.' };
  let why = `حددت ${r.decision} والصح ${label.spot}. تقديري لمكان السيارة كان بعيد ${d.toFixed(1)} م عن ${label.spot}${parts.length ? ' (' + parts.join('، ') + ')' : ''}.`;
  if (belief && belief[tS.idx] === (label.type === 'park' ? 'occ' : 'free')) why += ` وكنت أحسب ${label.spot} ${label.type === 'park' ? 'مشغول' : 'فاضي'} فاستبعدته.`;
  return { ok: false, why, learned: `أضفت انحراف GPS (${rawOff.toFixed(1)} م) لخريطة التصحيح في هالمنطقة، وصححت حالة ${label.spot}.` };
}
function makeRec(sess, r, label, belief, at){
  const truthId = label.type === 'none' ? 'none' : label.spot;
  const x = explainEvent(sess, r, label, belief);
  const typeAr = { park: 'رصد وقوف', depart: 'رصد مغادرة' };
  return { kind: sess.kind, lt: label.type, event: r.event, dec: r.decision || null, auto: !!(r.event && r.auto), ok: r.event ? r.decision === truthId : label.type === 'none', conf: r.event ? r.conf : null,
    at: at || Date.now(), title: r.event ? `${typeAr[r.event]}: ${r.decision === 'none' ? 'خارج المواقف' : r.decision}` : 'جلسة بدون وقوف أو مغادرة', why: x.why, learned: x.learned, okx: x.ok };
}
function applyEventOcc(O, label, t){ const s = label.spot && lot.byId[label.spot]; if (!s) return; if (label.type === 'park') { occObserve(O, s.idx, 'occ'); occSet(O, s.idx, 'occ', t); } if (label.type === 'depart') { occObserve(O, s.idx, 'free'); occSet(O, s.idx, 'free', t); } }
function applyTruth(truth, devBySpot, sess){ const t = sess.truth; if (!t || !t.spot || !lot.byId[t.spot]) return; const s = lot.byId[t.spot]; if (t.type === 'park') { truth[s.idx] = true; devBySpot[t.spot] = sess.deviceId; } else if (t.type === 'depart') { truth[s.idx] = false; delete devBySpot[t.spot]; } }
function itemToSess(it){ return { id: it.sid, kind: it.kind, deviceId: it.dev || null, samples: unpack(it.smp), truth: it.truth || null, ended: !!it.end, atStart: !!it.st0, createdAt: it.at }; }

function rebuild(){
  const L = lotsById[currentLot]; if (!L || L.deleted || !L.cfg) return;
  const cfg = clone(L.cfg); lot = PE.buildLot(cfg); world = clone(L.world);
  const sessMap = {}, labelEv = {};
  knownKeys = new Set();
  const marks = [], fpItems = [], verifs = [];
  for (const id in chunkDocs) for (const it of (chunkDocs[id].items || [])) {
    knownKeys.add(keyOf(it));
    if (it.k === 'm') { marks.push(it); continue; }
    if (it.k === 'f') { fpItems.push(it); continue; }
    if (it.k === 'v') { verifs.push(it); continue; }
    if (it.k === 's') sessMap[it.sid] = it;
    else if (it.k === 'l') { const p = labelEv[it.sid]; if (!p || p.at < it.at) labelEv[it.sid] = it; }
  }
  const labeled = [], queue = [];
  for (const sid in sessMap) {
    const it = sessMap[sid];
    let lab = it.label ? { label: it.label, at: it.lat || it.at } : null;
    const ev = labelEv[sid]; if (ev && (!lab || ev.at > lab.at)) lab = { label: ev.label, at: ev.at };
    if (lab) labeled.push({ it, lab }); else queue.push(it);
  }
  queue.sort((a, b) => a.at - b.at);
  const model = PE.freshModel(); model.P.target = cfg.target;
  const brain = brains[cfg.real ? 'real' : 'sim'];
  const fps = {}; fpItems.sort((a, b) => a.at - b.at).forEach(f => { if (f.removed) delete fps[f.spot]; else if (lot.byId[f.spot]) fps[f.spot] = f; });
  model.fp = fpList(fps);
  const init = (L.init || []).slice(); while (init.length < lot.spots.length) init.push(cfg.real ? -1 : 0);
  const truth = init.map(v => v === 1), O = newOcc(!!cfg.real), t0 = L.createdAt || 0;
  seedModel(model, O, brain);
  init.forEach((v, i) => { if (v === 1 || v === 0) occSet(O, i, v === 1 ? 'occ' : 'free', t0); });
  const devBySpot = {}, sessions = [], records = [], status = [];
  const timeline = labeled.map(x => ({ t: x.lab.at, x })).concat(marks.map(m => ({ t: m.at, m })), verifs.map(v => ({ t: v.at, v })));
  timeline.sort((a, b) => (a.t - b.t) || ((a.x ? a.x.it.sid : (a.m || a.v).sid) < (b.x ? b.x.it.sid : (b.m || b.v).sid) ? -1 : 1));
  for (const ev of timeline) {
    if (ev.m) { const s = lot.byId[ev.m.spot]; if (s) occSet(O, s.idx, ev.m.st, ev.t); continue; }
    if (ev.v) { const rec = applyVerify(O, ev.v); if (rec) status.push(rec); continue; }
    const { it, lab } = ev.x;
    const sess = itemToSess(it), belief = beliefAt(O, lab.at);
    sess.beliefSnap = belief; sess.devSnap = Object.assign({}, model.dev);
    sess.result = PE.analyze(model, lot, sess, belief, model.dev);
    records.push(makeRec(sess, sess.result, lab.label, belief, lab.at));
    PE.learn(model, lot, sess, lab.label);
    applyEventOcc(O, lab.label, lab.at); applyTruth(truth, devBySpot, sess);
    delete sess.result; sess.label = lab.label; sessions.push(sess);
  }
  const pending = S && S.lotId === currentLot ? S.pending : null;
  const pendQ = pending && pending.fromQueue ? pending.id : null;
  const ask = S && S.lotId === currentLot ? S.ask : null;
  S = { lotId: currentLot, name: L.name, cfg, world, fps, truth, occ: O, devBySpot, model, sessions, records, status, queue: queue.filter(q => q.sid !== pendQ), pending, ask };
}
function curBelief(){ return beliefAt(S.occ, Date.now()); }

function commitLabel(sess, label){
  const r = sess.result, now = Date.now(), belief = sess.beliefSnap || curBelief();
  const rec = makeRec(sess, r, label, belief, now);
  PE.learn(S.model, lot, sess, label);
  applyEventOcc(S.occ, label, now); applyTruth(S.truth, S.devBySpot, sess);
  S.records.push(rec); S.lastExplain = rec; lastAskT = Date.now();
  const keep = Object.assign({}, sess); delete keep.result; keep.label = label; keep.beliefSnap = belief; keep.devSnap = keep.devSnap || Object.assign({}, S.model.dev); S.sessions.push(keep);
  if (sess.fromQueue) appendItem({ k: 'l', sid: sess.id, label, at: now });
  else appendItem({ k: 's', sid: sess.id, kind: sess.kind, dev: sess.deviceId || null, at: sess.createdAt || now, smp: pack(sess.samples), truth: sess.truth || null, label, lat: now, end: sess.ended ? 1 : 0, st0: sess.atStart ? 1 : 0 });
  return rec;
}
function commitVerify(spot, truth){
  const it = { k: 'v', sid: 'v-' + clientId + '-' + rid(), spot, truth, at: Date.now() };
  const rec = applyVerify(S.occ, it); if (!rec) return null;
  S.status.push(rec); S.lastExplain = rec; lastAskT = Date.now(); appendItem(it);
  return rec;
}

function onChunks(docs){
  let fresh = firstChunkLoad;
  for (const d of docs) {
    if (myChunk && d.id === myChunk.id) continue;
    chunkDocs[d.id] = d;
    if (!fresh) for (const it of (d.items || [])) if (!knownKeys.has(keyOf(it))) { fresh = true; break; }
  }
  if (!fresh) return;
  firstChunkLoad = false;
  rebuild(); markMode = false;
  if (openQueueNext && S.queue.length && !S.pending) { openQueueNext = false; openNext(); } else renderAll();
  $('loading').hidden = true;
  if (!dirty.size && !flushing) setSave(readOnly ? 'readonly' : 'saved');
}
function switchLot(id){
  if (!id || (lotsById[id] && lotsById[id].deleted)) return;
  if (!lotsById[id]) { wantedLot = id; return; }
  if (id === currentLot) return;
  wantedLot = null; currentLot = id;
  if (unsubChunks) unsubChunks();
  chunkDocs = {}; myChunk = null; knownKeys = new Set(); firstChunkLoad = true; picking = false; fpSel = null; if (live) stopLive();
  if (S) S.pending = null;
  $('loading').hidden = false;
  unsubChunks = store.watchChunks(id, onChunks);
  renderLotSel();
}
async function createLot(cfg, name){
  const id = 'lot-' + rid();
  const l = PE.buildLot(cfg), w = PE.makeWorld(l, { biasStrength: cfg.bias, gpsSigma: cfg.gps });
  const init = l.spots.map(() => Math.random() < cfg.occ ? 1 : 0);
  try { await store.setLot(id, { name, cfg, world: w, init, createdAt: Date.now() }); creatingSim = false; selectLot(id); }
  catch (e) { handleWriteError(e); $('loading').hidden = true; }
}
function renderLotSel(){
  const sel = $('lotSel'); const showA = $('showArch').checked; const ids = Object.keys(lotsById).filter(id => !lotsById[id].deleted && !!lotsById[id].real === (mode === 'real') && (showA || !lotsById[id].archived || id === currentLot)).sort((a, b) => (lotsById[a].createdAt || 0) - (lotsById[b].createdAt || 0));
  sel.innerHTML = ids.map(id => { const L = lotsById[id]; const d = new Date(L.createdAt || 0); return `<option value="${id}">${(L.name || 'باركنق').replace(/[<>&"]/g, '')}${L.archived ? ' (مؤرشف)' : ''}</option>`; }).join('');
  if (!ids.length) sel.innerHTML = `<option value="">${mode === 'real' ? 'ما فيه باركنق حقيقي' : 'جاري التجهيز'}</option>`;
  if (currentLot) sel.value = currentLot;
}

/* ---------------- manual spot status & real lots ---------------- */
let markMode = false, openQueueNext = false;
// Ask the person whether the predicted state of a spot is right
function askSpot(id, why){
  if (readOnly || !S || !S.cfg.real || !lot.byId[id]) return;
  const pr = occProb(S.occ, lot.byId[id].idx, Date.now());
  S.ask = { spot: id, p: pr.p, pred: predOf(pr), last: pr.last, age: pr.age, base: pr.base, why: why || 'tap', t: Date.now() };
  S.lastExplain = null; askedAt[id] = Date.now(); lastAskT = Date.now();
  renderReview(); renderMap();
}
let askedAt = {}, lastAskT = 0;
function answerAsk(truth){
  if (!S || !S.ask) return;
  if (S.ask.kind === 'exit') { const spot = S.ask.spot; S.ask = null; if (truth === 'free') { delete S.model.dev['live-' + clientId]; commitVerify(spot, 'free'); toast(`${spot} صار فاضي`); } renderAll(); return; }
  const rec = commitVerify(S.ask.spot, truth); S.ask = null;
  if (rec) toast(rec.ok === false ? 'انسجل الغلط، والنظام تعلّم منه' : rec.ok ? 'صح ✓' : 'انسجلت الحالة');
  renderAll();
}
function parseLL(txt){
  const m = String(txt || '').replace(/[،٫]/g, ',').match(/(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)/);
  if (!m) return null; const lat = +m[1], lon = +m[2];
  if (Math.abs(lat) > 90 || Math.abs(lon) > 180) return null; return { lat, lon };
}
/* ---------------- GPS stream ---------------- */
// Browsers (especially iPhone Safari) send very few watchPosition updates while the phone is standing still,
// so we also ask for a fresh position every 1.5 s and merge both, skipping duplicates.
function geoStream(onFix, onDenied){
  let alive = true, lastT = 0;
  const ok = p => { if (!alive || p.timestamp === lastT) return; lastT = p.timestamp; onFix(p); };
  const bad = e => { if (alive && e.code === 1) { stop(); onDenied(); } };
  const opts = { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 };
  const watch = navigator.geolocation.watchPosition(ok, bad, opts);
  const poll = setInterval(() => { if (alive) navigator.geolocation.getCurrentPosition(ok, bad, opts); }, 1500);
  navigator.geolocation.getCurrentPosition(ok, bad, opts);
  function stop(){ alive = false; try { navigator.geolocation.clearWatch(watch); } catch (e) {} clearInterval(poll); }
  return stop;
}
function averageFixes(fixes){
  if (!fixes.length) return null;
  const rest = fixes.length > 4 ? fixes.slice(1) : fixes;
  const g0 = rest.filter(f => f.acc <= 25), base = g0.length >= 3 ? g0 : rest;
  const med = a => { const s = a.slice().sort((x, y) => x - y); return s[Math.floor(s.length / 2)] || 0; };
  const mlat = med(base.map(f => f.lat)), mlon = med(base.map(f => f.lon)), kx = Math.cos(mlat * Math.PI / 180) * 111320;
  let use = base.filter(f => Math.hypot((f.lat - mlat) * 110540, (f.lon - mlon) * kx) <= Math.max(6, 2 * f.acc));
  if (!use.length) use = base;
  let sw = 0, la = 0, lo = 0, ac = 0; use.forEach(f => { const w = 1 / Math.max(1, f.acc * f.acc); sw += w; la += w * f.lat; lo += w * f.lon; ac += f.acc; });
  return { lat: la / sw, lon: lo / sw, n: use.length, acc: ac / use.length };
}

/* ---------------- add-a-real-lot wizard ---------------- */
let wiz = { type: 'row', side: null, p1: null, p2: null, dir: null, busy: false }, wizardOpen = false;
function geoAdd(ll, de, dn){ const k = Math.cos(ll.lat * Math.PI / 180) * 111320; return { lat: ll.lat + dn / 110540, lon: ll.lon + de / k }; }
function captureGPS(ms, onTick){
  return new Promise((resolve, reject) => {
    if (!('geolocation' in navigator)) { reject('المتصفح ما يدعم قراءة الموقع.'); return; }
    const fixes = [], t0 = Date.now(); let over = false, timer;
    const stop = geoStream(p => fixes.push({ lat: p.coords.latitude, lon: p.coords.longitude, acc: p.coords.accuracy }),
      () => end('المتصفح رفض إذن الموقع. فعّله من إعدادات المتصفح للموقع هذا، وجرّب مرة ثانية.'));
    function end(err){
      if (over) return; over = true; stop(); clearInterval(timer);
      if (err) { reject(err); return; }
      const r = averageFixes(fixes);
      if (!r) { reject('الجوال ما أعطى أي قراءة موقع. تأكد إن خدمات الموقع شغالة للمتصفح.'); return; }
      resolve(r);
    }
    timer = setInterval(() => { const el2 = Date.now() - t0; if (onTick) onTick(Math.min(1, el2 / ms), Math.max(0, Math.ceil((ms - el2) / 1000)), fixes.length, fixes.length ? fixes[fixes.length - 1].acc : null); if (el2 >= ms) end(); }, 500);
  });
}
function captureCompass(ms){
  return new Promise(resolve => {
    const vals = []; const h = e => { if (typeof e.webkitCompassHeading === 'number') vals.push(e.webkitCompassHeading); else if (e.absolute && e.alpha !== null) vals.push((360 - e.alpha) % 360); };
    window.addEventListener('deviceorientation', h); window.addEventListener('deviceorientationabsolute', h);
    setTimeout(() => { window.removeEventListener('deviceorientation', h); window.removeEventListener('deviceorientationabsolute', h);
      if (!vals.length) { resolve(null); return; } let s = 0, c = 0; vals.forEach(v => { s += Math.sin(v * Math.PI / 180); c += Math.cos(v * Math.PI / 180); }); resolve((Math.atan2(s, c) * 180 / Math.PI + 360) % 360); }, ms);
  });
}
async function wizFp(which){
  if (wiz.busy) return; wiz.busy = true; renderWizard();
  const lab = which === 1 ? 'wFp1s' : 'wFp2s';
  $('wProg').hidden = false;
  try {
    const r = await captureGPS(20000, (f, left, n, acc) => { $('wProg').firstElementChild.style.width = (f * 100) + '%'; $(lab).textContent = `خلك واقف... باقي ${left} ثانية، ${n} قراءة${acc ? `، الدقة ${Math.round(acc)} م` : ''}`; });
    wiz['p' + which] = r; $(lab).textContent = `تم (${r.n} قراءة، الدقة تقريباً ${Math.round(r.acc)} م)` + (r.acc > 20 ? '. الدقة ضعيفة: فعّل "الموقع الدقيق" للمتصفح وأعدها' : '');
  } catch (err) { $(lab).textContent = ''; $('wOut').innerHTML = `<div class="note-warn">${err}</div>`; }
  $('wProg').hidden = true; wiz.busy = false; renderWizard();
}
async function wizDir(){
  try { if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') await DeviceOrientationEvent.requestPermission(); } catch (e) {}
  $('wDirs').textContent = 'ثبّت الجوال...';
  const d = await captureCompass(2500);
  wiz.dir = d; $('wDirs').textContent = d === null ? 'البوصلة غير متاحة، عادي نكمل بدونها' : 'تم'; wiz.dirTried = true; renderWizard();
}
function wizCfg(){
  const W = Math.max(2, Math.min(4, +$('wW').value || 2.5)), L = Math.max(4, Math.min(7, +$('wL').value || 5.5));
  if (!wiz.p1) return { err: null };
  if (wiz.type === 'one') {
    if (!wiz.dirTried) return { err: null };
    const td = wiz.dir === null ? 0 : wiz.dir; const v = { e: Math.sin(td * Math.PI / 180), n: Math.cos(td * Math.PI / 180) }, u = { e: v.n, n: -v.e };
    const A = geoAdd(wiz.p1, -u.e * W / 2 - v.e * L / 2, -u.n * W / 2 - v.n * L / 2), B = geoAdd(A, u.e * W, u.n * W);
    return { cfg: { real: true, A, B, side: 1, rows: 1, perRow: 1, W, L, aisle: 6.5, margin: 5, target: 0.98, noHeading: wiz.dir === null }, seeds: [['A-01', wiz.p1]], warn: [] };
  }
  const per = Math.max(2, Math.min(80, Math.round(+$('wPer').value || 2))), rows = Math.max(1, Math.min(8, Math.round(+$('wRows').value || 1))), aisle = Math.max(3, Math.min(12, +$('wAisle').value || 6.5));
  if (!wiz.p2 || !wiz.side) return { err: null };
  const k = Math.cos(wiz.p1.lat * Math.PI / 180) * 111320, de = (wiz.p2.lon - wiz.p1.lon) * k, dn = (wiz.p2.lat - wiz.p1.lat) * 110540, d = Math.hypot(de, dn);
  if (d < 2) return { err: 'البصمتين قريبة من بعض مرة. تأكد إنك بصمت أول موقف وآخر موقف.' };
  const u = { e: de / d, n: dn / d }, side = wiz.side === 'right' ? 1 : -1, v = { e: -u.n * side, n: u.e * side };
  const A = geoAdd(wiz.p1, -u.e * W / 2 - v.e * L / 2, -u.n * W / 2 - v.n * L / 2), B = geoAdd(A, u.e * per * W, u.n * per * W);
  const expect = (per - 1) * W, warn = [];
  if (Math.abs(d - expect) > Math.max(3, 0.12 * expect)) warn.push(`المسافة بين البصمتين ${d.toFixed(1)} م، والمفروض ${expect.toFixed(1)} م لـ${per} مواقف بعرض ${W} م. تأكد من العدد أو أعد البصمة.`);
  return { cfg: { real: true, A, B, side, rows, perRow: per, W, L, aisle, margin: 5, target: 0.98 }, seeds: [['A-01', wiz.p1], ['A-' + String(per).padStart(2, '0'), wiz.p2]], warn, d };
}
function renderWizard(){
  const one = wiz.type === 'one';
  document.querySelectorAll('[data-wt]').forEach(b => b.classList.toggle('on', b.dataset.wt === wiz.type));
  document.querySelectorAll('[data-side]').forEach(b => b.classList.toggle('on', b.dataset.side === wiz.side));
  $('wRowFields').hidden = one; $('wS2').hidden = one; $('wS3').hidden = one; $('wS2b').hidden = !one;
  $('wS1t').textContent = one ? 'قف في منتصف الموقف' : 'قف في منتصف أول موقف';
  $('wFp1').disabled = wiz.busy; $('wFp2').disabled = wiz.busy || !wiz.p1; $('wDir').disabled = wiz.busy || !wiz.p1;
  const r = wizCfg();
  if (r.err) $('wOut').innerHTML = `<div class="note-warn">${r.err}</div>`;
  else if (r.cfg) $('wOut').innerHTML = r.warn.length ? `<div class="note-warn">${r.warn.join('<br>')}</div>` : `<span style="color:var(--good)">${one ? 'جاهز.' : `جاهز: ${r.cfg.rows} صف، ${r.cfg.perRow} موقف في الصف.`}</span>`;
  $('wAdd').disabled = !r.cfg || readOnly || wiz.busy;
}
function resetWizard(){ wiz = { type: wiz.type || 'row', side: null, p1: null, p2: null, dir: null, busy: false }; ['wFp1s', 'wFp2s', 'wDirs'].forEach(id => $(id).textContent = ''); $('wOut').textContent = ''; $('wName').value = ''; renderWizard(); }
async function wizAdd(){
  const r = wizCfg(); if (!r.cfg) return;
  const name = ($('wName').value || 'باركنق').slice(0, 60), id = 'lot-' + rid(), l = PE.buildLot(r.cfg);
  $('loading').hidden = false;
  try {
    await store.setLot(id, { name, real: true, cfg: r.cfg, world: null, init: l.spots.map(() => -1), createdAt: Date.now() });
    const now = Date.now();
    const seeds = r.seeds.filter(([spot]) => l.byId[spot]).map(([spot, p], i) => { const q = PE.geoToLocal(r.cfg, p.lat, p.lon); return { k: 'f', sid: 'f-' + clientId + '-' + rid() + i, spot, lat: p.lat, lon: p.lon, x: Math.round(q.x * 100) / 100, y: Math.round(q.y * 100) / 100, n: p.n || 0, acc: p.acc ? Math.round(p.acc * 10) / 10 : null, at: now + i }; });
    if (seeds.length) await writeItemsAsChunks(id, seeds);
    wizardOpen = false; resetWizard(); selectLot(id); toast('انضاف الباركنق');
  } catch (e) { handleWriteError(e); $('loading').hidden = true; }
}

async function archiveCurrent(){
  const L = lotsById[currentLot]; if (!L) return;
  const body = Object.assign({}, clone(L)); delete body.id; body.archived = !L.archived;
  try {
    await store.setLot(currentLot, body);
    if (body.archived) { const next = Object.keys(lotsById).filter(id => id !== currentLot && !lotsById[id].archived && !!lotsById[id].real === (mode === 'real')).sort((a, b) => (lotsById[b].createdAt || 0) - (lotsById[a].createdAt || 0))[0]; if (next) selectLot(next); }
    toast(body.archived ? 'انأرشف الباركنق، وبياناته محفوظة' : 'رجع الباركنق للقائمة');
  } catch (e) { handleWriteError(e); }
}
function applyLotMode(){
  document.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('on', b.dataset.mode === mode));
  const real = mode === 'real';
  const hasReal = Object.keys(lotsById).some(id => lotsById[id].real && !lotsById[id].archived && !lotsById[id].deleted);
  $('simBanner').hidden = real; $('addLotBtn').hidden = !real; $('simForm').hidden = real;
  const showWiz = real && wizardOpen;
  $('wizard').hidden = !showWiz;
  $('emptyReal').hidden = !(real && !hasReal && !showWiz && !(S && S.cfg.real && S.lotId === currentLot));
  const ready = S && S.lotId === currentLot && !!S.cfg.real === real;
  $('mainArea').hidden = !ready; $('ioDetails').hidden = !ready;
  if (!S) return;
  $('simPanel').hidden = real; $('realPanel').hidden = !real; $('tTruthL').hidden = real;
  if (real) $('tTruth').checked = false; else { markMode = false; fpMode = false; if (live) stopLive(); }
  $('markHint').hidden = !real;
  const L = lotsById[currentLot];
  $('archBtn').textContent = L && L.archived ? 'رجّعه للقائمة' : 'أرشف هذا الباركنق';
  renderFp(); renderLive();
}

/* ---------------- fingerprints ---------------- */
let fpMode = false, fpSel = null, fpRun = null;
function fpList(fps){ const out = []; for (const id in fps) { const f = fps[id], s = lot.byId[id]; if (!s) continue; out.push({ spot: id, x: s.cx, y: s.cy, rx: f.x - s.cx, ry: f.y - s.cy, w: 3 }); } return out; }
function selectFpSpot(id){ if (fpRun) return; fpSel = id; renderFp(); renderMap(); }
function renderFp(){
  $('fpBox').hidden = !fpMode; $('fpBtn').textContent = fpMode ? 'انتهيت من البصمة' : 'بصّم مواقف';
  if (!fpMode || !S) return;
  const f = fpSel && S.fps[fpSel];
  $('fpSpot').textContent = fpSel || 'اختر من الخريطة';
  $('fpStart').disabled = !fpSel || !!fpRun || readOnly; $('fpManualBtn').disabled = !fpSel || !!fpRun || readOnly;
  $('fpRemove').hidden = !f || !!fpRun; $('fpStart').textContent = f ? 'أعد التبصيم' : 'بصّم هذا الموقف';
  if (!fpRun) $('fpState').textContent = !fpSel ? '' : f ? `مبصوم${f.n ? ` من ${f.n} قراءة` : ' يدوياً'}${f.acc ? `، دقة GPS وقتها تقريباً ${Math.round(f.acc)} م` : ''}. يبعد ${Math.hypot(f.x - lot.byId[fpSel].cx, f.y - lot.byId[fpSel].cy).toFixed(1)} م عن مكانه المرسوم.` : 'غير مبصوم.';
}
function fpWarnings(spot, x, y){
  const s = lot.byId[spot], w = [];
  const off = Math.hypot(x - s.cx, y - s.cy);
  if (off > 8) w.push(`البصمة تبعد ${off.toFixed(1)} م عن مكان الموقف المرسوم. تأكد إنك واقف في ${spot}، أو إن نقاط الباركنق صحيحة.`);
  for (const id in S.fps) {
    if (id === spot) continue; const o = S.fps[id], so = lot.byId[id]; if (!so) continue;
    const dp = Math.hypot(x - o.x, y - o.y), dg = Math.hypot(s.cx - so.cx, s.cy - so.cy);
    if (dp < s.x1 - s.x0 - 0.5 && dg > 0.1) w.push(`البصمة قريبة جداً من بصمة ${id} (${dp.toFixed(1)} م)، يعني ممكن تتلخبط معه.`);
    else if (dg < 12 && Math.abs(dp - dg) > 3.5) w.push(`المسافة بين بصمتي ${spot} و${id} ${dp.toFixed(1)} م، والمفروض حسب المقاس ${dg.toFixed(1)} م.`);
  }
  return w;
}
function saveFp(spot, lat, lon, n, acc){
  const p = PE.geoToLocal(S.cfg, lat, lon);
  const it = { k: 'f', sid: 'f-' + clientId + '-' + rid(), spot, lat, lon, x: Math.round(p.x * 100) / 100, y: Math.round(p.y * 100) / 100, n, acc: acc === null ? null : Math.round(acc * 10) / 10, at: Date.now() };
  const warns = fpWarnings(spot, it.x, it.y);
  S.fps[spot] = it; S.model.fp = fpList(S.fps);
  appendItem(it);
  $('fpWarn').innerHTML = warns.length ? `<div class="note-warn">${warns.join('<br>')}</div>` : `<span style="color:var(--good)">انحفظت بصمة ${spot}.</span>`;
  if ($('fpNext').checked) { const s = lot.byId[spot], nx = lot.spots.find(q => q.row === s.row && q.col === s.col + 1) || lot.spots.find(q => q.row === s.row + 1 && q.col === 0); if (nx) fpSel = nx.id; }
  renderFp(); renderMap();
}
function removeFp(spot){
  delete S.fps[spot]; S.model.fp = fpList(S.fps);
  appendItem({ k: 'f', sid: 'f-' + clientId + '-' + rid(), spot, removed: true, at: Date.now() });
  $('fpWarn').textContent = 'انفكت البصمة.'; renderFp(); renderMap();
}
async function startFp(){
  if (!fpSel || fpRun) return;
  const spot = fpSel; fpRun = { spot };
  $('fpProg').hidden = false; $('fpWarn').textContent = ''; renderFp();
  try {
    const r = await captureGPS(20000, (f, left, n, acc) => { $('fpProg').firstElementChild.style.width = (f * 100) + '%'; $('fpState').textContent = `خلك واقف في منتصف ${spot}. ${n} قراءة${acc ? `، الدقة الحالية ${Math.round(acc)} م` : ''}، باقي ${left} ثانية.`; });
    fpRun = null; $('fpProg').hidden = true;
    saveFp(spot, r.lat, r.lon, r.n, r.acc);
    if (r.acc > 20) $('fpWarn').innerHTML += `<div class="note-warn" style="margin-top:6px">دقة الـGPS كانت تقريباً ${Math.round(r.acc)} م، وهذي ضعيفة للبصمة. تأكد إن "الموقع الدقيق" مفعّل للمتصفح في إعدادات الجوال، وأعدها في مكان مكشوف.</div>`;
  } catch (err) { fpRun = null; $('fpProg').hidden = true; $('fpState').textContent = ''; $('fpWarn').innerHTML = `<div class="note-warn">${err}</div>`; renderFp(); }
}

/* ---------------- geofence (from Mawqifi): lot boundary with 3-reading stabilization ---------------- */
const GEOFENCE_MARGIN = 12, GEOFENCE_CONFIRM = 3;
function newGeofence(){ return { stable: null, cand: null, count: 0, lastTransition: null, lastChangeAt: 0, insideSince: 0, lastInsideAt: 0 }; }
function rawInside(x, y){ return x >= -GEOFENCE_MARGIN && x <= lot.width + GEOFENCE_MARGIN && y >= -GEOFENCE_MARGIN && y <= lot.height + GEOFENCE_MARGIN; }
// Returns 'ENTER' | 'EXIT' | null. A change needs three consecutive readings, so one jumpy fix cannot flip it.
function updateGeofence(g, x, y, now){
  const raw = rawInside(x, y) ? 'IN' : 'OUT';
  let tr = null;
  if (g.stable === null) { g.stable = raw; if (raw === 'IN') { g.insideSince = now; } }
  else if (raw === g.stable) { g.cand = null; g.count = 0; }
  else { if (g.cand === raw) g.count++; else { g.cand = raw; g.count = 1; }
    if (g.count >= GEOFENCE_CONFIRM) { tr = raw === 'IN' ? 'ENTER' : 'EXIT'; g.stable = raw; g.cand = null; g.count = 0; g.lastTransition = tr; g.lastChangeAt = now; if (raw === 'IN') g.insideSince = now; } }
  if (g.stable === 'IN') g.lastInsideAt = now;
  return tr;
}
function myParkedSpot(){ const id = S && S.model.dev['live-' + clientId]; return id && lot.byId[id] ? id : null; }
// Geofence exits tell us how the person left: driving means the car left too; walking means it stayed.
function onGeofenceTransition(tr){
  const recent = (live.labels || []).slice(-6), driving = recent.filter(l => l === 'D').length >= 4;
  const spot = myParkedSpot();
  if (tr === 'ENTER') toast(driving ? 'دخلت الباركنق بالسيارة' : spot ? `دخلت الباركنق ماشي، سيارتك في ${spot}` : 'دخلت الباركنق');
  if (tr === 'EXIT') {
    if (driving && spot && !S.pending) { S.ask = { spot, kind: 'exit', t: Date.now() }; lastAskT = Date.now(); renderReview(); renderMap(); }
    else if (!driving && spot) toast(`طلعت من الباركنق ماشي، سيارتك باقية في ${spot}`);
    else toast('طلعت من الباركنق');
  }
}

/* ---------------- live sensing (foreground, phone browser) ---------------- */
let live = null;
function liveMsg(t){ const m = $('liveMsg'); m.hidden = !t; m.textContent = t || ''; }
async function startLive(){
  if (!S || !S.cfg.real || live) return;
  try { if (typeof DeviceMotionEvent !== 'undefined' && typeof DeviceMotionEvent.requestPermission === 'function') await DeviceMotionEvent.requestPermission(); } catch (e) {}
  try { if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') await DeviceOrientationEvent.requestPermission(); } catch (e) {}
  if (!('geolocation' in navigator)) { liveMsg('المتصفح ما يدعم قراءة الموقع.'); return; }
  live = { geo: newGeofence(), samples: [], labels: [], abs: 0, fix: null, prev: null, steps: [], lastEventAbs: -1, motion: false, compass: null, fast: 9.8, base: 9.8, up: false, lastStep: 0, state: null };
  live.onMotion = e => {
    const a = e.accelerationIncludingGravity; if (!a || a.x === null) return; live.motion = true;
    const mag = Math.hypot(a.x, a.y, a.z), now = performance.now();
    live.acc = live.acc || []; live.acc.push(mag); if (live.acc.length > 60) live.acc.shift();
    live.fast = live.fast * 0.7 + mag * 0.3; live.base = live.base * 0.98 + mag * 0.02;
    const d = live.fast - live.base;
    if (!live.up && d > 1.3 && now - live.lastStep > 280) { live.up = true; live.lastStep = now; live.steps.push(now); }
    else if (live.up && d < 0.3) live.up = false;
    while (live.steps.length && now - live.steps[0] > 4000) live.steps.shift();
  };
  live.onOrient = e => { if (typeof e.webkitCompassHeading === 'number') live.compass = e.webkitCompassHeading; else if (e.absolute && e.alpha !== null) live.compass = (360 - e.alpha) % 360; };
  window.addEventListener('devicemotion', live.onMotion); window.addEventListener('deviceorientation', live.onOrient);
  live.stopGeo = geoStream(p => {
    const c = p.coords, loc = PE.geoToLocal(S.cfg, c.latitude, c.longitude);
    live.prev = live.fix; live.fix = { x: loc.x, y: loc.y, acc: c.accuracy, speed: c.speed, heading: c.heading, t: p.timestamp };
    live.hist = (live.hist || []).concat([live.fix]).slice(-8);
    liveMsg('');
  }, () => { stopLive(); liveMsg('المتصفح رفض إذن الموقع. فعّله من إعدادات المتصفح للموقع هذا.'); });
  live.timer = setInterval(liveTick, 1000);
  try { if (navigator.wakeLock) live.wake = await navigator.wakeLock.request('screen'); } catch (e) {}
  renderLive();
}
function stopLive(){
  if (!live) return;
  try { if (S) finalizeOnHide(); } catch (e) {}
  try { if (live.stopGeo) live.stopGeo(); } catch (e) {}
  clearInterval(live.timer);
  window.removeEventListener('devicemotion', live.onMotion); window.removeEventListener('deviceorientation', live.onOrient);
  try { if (live.wake) live.wake.release(); } catch (e) {}
  live = null; renderLive(); if (S) renderMap();
}
function liveTick(){
  if (!live || !S) return;
  const f = live.fix; if (!f) { renderLive(); return; }
  let speed = (typeof f.speed === 'number' && f.speed >= 0) ? f.speed : null;
  if (speed === null) { // no Doppler speed from the browser: use displacement over ~3 s, which damps GPS jitter
    const h = live.hist || [], old = h.find(q => f.t - q.t >= 2500) || h[0];
    speed = old && f.t - old.t > 400 ? Math.hypot(f.x - old.x, f.y - old.y) / ((f.t - old.t) / 1000) : 0;
  }
  const cad = live.motion ? live.steps.length / 4 : 0;
  const hdgDeg = (typeof f.heading === 'number' && f.heading >= 0 && speed > 1.5) ? f.heading : live.compass;
  const hdg = hdgDeg === null || hdgDeg === undefined ? null : Math.round(PE.headingToLocal(S.cfg, hdgDeg) * 1000) / 1000;
  const r2 = v => Math.round(v * 100) / 100;
  const vib = live.motion ? vibNow() : 0;
  live.samples.push({ t: live.abs, gx: r2(f.x), gy: r2(f.y), acc: r2(f.acc), speed: r2(speed), cad: r2(cad), act: 'unknown', hdg, vib: r2(vib) });
  live.abs++; if (live.samples.length > 400) live.samples.shift();
  const now = Date.now(), tr = updateGeofence(live.geo, f.x, f.y, now);
  const nearLot = live.geo.stable === 'IN' || now - live.geo.lastInsideAt < 60000;
  const win = live.samples.slice(-180), winStart = live.abs - win.length;
  const r = PE.analyze(S.model, lot, { id: 'live', samples: win, deviceId: 'live-' + clientId }, curBelief(), S.model.dev, null, { ended: false, atStart: winStart === 0 });
  live.labels = r.labels; live.state = r.labels[r.labels.length - 1]; live.winStart = winStart;
  if (r.event && r.ev && winStart + r.ev.dwell[0] > live.lastEventAbs && nearLot) {
    live.lastEventAbs = live.abs - 1;
    captureLive(win.slice(Math.max(0, r.ev.dwell[0] - 60)), 'live', { atStart: winStart === 0 && r.ev.how === 'start' });
  } else if (r.event && r.ev && !nearLot) {
    live.lastEventAbs = live.abs - 1; // stopped outside the lot boundary: not a parking event here
  } else maybeAskNearby(f, speed, cad);
  if (tr) onGeofenceTransition(tr);
  renderLive(); if (!S.pending) renderMap();
}
// While walking slowly or standing next to a spot, ask whether its predicted state is right
function maybeAskNearby(f, speed, cad){
  if (S.pending || S.ask || readOnly || !S.cfg.real || live.geo.stable !== 'IN') return;
  if (!(f.acc <= 20) || speed > 1.6 || live.state === 'D' || Date.now() - lastAskT < 20000) return;
  if ((live.labels || []).slice(-90).includes('D')) return; // just drove: the person is parking or leaving, not checking spots
  const c = PE.correction(S.model, f.x, f.y), x = f.x - c.x, y = f.y - c.y;
  let best = null, bd = 1e9;
  for (const s of lot.spots) { const dx = Math.max(s.x0 - x, 0, x - s.x1), dy = Math.max(s.y0 - y, 0, y - s.y1), d = Math.hypot(dx, dy); if (d < bd) { bd = d; best = s; } }
  if (!best || bd > 1.5 || Date.now() - (askedAt[best.id] || 0) < 600000) return;
  askSpot(best.id, 'near');
}
function vibNow(){ const a = live.acc; if (!a || a.length < 10) return 0; let m = 0; a.forEach(v => m += v); m /= a.length; let s = 0; a.forEach(v => s += (v - m) * (v - m)); return Math.sqrt(s / a.length); }
function liveStages(){
  const labs = live.labels || []; const runs = []; labs.forEach((l, i) => { if (runs.length && runs[runs.length - 1].m === l) runs[runs.length - 1].n++; else runs.push({ m: l, n: 1 }); });
  const P = S.model.P; let k = -1; for (let i = runs.length - 1; i >= 0; i--) if (runs[i].m === 'D' && runs[i].n >= P.minDrive) { k = i; break; }
  const st = [['قيادة', false], ['توقف', false], ['نزول ومشي', false]]; let wait = 'قيادة داخل الباركنق';
  if (k >= 0) { st[0][1] = true; wait = 'توقف السيارة';
    const s = runs[k + 1]; if (s && s.m === 'S') { st[1][1] = s.n >= P.minDwell; wait = st[1][1] ? `تنزل وتمشي، أو ${Math.max(0, P.parkDwell - s.n)} ثانية ثبات` : 'ثبات السيارة';
      const w = runs[k + 2]; if (w && w.m === 'W') { st[2][1] = w.n >= P.minWalk; wait = 'مشي أكثر شوي'; } } }
  return { st, wait };
}
function captureLive(samples, kind, flags){
  flags = flags || {};
  const it = { k: 's', sid: 's-' + clientId + '-' + rid(), kind, dev: 'live-' + clientId, at: Date.now(), smp: pack(samples), truth: null, end: flags.ended ? 1 : 0, st0: flags.atStart ? 1 : 0 };
  if (document.hidden) urgentSave(it); else appendItem(it);
  S.queue.push(it); S.ask = null;
  if (!S.pending) openNext(); else { toast('انرصد حدث جديد، ينتظر المراجعة'); renderReview(); }
}
// The page is being hidden (phone locked): if the car just stopped, that is a park; save it right away
function finalizeOnHide(){
  if (!live || !S || live.samples.length < 12) return;
  if (!(live.geo.stable === 'IN' || Date.now() - live.geo.lastInsideAt < 60000)) return;
  const win = live.samples.slice(-180), winStart = live.abs - win.length;
  const r = PE.analyze(S.model, lot, { id: 'live', samples: win, deviceId: 'live-' + clientId }, curBelief(), S.model.dev, null, { ended: true, atStart: winStart === 0 });
  if (r.event && r.ev && winStart + r.ev.dwell[0] > live.lastEventAbs) {
    live.lastEventAbs = live.abs - 1;
    captureLive(win.slice(Math.max(0, r.ev.dwell[0] - 60)), 'live', { ended: r.ev.how === 'ended', atStart: r.ev.how === 'start' });
  }
}
function urgentSave(it){
  knownKeys.add(keyOf(it));
  const id = clientId + '-u-' + rid(), doc = { client: clientId, items: [it], updatedAt: Date.now() };
  chunkDocs[id] = Object.assign({ id }, doc);
  try { (store.setChunkUrgent || store.setChunk)(currentLot, id, doc).catch(() => { appendItem(it); }); } catch (e) { appendItem(it); }
}
function renderLive(){
  const on = !!live;
  $('liveBtn').textContent = on ? 'أوقف الاستشعار' : 'ابدأ الاستشعار';
  $('liveMissBtn').hidden = !on; $('liveBox').hidden = !on;
  if (!on) return;
  const s = live.samples[live.samples.length - 1];
  const st = { D: 'قيادة', S: 'متوقف', W: 'مشي' }[live.state] || 'ننتظر قراءات';
  const g = liveStages();
  $('liveBox').innerHTML = `
    <div style="grid-column:1/-1"><span>مراحل رصد الوقوف</span><b>${g.st.map(([n, ok]) => `<span class="stage${ok ? ' ok' : ''}">${ok ? '✓ ' : ''}${n}</span>`).join('<span class="muted"> ← </span>')}</b><div class="small muted" style="margin-top:4px">ينتظر: ${g.wait}</div></div>
    <div><span>حدود الباركنق</span><b>${live.geo.stable === 'IN' ? '✓ داخل' : live.geo.stable === 'OUT' ? 'خارج' : '...'}${live.geo.cand ? ` <span class="muted small">(${live.geo.count}/${GEOFENCE_CONFIRM})</span>` : ''}</b></div>
    <div><span>الحالة الآن</span><b>${st}</b></div>
    <div><span>دقة GPS</span><b>${s ? Math.round(s.acc) + ' م' : '...'}</b></div>
    <div><span>السرعة</span><b>${s ? (s.speed * 3.6).toFixed(0) + ' كم/س' : '...'}</b></div>
    <div><span>الخطوات</span><b>${live.motion ? (s ? s.cad.toFixed(1) + ' بالثانية' : '...') : 'حساس الحركة غير متاح'}</b></div>
    <div><span>الاهتزاز</span><b>${live.motion && s ? s.vib.toFixed(2) : 'غير متاح'}</b></div>
    <div><span>قراءات مسجلة</span><b>${live.abs}</b></div>`;
}

/* ---------------- map pan & zoom ---------------- */
let mapView = null, mapDragged = false;
function zoomMap(f, cx, cy){
  if (!mapView) return;
  const nw = Math.min(mapView.home.w * 3, Math.max(8, mapView.w * f)), k = nw / mapView.w;
  if (cx === undefined) { cx = mapView.x + mapView.w / 2; cy = mapView.y + mapView.h / 2; }
  mapView.x = cx - (cx - mapView.x) * k; mapView.y = cy - (cy - mapView.y) * k; mapView.w *= k; mapView.h *= k; renderMap();
}
function centerMapOn(x, y){ if (!mapView) return; mapView.x = x - mapView.w / 2; mapView.y = y - mapView.h / 2; renderMap(); }
function setupMapGestures(){
  const svg = $('map'), pts = new Map(); let start = null;
  const toSvg = (cx, cy) => { const b = svg.getBoundingClientRect(); return { x: mapView.x + (cx - b.left) / b.width * mapView.w, y: mapView.y + (cy - b.top) / b.height * mapView.h }; };
  svg.addEventListener('pointerdown', e => { if (!mapView) return; pts.set(e.pointerId, { x: e.clientX, y: e.clientY }); start = { view: Object.assign({}, mapView), pts: new Map([...pts].map(([k, v]) => [k, Object.assign({}, v)])) }; mapDragged = false; });
  svg.addEventListener('pointermove', e => {
    if (!pts.has(e.pointerId) || !start) return;
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const b = svg.getBoundingClientRect(), s = start.view.w / b.width;
    if (pts.size === 1) {
      const p0 = start.pts.get(e.pointerId); if (!p0) return;
      const dx = e.clientX - p0.x, dy = e.clientY - p0.y;
      if (Math.hypot(dx, dy) > 6) mapDragged = true;
      if (mapDragged) { mapView.x = start.view.x - dx * s; mapView.y = start.view.y - dy * s; renderMap(); }
    } else if (pts.size === 2) {
      const [a, c] = [...pts.values()], [a0, c0] = [...start.pts.values()];
      if (!a0 || !c0) return;
      const d0 = Math.hypot(a0.x - c0.x, a0.y - c0.y) || 1, d1 = Math.hypot(a.x - c.x, a.y - c.y) || 1;
      mapDragged = true; Object.assign(mapView, start.view);
      const mid = toSvg((a0.x + c0.x) / 2, (a0.y + c0.y) / 2); zoomMap(d0 / d1, mid.x, mid.y);
    }
  });
  const end = e => { pts.delete(e.pointerId); if (pts.size === 0) { start = null; setTimeout(() => { mapDragged = false; }, 0); } else start = { view: Object.assign({}, mapView), pts: new Map([...pts].map(([k, v]) => [k, Object.assign({}, v)])) }; };
  svg.addEventListener('pointerup', end); svg.addEventListener('pointercancel', end); svg.addEventListener('pointerleave', end);
  svg.addEventListener('wheel', e => { if (!mapView) return; e.preventDefault(); const p = toSvg(e.clientX, e.clientY); zoomMap(e.deltaY > 0 ? 1.15 : 1 / 1.15, p.x, p.y); }, { passive: false });
  $('zIn').onclick = () => zoomMap(1 / 1.3); $('zOut').onclick = () => zoomMap(1.3);
  $('zFit').onclick = () => { if (mapView) { Object.assign(mapView, mapView.home); renderMap(); } };
  $('zMe').onclick = () => { const s = live && live.samples[live.samples.length - 1]; if (s) centerMapOn(s.gx, lot.height - s.gy); else toast('شغّل الاستشعار عشان أعرف مكانك'); };
}

/* ---------------- shared learning ("brain") kept when a lot is deleted ---------------- */
// Transferable knowledge: how walking/driving look, how accurate the estimates are, how confidence
// maps to correctness, and how fast information goes stale. GPS offsets and occupancy rates are
// tied to one place, so they are not carried over.
let brains = { real: null, sim: null };
function brainOf(model, O){
  return { w: model.w.slice(), eA: model.eA.slice(-200), eB: model.eB.slice(-200), eF: model.eF.slice(-200), calib: model.calib.slice(-300), trained: model.trained, tau: O ? O.tau : 20, lots: 1, at: Date.now() };
}
function mergeBrain(old, add){
  if (!old || !Array.isArray(old.w)) return add;
  const a = old.trained || 0, b = add.trained || 0, n = Math.max(1, a + b);
  return { w: add.w.map((v, i) => ((old.w[i] ?? v) * a + v * b) / n), eA: old.eA.concat(add.eA).slice(-200), eB: old.eB.concat(add.eB).slice(-200), eF: old.eF.concat(add.eF).slice(-200),
    calib: old.calib.concat(add.calib).slice(-300), trained: a + b, tau: (old.tau * a + add.tau * b) / n, lots: (old.lots || 1) + 1, at: Date.now() };
}
function seedModel(model, O, brain){
  if (!brain || !Array.isArray(brain.w) || !Array.isArray(brain.eA) || !Array.isArray(brain.calib)) return;
  model.w = brain.w.slice(); model.eA = brain.eA.slice(); model.eB = brain.eB.slice(); model.eF = brain.eF.slice(); model.calib = brain.calib.slice();
  PE.recalibrate(model); if (O && brain.tau) O.tau = brain.tau;
}
async function loadBrains(){
  for (const m of ['real', 'sim']) { try { brains[m] = await store.getBrain(m); } catch (e) { brains[m] = null; } }
}
// Deleting erases the place for everyone: the lot's coordinates and all its recordings are overwritten
// (the database keeps no history), after its transferable learning is merged into the shared brain.
async function scrubLot(id, real){
  const body = { name: '(محذوف)', real: !!real, deleted: true, deletedAt: Date.now(), cfg: null, world: null, init: [], createdAt: (lotsById[id] && lotsById[id].createdAt) || 0 };
  await store.setLot(id, body);
  lotsById[id] = Object.assign({ id }, body);
  const chunks = await store.getChunks(id);
  for (const c of chunks) if ((c.items || []).length) await store.setChunk(id, c.id, { client: clientId, items: [], erased: true, updatedAt: Date.now() });
}
async function deleteCurrentLot(){
  const L = lotsById[currentLot]; if (!L || !S) return;
  const m = L.real ? 'real' : 'sim', id = currentLot, trained = S.model.trained;
  $('loading').hidden = false;
  try {
    const merged = mergeBrain(brains[m], brainOf(S.model, S.occ));
    await store.setBrain(m, merged); brains[m] = merged;
    if (live) stopLive();
    if (unsubChunks) { unsubChunks(); unsubChunks = null; }
    await scrubLot(id, L.real);
    S = null; currentLot = null; mapView = null; chunkDocs = {}; myChunk = null; dirty.clear();
    lsSet('pk-lot-' + mode, '');
    toast(`انحذف الباركنق وموقعه نهائياً، واللي تعلمه من ${trained} جلسة انحفظ للباركنقات الجاية`);
    const next = lotsOfMode()[0];
    if (next) selectLot(next); else { $('loading').hidden = true; applyLotMode(); renderLotSel(); }
  } catch (e) { $('loading').hidden = true; handleWriteError(e); toast('ما قدرت أحذفه، جرّب مرة ثانية'); }
}
// Lots deleted by an older version only had a "deleted" flag: erase their coordinates now.
let scrubbing = false;
async function scrubOldDeletedLots(){
  if (scrubbing || readOnly) return; scrubbing = true;
  try { for (const id of Object.keys(lotsById)) { const L = lotsById[id]; if (L.deleted && (L.cfg || (L.name && L.name !== '(محذوف)'))) await scrubLot(id, L.real); } }
  catch (e) { /* no write access: nothing to do */ }
  scrubbing = false;
}

/* ---------------- lot selection (per device) ---------------- */
let mode = (() => { try { return localStorage.getItem('pk-mode') || 'real'; } catch (e) { return 'real'; } })();
let creatingSim = false;
function lsGet(k){ try { return localStorage.getItem(k); } catch (e) { return null; } }
function lsSet(k, v){ try { localStorage.setItem(k, v); } catch (e) {} }
function lotsOfMode(){ return Object.keys(lotsById).filter(id => !!lotsById[id].real === (mode === 'real') && !lotsById[id].archived && !lotsById[id].deleted).sort((a, b) => (lotsById[b].createdAt || 0) - (lotsById[a].createdAt || 0)); }
function selectLot(id){ lsSet('pk-lot-' + mode, id); switchLot(id); renderLotSel(); applyLotMode(); }
function ensureSelection(){
  if (currentLot && lotsById[currentLot] && !lotsById[currentLot].deleted && !!lotsById[currentLot].real === (mode === 'real')) return;
  if (wantedLot && !lotsById[wantedLot]) return;
  const saved = lsGet('pk-lot-' + mode), list = lotsOfMode();
  const pickId = saved && lotsById[saved] && !lotsById[saved].deleted && !!lotsById[saved].real === (mode === 'real') ? saved : list[0];
  if (pickId) { switchLot(pickId); return; }
  if (mode === 'sim') { if (!creatingSim) { creatingSim = true; createLot(defaults(), 'باركنق تجريبي'); } return; }
  // real mode with no lots: nothing to load
  if (unsubChunks) { unsubChunks(); unsubChunks = null; }
  currentLot = null; $('loading').hidden = true; if (!dirty.size && !flushing) setSave(readOnly ? 'readonly' : 'saved'); applyLotMode(); renderLotSel();
}
function setMode(m){
  if (m === mode) return; mode = m; lsSet('pk-mode', m);
  picking = false; markMode = false; fpMode = false; if (live) stopLive(); wizardOpen = false;
  ensureSelection(); renderLotSel(); applyLotMode();
}

/* ---------------- sessions ---------------- */
function randomKind(){
  const n = S.truth.length, occ = S.truth.filter(o => o).length / n;
  if (Math.random() < 0.72) {
    const pPark = Math.min(0.9, Math.max(0.1, 0.5 + (S.cfg.occ - occ) * 3));
    if (Math.random() < pPark && occ < 1) return Math.random() < 0.2 ? 'cruise' : 'park';
    if (occ > 0) return 'depart';
    return 'park';
  }
  return Math.random() < 0.75 ? 'walker' : 'dropoff';
}
function runSession(kind){
  if (kind === 'random') kind = randomKind();
  let spot = null, dev = null;
  if (kind === 'park' || kind === 'cruise') {
    const free = lot.spots.filter(s => !S.truth[s.idx]); if (!free.length) { toast('كل المواقف مشغولة في المحاكاة'); return null; }
    spot = PE.pick(free); dev = 'sim-' + rid();
  } else if (kind === 'depart') {
    const occ = lot.spots.filter(s => S.truth[s.idx]); if (!occ.length) { toast('ما فيه سيارات واقفة تغادر'); return null; }
    spot = PE.pick(occ); dev = S.devBySpot[spot.id] || null;
  }
  const { path, truth } = PE.simulateTruth(lot, kind, { spot });
  const samples = PE.sense(world, path);
  const sess = { id: 's-' + clientId + '-' + rid(), kind, deviceId: dev, samples, truth, createdAt: Date.now() };
  sess.beliefSnap = curBelief(); sess.devSnap = Object.assign({}, S.model.dev);
  sess.result = PE.analyze(S.model, lot, sess, sess.beliefSnap, S.model.dev);
  return sess;
}
function truthLabel(sess){ const t = sess.truth; return t.type === 'none' ? { type: 'none' } : { type: t.type, spot: t.spot }; }

/* ---------------- auto training ---------------- */
async function autoTrain(){
  if (autoRunning) { autoStop = true; return; }
  if (S.pending && S.pending.truth && !S.pending.fromQueue) finishReview(truthLabel(S.pending));
  else if (S.pending) { toast('راجع الجلسة المفتوحة أولاً'); return; }
  const N = +$('autoN').value; autoRunning = true; autoStop = false;
  $('autoBtn').textContent = 'أوقف'; $('autoProg').hidden = false; setSimDisabled(true);
  for (let i = 0; i < N && !autoStop; i++) {
    const sess = runSession('random'); if (sess) commitLabel(sess, truthLabel(sess));
    $('autoProg').firstElementChild.style.width = ((i + 1) / N * 100) + '%';
    if (i % 5 === 4 || i === N - 1) { renderAll(); await sleep(16); }
  }
  autoRunning = false; scheduleFlush(0);
  $('autoBtn').textContent = 'ابدأ التدريب الآلي'; $('autoProg').hidden = true;
  renderAll(); toast('انتهى التدريب الآلي');
}
function setSimDisabled(d){
  document.querySelectorAll('#simBtns .btn').forEach(b => b.disabled = d || readOnly || !S || !!S.pending);
  $('autoBtn').disabled = readOnly || !S; $('impBtn').disabled = readOnly || !S; $('applyBtn').disabled = readOnly; $('archBtn').disabled = readOnly; $('delBtn').disabled = readOnly; $('liveBtn').disabled = readOnly; $('fpBtn').disabled = readOnly; $('addLotBtn').disabled = readOnly;
}

/* ---------------- settings, backup & import ---------------- */
function readSettings(){
  const num = (id, lo, hi, d) => { const v = parseFloat($(id).value); return isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d; };
  return { rows: Math.round(num('cRows', 1, 8, 4)), perRow: Math.round(num('cPer', 4, 40, 16)), W: num('cW', 2, 4, 2.5), L: num('cL', 4, 7, 5.5), aisle: num('cA', 4, 10, 6.5), margin: 5, occ: +$('cOcc').value, gps: +$('cGps').value, bias: +$('cBias').value, target: +$('cTarget').value, lat0: 24.7136, lon0: 46.6753, rot: 0 };
}
function backupObj(){
  const L = lotsById[currentLot], items = [];
  for (const id in chunkDocs) for (const it of (chunkDocs[id].items || [])) items.push(it);
  return {
    format: 'parking-training-v2', exportedAt: new Date().toISOString(),
    sampleFields: ['gx', 'gy', 'acc', 'speed', 'cadence', 'activity: 0 automotive, 1 walking, 2 still, 3 unknown', 'heading radians from lot x-axis', 'truthX (simulation)', 'truthY (simulation)', 'truthMode: 0 drive, 1 still, 2 walk'],
    lot: { id: currentLot, name: L.name, cfg: L.cfg, world: L.world, init: L.init, createdAt: L.createdAt },
    items, model: S.model
  };
}
async function doImport(){
  const msg = $('ioMsg'); let d;
  try { d = JSON.parse($('ioText').value); } catch (e) { msg.textContent = 'النص مو JSON صحيح. تأكد إنك نسخته كامل.'; return; }
  try {
    if (d && d.format === 'parking-training-v2' && d.lot && Array.isArray(d.items)) {
      const target = d.lot.id;
      if (!lotsById[target]) await store.setLot(target, { name: d.lot.name, cfg: d.lot.cfg, world: d.lot.world, init: d.lot.init, createdAt: d.lot.createdAt || Date.now() });
      let skip = knownKeys;
      if (target !== currentLot) { skip = new Set(); if (lotsById[target]) for (const c of await store.getChunks(target)) for (const it of (c.items || [])) skip.add(keyOf(it)); }
      const items = d.items.filter(it => !skip.has(keyOf(it)));
      await writeItemsAsChunks(target, items);
      if (target !== currentLot) { const isReal = !!(d.lot.cfg && d.lot.cfg.real); if ((mode === 'real') !== isReal) setMode(isReal ? 'real' : 'sim'); selectLot(target); }
      msg.textContent = `تمت الاستعادة: ${items.length} عنصر جديد.`; return;
    }
    if (d && d.model && d.cfg && Array.isArray(d.sessions)) { const n = await migrateV1(d); msg.textContent = `انتقلت ${n} جلسة لباركنق جديد.`; return; }
    if (!d || !Array.isArray(d.sessions)) { msg.textContent = 'ما لقيت "sessions" في النص. راجع الشكل المطلوب فوق.'; return; }
    const items = []; let labeled = 0, queued = 0; const base = Date.now();
    d.sessions.forEach((raw, i) => {
      if (!raw || !Array.isArray(raw.samples) || raw.samples.length < 10) return;
      const it = { k: 's', sid: 's-' + clientId + '-' + rid() + i, kind: 'imported', dev: raw.deviceId || null, at: base + i, smp: pack(PE.importSamples(S.cfg, raw.samples)), truth: null };
      const lb = raw.label;
      if (lb && lb.type && (lb.type === 'none' || lot.byId[lb.spot])) { it.label = lb.type === 'none' ? { type: 'none' } : { type: lb.type, spot: lb.spot }; it.lat = base + i; labeled++; } else queued++;
      items.push(it);
    });
    if (queued) openQueueNext = true;
    await writeItemsAsChunks(currentLot, items);
    msg.textContent = `انضافت ${labeled} جلسة مصححة للتدريب، و${queued} تنتظر المراجعة.`;
  } catch (e) { handleWriteError(e); msg.textContent = 'ما قدرت أحفظ الاستيراد.'; }
}
async function migrateV1(d){
  const sessions = d.sessions.filter(s => s && s.label && Array.isArray(s.samples));
  const first = sessions[0];
  const init = (first && first.beliefSnap ? first.beliefSnap : (d.belief || [])).map(v => v === 'occ' ? 1 : 0);
  const id = 'lot-' + rid(), base = Date.now();
  await store.setLot(id, { name: 'منقول من النسخة السابقة', cfg: Object.assign(defaults(), d.cfg), world: d.world, init, createdAt: base });
  const items = sessions.map((s, i) => ({ k: 's', sid: 'v1-' + rid() + i, kind: s.kind, dev: s.deviceId || null, at: base + i, smp: pack(s.samples), truth: s.truth || null, label: s.label, lat: base + i }));
  await writeItemsAsChunks(id, items);
  if (mode !== 'sim') setMode('sim');
  selectLot(id);
  return items.length;
}

/* ---------------- glue ---------------- */
let toastT;
function toast(t){ const e = $('toast'); e.textContent = t; e.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => e.classList.remove('show'), 2400); }
function renderAll(){ if (!S) return; applyLotMode(); renderMap(); renderTimeline(); renderReview(); renderMetrics(); renderChart(); if (!autoRunning) setSimDisabled(false); }

async function boot(){
  setSave('loading');
  document.querySelectorAll('#simBtns .btn').forEach(b => b.onclick = () => { if (!S || S.pending || readOnly) return; picking = false; const s = runSession(b.dataset.kind); if (s) { S.pending = s; renderAll(); } });
  $('autoBtn').onclick = autoTrain;
  $('replayBtn').onclick = () => { if (S) replay(); };
  ['tTruth', 'tBias', 'tIds'].forEach(id => $(id).onchange = () => { if (S) { renderMap(); renderTimeline(); } });
  $('applyBtn').onclick = () => { $('applyConfirm').hidden = false; };
  $('applyConfirm').onclick = async () => { $('applyConfirm').hidden = true; $('loading').hidden = false; await createLot(readSettings(), ($('cName').value || 'باركنق').slice(0, 60)); toast('انشأ باركنق محاكاة جديد'); };
  $('fpBtn').onclick = () => { if (fpRun) return; fpMode = !fpMode; markMode = false; picking = false; if (!fpMode) fpSel = null; $('fpWarn').textContent = ''; renderAll(); };
  $('fpStart').onclick = startFp;
  $('fpRemove').onclick = () => { if (fpSel) removeFp(fpSel); };
  $('fpManualBtn').onclick = () => { const ll = parseLL($('fpManual').value); if (!ll) { $('fpWarn').textContent = 'اكتب الإحداثيات مثل: 24.71372, 46.67541'; return; } saveFp(fpSel, ll.lat, ll.lon, 0, null); $('fpManual').value = ''; };
  $('liveBtn').onclick = () => { if (live) stopLive(); else startLive(); };
  $('liveMissBtn').onclick = () => { if (!live || live.samples.length < 20) { toast('ما فيه قراءات كافية بعد'); return; } captureLive(live.samples.slice(-120), 'live-manual'); };
  $('showArch').onchange = renderLotSel;
  $('archBtn').onclick = () => { if (lotsById[currentLot] && lotsById[currentLot].archived) archiveCurrent(); else $('archConfirm').hidden = false; };
  $('archConfirm').onclick = () => { $('archConfirm').hidden = true; archiveCurrent(); };
  $('delBtn').onclick = () => { $('delConfirm').hidden = false; $('delNote').hidden = false; };
  $('delConfirm').onclick = () => { $('delConfirm').hidden = true; $('delNote').hidden = true; deleteCurrentLot(); };
  $('lotSel').onchange = () => { if ($('lotSel').value) selectLot($('lotSel').value); };
  document.querySelectorAll('[data-mode]').forEach(b => b.onclick = () => setMode(b.dataset.mode));
  $('addLotBtn').onclick = () => { wizardOpen = !wizardOpen; if (wizardOpen) resetWizard(); applyLotMode(); if (wizardOpen) $('wizard').scrollIntoView({ behavior: 'smooth' }); };
  $('setBtn').onclick = () => { $('setPanel').hidden = !$('setPanel').hidden; };
  document.querySelectorAll('[data-wt]').forEach(b => b.onclick = () => { wiz.type = b.dataset.wt; wiz.p2 = null; renderWizard(); });
  document.querySelectorAll('[data-side]').forEach(b => b.onclick = () => { wiz.side = b.dataset.side; renderWizard(); });
  ['wW', 'wL', 'wPer', 'wRows', 'wAisle'].forEach(id => $(id).addEventListener('input', renderWizard));
  $('wFp1').onclick = () => wizFp(1); $('wFp2').onclick = () => wizFp(2); $('wDir').onclick = wizDir;
  $('wManual').onclick = () => { const a = parseLL($('wM1').value), c = parseLL($('wM2').value); if (!a) { $('wOut').innerHTML = '<div class="note-warn">اكتب الإحداثيات مثل: 24.71372, 46.67541</div>'; return; } wiz.p1 = Object.assign({ n: 0, acc: null }, a); $('wFp1s').textContent = 'من الإحداثيات'; if (c) { wiz.p2 = Object.assign({ n: 0, acc: null }, c); $('wFp2s').textContent = 'من الإحداثيات'; } if (wiz.type === 'one') { wiz.dirTried = true; wiz.dir = null; $('wDirs').textContent = 'بدون اتجاه'; } renderWizard(); };
  $('wAdd').onclick = wizAdd; $('wCancel').onclick = () => { wizardOpen = false; applyLotMode(); };
  $('expBtn').onclick = () => { if (!S) return; $('ioText').value = JSON.stringify(backupObj()); $('ioMsg').textContent = 'انسخ النص واحفظه في ملف.'; };
  $('copyBtn').onclick = async () => { const t = $('ioText'); if (!t.value && S) t.value = JSON.stringify(backupObj()); t.select(); try { await navigator.clipboard.writeText(t.value); $('ioMsg').textContent = 'تم النسخ.'; } catch (e) { $('ioMsg').textContent = 'النص محدد، انسخه يدوياً.'; } };
  $('impBtn').onclick = () => { if (!readOnly) doImport(); };
  $('dlBtn').onclick = async () => {
    if (!S) return;
    const data = JSON.stringify(backupObj());
    const dl = window.claude && window.claude.use ? await window.claude.use('downloads') : null;
    const name = 'parking-training-' + new Date().toISOString().slice(0, 10) + '.json';
    if (!dl) { try { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type: 'application/json' })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000); } catch (e) { $('ioText').value = data; $('ioMsg').textContent = 'انسخ النص واحفظه.'; } return; }
    try { await dl.save({ filename: name, data }); } catch (e) { if (e && e.code !== 'declined') { $('ioText').value = data; $('ioMsg').textContent = 'تعذر التنزيل، النسخة معروضة كنص.'; } }
  };
  try { if (localStorage.getItem('parking-trainer-v1')) $('migRow').hidden = false; } catch (e) {}
  $('migBtn').onclick = async () => { try { const d = JSON.parse(localStorage.getItem('parking-trainer-v1')); const n = await migrateV1(d); toast(`انتقلت ${n} جلسة لقاعدة البيانات`); $('migRow').hidden = true; } catch (e) { handleWriteError(e); toast('ما قدرت أنقل البيانات'); } };
  let rt; window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { if (S) renderChart(); }, 120); });

  readHashCfg();
  const sc = supaCfg();
  if (sc) { $('sUrl').value = sc.url; $('sKey').value = sc.key; $('sTeam').value = sc.team || ''; }
  $('supaBox').hidden = IN_CLAUDE; $('tSatL').hidden = IN_CLAUDE;
  $('tSat').onchange = () => { if (S) renderMap(); };
  $('sSave').onclick = async () => {
    const c = { url: $('sUrl').value.trim(), key: $('sKey').value.trim(), team: $('sTeam').value.trim() };
    if (!/^https:\/\/.+/.test(c.url) || c.key.length < 20) { $('sMsg').textContent = 'تأكد من الرابط والمفتاح.'; return; }
    $('sMsg').textContent = 'جاري الاختبار...';
    try { await makeSupaStore(c).test(); localStorage.setItem('pk-supa', JSON.stringify(c)); $('sMsg').textContent = 'الاتصال شغال. بتنعاد الصفحة.'; setTimeout(() => location.reload(), 800); }
    catch (e) { $('sMsg').textContent = e.code === 'not_granted' ? 'مرفوض: المفتاح أو كود الفريق غلط.' : e.status === 404 ? 'الجدول مو موجود. شغّل setup.sql في Supabase أول.' : 'ما قدرت أتصل: ' + String(e.message || '').slice(0, 120); }
  };
  $('sShare').onclick = async () => {
    const c = supaCfg(); if (!c) { $('sMsg').textContent = 'احفظ الاتصال أول.'; return; }
    const link = location.origin + location.pathname + '#supa=' + encodeURIComponent(btoa(unescape(encodeURIComponent(JSON.stringify(c)))));
    try { await navigator.clipboard.writeText(link); $('sMsg').textContent = 'انسخ الرابط. أرسله للفريق فقط، لأن فيه كود الفريق.'; } catch (e) { $('sMsg').textContent = link; }
  };
  $('sClear').onclick = () => { localStorage.removeItem('pk-supa'); location.reload(); };
  let db = null;
  try { if (IN_CLAUDE) db = await window.claude.use('db'); } catch (e) { db = null; }
  store = db ? makeSharedStore(db) : sc ? makeSupaStore(sc) : makeLocalStore();
  if (!IN_CLAUDE) $('supaState').textContent = sc ? 'متصل. كل البيانات تنحفظ للفريق.' : 'غير متصل: البيانات الحين تنحفظ في هذا الجهاز فقط.';
  setTimeout(() => { if (!lotsLoaded) { $('loading').hidden = true; showNote('تأخر تحميل البيانات. حدّث الصفحة، وإذا استمر تأكد من اتصالك.'); } }, 15000);
  if (!db && !sc) showNote(IN_CLAUDE ? 'قاعدة البيانات المشتركة غير متاحة في هذا العرض، فالبيانات تنحفظ في هذا الجهاز فقط.' : 'البيانات تنحفظ في هذا الجهاز فقط. اربط Supabase من "إعدادات" عشان تنحفظ للفريق.');
  setupMapGestures();
  await loadBrains();
  store.watchLots(list => {
    lotsLoaded = true; lotsById = {}; list.forEach(l => { lotsById[l.id] = l; });
    if (wantedLot && lotsById[wantedLot]) switchLot(wantedLot);
    ensureSelection(); renderLotSel(); applyLotMode();
    scrubOldDeletedLots();
  });
  applyLotMode();
}
window.__pkState = () => S;
boot();
})();
