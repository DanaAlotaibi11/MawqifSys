(function(){
'use strict';
const $ = id => document.getElementById(id);
const KIND_AR = { park: 'سيارة توقف', cruise: 'سيارة تدور ببطء ثم توقف', depart: 'سيارة تغادر', walker: 'شخص يمشي بين المواقف', dropoff: 'إنزال راكب في الممر', imported: 'جلسة مستوردة', live: 'رصد مباشر من الجوال', 'live-manual': 'تسجيل يدوي من الجوال' };
const COL = { free: '#2F9D6A', occ: '#C9463D', unk: '#868C94', D: '#4C9EF5', S: '#E6B52E', W: '#B38AF7', paint: '#ECEAE3', yellow: '#E6B52E' };
const ACTS = ['automotive', 'walking', 'still', 'unknown'], MODES = ['D', 'S', 'W'];
let S = null, lot = null, world = null;
const IN_CLAUDE = !!(window.claude && typeof window.claude.use === 'function');
let picking = false, autoRunning = false, autoStop = false, readOnly = false;
const clone = o => JSON.parse(JSON.stringify(o));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const rid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clientId = (() => { try { let c = localStorage.getItem('pk-client'); if (!c) { c = 'c' + Math.random().toString(36).slice(2, 10); localStorage.setItem('pk-client', c); } return c; } catch (e) { return 'c' + Math.random().toString(36).slice(2, 10); } })();

function defaults(){ return { rows: 4, perRow: 16, W: 2.5, L: 5.5, aisle: 6.5, margin: 5, occ: 0.5, gps: 2.2, bias: 2, target: 0.98, lat0: 24.7136, lon0: 46.6753, rot: 0 }; }
function pack(samples){ return samples.map(s => { const a = [s.gx, s.gy, s.acc, s.speed, s.cad, Math.max(0, ACTS.indexOf(s.act)), (s.hdg === null || s.hdg === undefined) ? null : Math.round(s.hdg * 1000) / 1000, Math.round((s.vib || 0) * 100) / 100]; if (s._x !== undefined) a.push(s._x, s._y, MODES.indexOf(s._m)); return a; }); }
function unpack(rows){ return rows.map((r, t) => { const v8 = r.length === 8 || r.length === 11, o = { t, gx: r[0], gy: r[1], acc: r[2], speed: r[3], cad: r[4], act: ACTS[r[5]] || 'unknown', hdg: r[6] === undefined ? null : r[6], vib: v8 ? r[7] : 0 }; const b = v8 ? 8 : 7; if (r.length > b) { o._x = r[b]; o._y = r[b + 1]; o._m = MODES[r[b + 2]]; } return o; }); }
