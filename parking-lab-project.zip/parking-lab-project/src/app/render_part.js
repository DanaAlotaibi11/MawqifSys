/* ---------------- map ---------------- */
const NS = 'http://www.w3.org/2000/svg';
function el(tag, attrs, parent){ const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; }
function renderMap(){
  const svg = $('map'); svg.innerHTML = ''; svg.setAttribute('direction', 'ltr');
  const H = lot.height, Wd = lot.width, sat = satOn(), real = !!(S.cfg && S.cfg.real);
  const pad = real ? GEOFENCE_MARGIN + 4 : sat ? 8 : 2;
  if (!mapView || mapView.lot !== S.lotId) mapView = { lot: S.lotId, x: -pad, y: -pad, w: Wd + pad * 2, h: H + pad * 2, home: { x: -pad, y: -pad, w: Wd + pad * 2, h: H + pad * 2 } };
  svg.setAttribute('viewBox', `${mapView.x} ${mapView.y} ${mapView.w} ${mapView.h}`);
  svg.classList.toggle('picking', picking || fpMode || !!(S.cfg && S.cfg.real));
  const Y = y => H - y;
  el('rect', { x: 0, y: 0, width: Wd, height: H, fill: 'transparent' }, svg);
  $('satAttr').hidden = !sat;
  if (sat) drawSatellite(svg, Wd, H, pad, Y);
  if (real) { // detection boundary (geofence) around the lot
    const M = GEOFENCE_MARGIN, inside = live && live.geo && live.geo.stable === 'IN';
    el('rect', { x: -M, y: -M, width: Wd + 2 * M, height: H + 2 * M, fill: inside ? '#2F9D6A' : 'none', 'fill-opacity': 0.06, stroke: inside ? '#3DB57D' : COL.yellow, 'stroke-width': 0.35, 'stroke-dasharray': '1.6 1', rx: 1 }, svg);
    el('text', { x: -M + 1, y: -M + 2.2, 'font-size': 1.6, fill: inside ? '#3DB57D' : COL.yellow, 'font-family': 'IBM Plex Sans Arabic, sans-serif' }, svg).textContent = inside ? 'حدود الرصد: داخل' : 'حدود الرصد';
  }
  // aisle centre dashes
  for (const a of lot.aisles) el('line', { x1: 1, x2: Wd - 1, y1: Y((a.y0 + a.y1) / 2), y2: Y((a.y0 + a.y1) / 2), stroke: COL.yellow, 'stroke-width': 0.18, 'stroke-dasharray': '2.2 1.6', opacity: 0.55 }, svg);
  const sess = S.pending; const r = sess && sess.result;
  const probs = {}; if (r && r.post) r.post.forEach(p => { probs[p.id] = p.p; });
  const nowT = Date.now();
  const gSpots = el('g', {}, svg);
  for (const s of lot.spots) {
    const pr = occProb(S.occ, s.idx, nowT), st = predOf(pr), cf = Math.max(pr.p, 1 - pr.p);
    const g = el('g', { class: 'spot', 'data-id': s.id }, gSpots);
    const fill = st === 'free' ? COL.free : st === 'occ' ? COL.occ : COL.unk;
    el('rect', { class: 'base', x: s.x0, y: Y(s.y1), width: s.x1 - s.x0, height: s.y1 - s.y0, fill, 'fill-opacity': st === 'free' ? 0.12 + 0.25 * (cf - 0.5) * 2 : 0.16, stroke: COL.paint, 'stroke-width': 0.12 }, g);
    if (S.ask && S.ask.spot === s.id) el('rect', { x: s.x0 + 0.05, y: Y(s.y1) + 0.05, width: s.x1 - s.x0 - 0.1, height: s.y1 - s.y0 - 0.1, fill: 'none', stroke: '#fff', 'stroke-width': 0.45, 'stroke-dasharray': '0.7 0.4' }, g);
    if (st === 'occ') {
      const w = (s.x1 - s.x0) - 0.7, l = (s.y1 - s.y0) - 1.0;
      el('rect', { x: s.cx - w / 2, y: Y(s.cy) - l / 2, width: w, height: l, rx: 0.55, fill: COL.occ, 'fill-opacity': 0.35 + 0.55 * (cf - 0.5) * 2 }, g);
      const wy = s.dir === 1 ? Y(s.cy) - l / 2 + 0.6 : Y(s.cy) + l / 2 - 1.5; // windscreen towards the aisle? front faces into the spot
      el('rect', { x: s.cx - w / 2 + 0.3, y: wy, width: w - 0.6, height: 0.9, rx: 0.25, fill: '#000', 'fill-opacity': 0.28 }, g);
    }
    if ($('tIds').checked) el('text', { x: s.cx, y: Y(s.dir === 1 ? s.y0 + 0.9 : s.y1 - 0.9) + 0.3, 'text-anchor': 'middle', 'font-size': 0.78, fill: COL.paint, 'fill-opacity': 0.6, 'font-family': 'IBM Plex Sans Arabic, sans-serif' }, g).textContent = s.id;
    const p = probs[s.id];
    if (p !== undefined && p > 0.02) {
      el('rect', { x: s.x0 + 0.1, y: Y(s.y1) + 0.1, width: s.x1 - s.x0 - 0.2, height: s.y1 - s.y0 - 0.2, fill: 'none', stroke: COL.yellow, 'stroke-width': 0.12 + p * 0.45, rx: 0.2 }, g);
      el('text', { x: s.cx, y: Y(s.cy) + (s.col % 2 ? -1.1 : 1.6), 'text-anchor': 'middle', 'font-size': 0.9, 'font-weight': 700, fill: '#fff', stroke: '#000', 'stroke-width': 0.22, 'paint-order': 'stroke' }, g).textContent = Math.round(p * 100) + '%';
    }
    g.addEventListener('click', () => { if (mapDragged) return; if (picking) pickSpot(s.id); else if (fpMode) selectFpSpot(s.id); else if (S.cfg.real && !S.pending) askSpot(s.id, 'tap'); });
    if (fpMode && fpSel === s.id) el('rect', { x: s.x0 + 0.05, y: Y(s.y1) + 0.05, width: s.x1 - s.x0 - 0.1, height: s.y1 - s.y0 - 0.1, fill: 'none', stroke: '#fff', 'stroke-width': 0.4 }, g);
  }
  // learned correction arrows
  if ($('tBias').checked) {
    const gb = el('g', {}, svg);
    for (let x = 4; x < Wd; x += 7) for (let y = 3; y < H; y += 7) {
      const c = PE.correction(S.model, x, y);
      if (Math.hypot(c.x, c.y) > 0.15) arrow(gb, x, Y(y), x + c.x * 1.4, Y(y + c.y * 1.4), COL.yellow, 0.22);
      if ($('tTruth').checked && S.world) { const b = PE.trueBias(world, x, y); arrow(gb, x, Y(y), x + b.x * 1.4, Y(y + b.y * 1.4), '#ffffff', 0.12, 0.55); }
    }
  }
  if (S.fps) for (const id in S.fps) {
    const f = S.fps[id], s = lot.byId[id]; if (!s) continue;
    el('line', { x1: s.cx, y1: Y(s.cy), x2: f.x, y2: Y(f.y), stroke: COL.yellow, 'stroke-width': 0.1, opacity: 0.8 }, svg);
    el('circle', { cx: f.x, cy: Y(f.y), r: 0.55, fill: 'none', stroke: COL.yellow, 'stroke-width': 0.22 }, svg);
    el('circle', { cx: f.x, cy: Y(f.y), r: 0.15, fill: COL.yellow }, svg);
  }
  if (!sess && live && live.samples.length) {
    const tail = live.samples.slice(-60), labs = (live.labels || []).slice(-tail.length);
    tail.forEach((s, i) => el('circle', { cx: s.gx, cy: Y(s.gy), r: 0.38, fill: COL[labs[i]] || '#999', 'fill-opacity': 0.35 + 0.6 * i / tail.length }, svg));
    const c = tail[tail.length - 1];
    el('circle', { cx: c.gx, cy: Y(c.gy), r: Math.min(15, c.acc || 5), fill: '#4C9EF5', 'fill-opacity': 0.12, stroke: '#4C9EF5', 'stroke-width': 0.12 }, svg);
    el('circle', { cx: c.gx, cy: Y(c.gy), r: 0.7, fill: '#fff', stroke: '#4C9EF5', 'stroke-width': 0.3 }, svg);
  }
  if (sess) {
    const smp = sess.samples, labels = r.labels;
    if ($('tTruth').checked && smp[0]._x !== undefined) {
      el('polyline', { points: smp.map(s => `${s._x},${Y(s._y)}`).join(' '), fill: 'none', stroke: '#fff', 'stroke-width': 0.18, 'stroke-dasharray': '0.6 0.5', opacity: 0.8 }, svg);
      const t = sess.truth; if (t && t.spot) { const s = lot.byId[t.spot]; el('rect', { x: s.x0 - 0.25, y: Y(s.y1) - 0.25, width: s.x1 - s.x0 + 0.5, height: s.y1 - s.y0 + 0.5, fill: 'none', stroke: '#fff', 'stroke-width': 0.3, 'stroke-dasharray': '0.8 0.5', rx: 0.3 }, svg); }
    }
    el('polyline', { points: smp.map(s => `${s.gx},${Y(s.gy)}`).join(' '), fill: 'none', stroke: '#fff', 'stroke-width': 0.08, opacity: 0.35 }, svg);
    smp.forEach((s, i) => el('circle', { cx: s.gx, cy: Y(s.gy), r: 0.42, fill: COL[labels[i]] || '#999', 'fill-opacity': 0.9 }, svg));
    if (r.est) {
      const ex = r.est.x, ey = Y(r.est.y);
      el('circle', { cx: ex, cy: ey, r: r.sigma * 2, fill: 'none', stroke: COL.yellow, 'stroke-width': 0.15, 'stroke-dasharray': '0.7 0.5' }, svg);
      el('circle', { cx: ex, cy: ey, r: r.sigma, fill: COL.yellow, 'fill-opacity': 0.14, stroke: COL.yellow, 'stroke-width': 0.2 }, svg);
      el('path', { d: `M${ex - 1.1},${ey}H${ex + 1.1}M${ex},${ey - 1.1}V${ey + 1.1}`, stroke: '#fff', 'stroke-width': 0.3 }, svg);
      if (r.heading !== null && r.heading !== undefined && !r.bMissing) arrow(svg, ex, ey, ex + Math.cos(r.heading) * 3.2, ey - Math.sin(r.heading) * 3.2, '#fff', 0.25);
    }
  }
}
function satOn(){ return !IN_CLAUDE && S && S.cfg && S.cfg.real && $('tSat').checked; }
function drawSatellite(svg, Wd, H, pad, Y){
  const cfg = S.cfg, corners = [[-pad, -pad], [Wd + pad, -pad], [-pad, H + pad], [Wd + pad, H + pad]].map(([x, y]) => PE.localToGeo(cfg, x, y));
  const lats = corners.map(c => c.lat), lons = corners.map(c => c.lon);
  let z = 19;
  const tx = (lon, zz) => (lon + 180) / 360 * Math.pow(2, zz);
  const ty = (lat, zz) => { const r = lat * Math.PI / 180; return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * Math.pow(2, zz); };
  const lonOf = (x, zz) => x / Math.pow(2, zz) * 360 - 180;
  const latOf = (y, zz) => { const n = Math.PI - 2 * Math.PI * y / Math.pow(2, zz); return 180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))); };
  let x0, x1, y0, y1;
  for (; z >= 16; z--) { x0 = Math.floor(tx(Math.min(...lons), z)); x1 = Math.floor(tx(Math.max(...lons), z)); y0 = Math.floor(ty(Math.max(...lats), z)); y1 = Math.floor(ty(Math.min(...lats), z)); if ((x1 - x0 + 1) * (y1 - y0 + 1) <= 36) break; }
  const g = el('g', { opacity: 0.85 }, svg);
  const toSvg = (lat, lon) => { const p = PE.geoToLocal(cfg, lat, lon); return { x: p.x, y: Y(p.y) }; };
  for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) {
    const nw = toSvg(latOf(y, z), lonOf(x, z)), ne = toSvg(latOf(y, z), lonOf(x + 1, z)), sw = toSvg(latOf(y + 1, z), lonOf(x, z));
    const m = [(ne.x - nw.x) / 256, (ne.y - nw.y) / 256, (sw.x - nw.x) / 256, (sw.y - nw.y) / 256, nw.x, nw.y].map(v => v.toFixed(5)).join(' ');
    el('image', { href: `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`, width: 256.6, height: 256.6, transform: `matrix(${m})`, preserveAspectRatio: 'none' }, g);
  }
  el('rect', { x: -pad, y: -pad, width: Wd + 2 * pad, height: H + 2 * pad, fill: '#000', opacity: 0.18 }, svg);
}
function arrow(parent, x1, y1, x2, y2, color, w, op){
  const g = el('g', { opacity: op || 1 }, parent);
  el('line', { x1, y1, x2, y2, stroke: color, 'stroke-width': w, 'stroke-linecap': 'round' }, g);
  const a = Math.atan2(y2 - y1, x2 - x1), h = 0.55 + w;
  el('path', { d: `M${x2},${y2}L${x2 - h * Math.cos(a - 0.5)},${y2 - h * Math.sin(a - 0.5)}L${x2 - h * Math.cos(a + 0.5)},${y2 - h * Math.sin(a + 0.5)}Z`, fill: color }, g);
}
function renderTimeline(){
  const svg = $('timeline'); svg.innerHTML = '';
  const sess = S.pending;
  svg.setAttribute('viewBox', '0 0 100 54');
  if (!sess) { el('rect', { x: 0, y: 8, width: 100, height: 18, fill: '#fff', 'fill-opacity': 0.06, rx: 1 }, svg); return; }
  const n = sess.samples.length, w = 100 / n, r = sess.result;
  r.labels.forEach((l, i) => el('rect', { x: i * w, y: 8, width: w + 0.05, height: 18, fill: COL[l] }, svg));
  if (sess.samples[0]._m) sess.samples.forEach((s, i) => el('rect', { x: i * w, y: 28, width: w + 0.05, height: 4, fill: COL[s._m], opacity: $('tTruth').checked ? 0.9 : 0 }, svg));
  el('polyline', { points: r.pD.map((p, i) => `${(i + 0.5) * w},${48 - p * 12}`).join(' '), fill: 'none', stroke: '#fff', 'stroke-width': 0.6, 'vector-effect': 'non-scaling-stroke', opacity: 0.85 }, svg);
  el('line', { x1: 0, x2: 100, y1: 42, y2: 42, stroke: '#fff', 'stroke-width': 0.5, 'vector-effect': 'non-scaling-stroke', opacity: 0.2 }, svg);
  $('tlInfo').textContent = $('tTruth').checked && sess.samples[0]._m ? 'الشريط العلوي تصنيف النظام، والرفيع تحته الحقيقة' : 'تصنيف كل ثانية: قيادة، توقف، مشي، والخط يوضح احتمال القيادة';
}

/* ---------------- review panel ---------------- */
function pct(x){ return Math.round(x * 100) + '%'; }
function spotName(id){ return id === 'none' ? 'خارج المواقف' : id; }
function renderReview(){
  const box = $('review'); const sess = S.pending;
  if (!sess && S.ask && S.ask.kind === 'exit') {
    box.innerHTML = `<h2>طلعت بالسيارة؟</h2>
      <div class="verdict"><div class="kind">طلعت من حدود الباركنق وأنت سايق</div>
      <div class="small muted" style="margin-top:6px">آخر مرة وقفت في <b>${S.ask.spot}</b>. يعني صار فاضي؟</div></div>
      <div class="row" style="margin-top:12px"><button class="btn good" id="qFreeX">إيه، طلعت منه</button><button class="btn ghost" id="qKeepX">لا، سيارتي باقية</button></div>`;
    $('qFreeX').onclick = () => answerAsk('free');
    $('qKeepX').onclick = () => { S.ask = null; renderAll(); };
    return;
  }
  if (!sess && S.ask) {
    const pr0 = occProb(S.occ, lot.byId[S.ask.spot].idx, Date.now());
    Object.assign(S.ask, { p: pr0.p, pred: predOf(pr0), last: pr0.last, age: pr0.age, base: pr0.base });
    const a = S.ask, sure = a.pred !== 'unk', conf = Math.round(Math.max(a.p, 1 - a.p) * 100);
    const info = a.last ? `آخر معلومة: ${ST_AR[a.last]} قبل ${ageAr(a.age)}` : `ما عندي معلومة عنه، نسبة الإشغال المتوقعة ${Math.round(a.base * 100)}%`;
    box.innerHTML = `<h2>تحقق من توقعي</h2>
      <div class="verdict"><div class="row" style="justify-content:space-between"><span class="kind">الموقف ${a.why === 'near' ? 'اللي جنبك' : ''}</span><span class="big">${a.spot}</span></div>
      <div style="margin-top:8px;font-size:18px;font-weight:700">${sure ? `توقعي: ${ST_AR[a.pred]} <span class="muted small">(ثقة ${conf}%)</span>` : 'مو متأكد من حالته'}</div>
      <div class="small muted" style="margin-top:4px">${info}</div></div>
      <div class="row" style="margin-top:12px">${sure ? `<button class="btn good" id="qOk">صح</button><button class="btn bad" id="qNo">خطأ</button>` : `<button class="btn" id="qOcc">مشغول</button><button class="btn" id="qFree">فاضي</button>`}<button class="btn ghost" id="qSkip">تخطي</button></div>`;
    const flip = a.pred === 'occ' ? 'free' : 'occ';
    const on2 = (id, fn) => { const b = $(id); if (b) b.onclick = fn; };
    on2('qOk', () => answerAsk(a.pred)); on2('qNo', () => answerAsk(flip)); on2('qOcc', () => answerAsk('occ')); on2('qFree', () => answerAsk('free'));
    on2('qSkip', () => { S.ask = null; renderAll(); });
    return;
  }
  if (!sess && S.lastExplain) {
    const x = S.lastExplain, good = x.kind === 'status' ? x.ok : x.okx;
    box.innerHTML = `<h2>المراجعة</h2>
      <div class="verdict" style="border-color:${good === false ? 'var(--bad)' : good ? 'var(--good)' : 'var(--line)'}">
        <div class="kind">${good === false ? '✗ ' : good ? '✓ ' : ''}${x.title}</div>
        <div class="small" style="margin-top:6px"><b>${good === false ? 'ليش غلطت:' : 'التحليل:'}</b> ${x.why}</div>
        ${x.learned ? `<div class="small" style="margin-top:6px"><b>وش تعلمت:</b> ${x.learned}</div>` : ''}
      </div>
      <p class="small muted" style="margin:8px 0 0">${S.cfg.real ? 'اضغط أي موقف في الخريطة عشان تتحقق منه، أو كمل الاستشعار.' : 'شغّل جلسة ثانية.'}</p>`;
    return;
  }
  if (!sess) {
    box.innerHTML = `<h2>المراجعة</h2><p class="muted" style="margin:0">${S.cfg.real ? 'لما النظام يرصد وقوف أو مغادرة، أو توقفت جنب موقف، يسألك هنا صح أو خطأ. وتقدر تضغط أي موقف في الخريطة وتتحقق منه.' : 'شغّل جلسة من الأزرار تحت، وبيظهر هنا قرار النظام عشان تأكده أو تصححه.'}${S.queue.length ? ' عندك ' + S.queue.length + ' جلسة مستوردة تنتظر.' : ''}</p>${S.queue.length ? '<div class="row" style="margin-top:10px"><button class="btn primary" id="nextQ">راجع الجلسة التالية</button></div>' : ''}`;
    const nq = $('nextQ'); if (nq) nq.onclick = () => { openNext(); };
    return;
  }
  const r = sess.result; const isSim = !!sess.truth;
  let head, body = '';
  if (!r.event) {
    head = `<div class="kind">ما رُصد وقوف ولا مغادرة</div><p class="small muted" style="margin:6px 0 0">الحركة ما تطابق نمط قيادة ثم توقف ثم مشي أو العكس، فما تغيّر أي موقف.</p>`;
  } else {
    const typ = r.event === 'park' ? 'رُصد وقوف' : 'رُصدت مغادرة';
    const tag = r.auto ? `<span class="tag auto">قرار تلقائي</span>` : `<span class="tag ask">غير متأكد، يحتاج تأكيدك</span>`;
    head = `<div class="row" style="justify-content:space-between"><span class="kind">${typ}</span>${tag}</div>
      <div style="margin-top:6px">${r.decision === 'none' ? '<span class="big" style="direction:rtl">خارج المواقف</span><p class="small muted" style="margin:4px 0 0">يرجّح النظام إنه توقف مؤقت أو إنزال راكب، فما غيّر أي موقف.</p>' : `<span class="muted small">الموقف </span><span class="big">${r.decision}</span>`}
      <span class="muted small" style="margin-inline-start:10px">ثقة ${pct(r.conf)} والحد ${pct(S.model.tau)}</span></div>`;
    const cl = picking ? ' clickable' : '';
    body += `<div class="cands">${r.post.filter(p => p.p > 0.005).slice(0, 4).map(p => `<button class="cand${cl}" data-id="${p.id}" ${picking ? '' : 'tabindex="-1"'}><span class="id">${spotName(p.id)}</span><span class="bar"><i style="width:${Math.max(2, p.p * 100)}%"></i></span><span>${pct(p.p)}</span></button>`).join('')}</div>`;
    const dir = r.heading === null || r.heading === undefined ? 'غير متاح' : (Math.abs(Math.sin(r.heading)) > 0.7 ? 'دخل الموقف من الممر' : 'على طول الممر');
    body += `<div class="facts">
      <div><span>مدة التوقف</span><b>${r.dwell} ثانية</b></div>
      <div><span>اتجاه السيارة</span><b>${dir}</b></div>
      <div><span>الخطأ المتوقع للتقدير</span><b>${r.sigma.toFixed(1)} م</b></div>
      <div><span>الفرق بين مصدري التقدير</span><b>${r.bMissing ? 'مصدر واحد (الاتجاه غير متاح)' : Math.hypot(r.estA.x - r.estB.x, r.estA.y - r.estB.y).toFixed(1) + ' م'}</b></div>
      ${r.known ? `<div style="grid-column:1/-1"><span>معلومة سابقة</span><b>هذا الجهاز أكّد وقوفه في ${r.known}</b></div>` : ''}
    </div>`;
  }
  let actions;
  if (picking) {
    actions = `<div class="hint" style="color:var(--ink)">اضغط على الموقف الصحيح في الخريطة أو من القائمة.</div>
      <div class="row" style="margin-top:8px"><button class="btn" id="aNone">ما كان وقوف ولا مغادرة</button><button class="btn ghost" id="aCancel">إلغاء</button></div>`;
  } else {
    actions = `<div class="row" style="margin-top:12px"><button class="btn good" id="aOk">صحيح</button><button class="btn bad" id="aWrong">خطأ، بحدد الصح</button></div>
      ${isSim ? `<div class="row" style="margin-top:8px"><button class="btn ghost small" id="aTruth">صحّح من الحقيقة</button></div>` : ''}`;
  }
  box.innerHTML = `<h2>المراجعة</h2><div class="small muted" style="margin:-4px 0 8px">${KIND_AR[sess.kind] || ''}</div><div class="verdict">${head}${body}</div>${actions}`;
  const on = (id, fn) => { const b = $(id); if (b) b.onclick = fn; };
  on('aOk', () => { const lab = confirmLabel(sess); finishReview(lab); });
  on('aWrong', () => { picking = true; renderAll(); });
  on('aCancel', () => { picking = false; renderAll(); });
  on('aNone', () => { picking = false; finishReview({ type: 'none' }); });
  on('aTruth', () => { finishReview(truthLabel(sess)); });
  box.querySelectorAll('.cand').forEach(b => b.onclick = () => { if (!picking) return; const id = b.dataset.id; if (id === 'none') { picking = false; finishReview({ type: 'none' }); } else pickSpot(id); });
}
function confirmLabel(sess){ const r = sess.result; if (!r.event || r.decision === 'none') return { type: 'none' }; return { type: r.event, spot: r.decision }; }
function pickSpot(id){
  const sess = S.pending; if (!sess) return;
  const r = sess.result; const s = lot.byId[id];
  const type = r.event || (curBelief()[s.idx] === 'occ' ? 'depart' : 'park');
  picking = false; finishReview({ type, spot: id });
}
function finishReview(label){
  const sess = S.pending; if (!sess) return;
  const ok = sess.result.event ? (label.type === 'none' ? sess.result.decision === 'none' : sess.result.decision === label.spot) : label.type === 'none';
  commitLabel(sess, label);
  S.pending = null;
  toast(ok ? 'تم التأكيد، والنظام تعلّم منها' : 'تم التصحيح، والنظام تعلّم من الخطأ');
  if (S.queue.length) openNext(); else renderAll();
}
function openNext(){
  const it = S.queue.shift(); if (!it) { renderAll(); return; }
  const q = itemToSess(it); q.fromQueue = true;
  q.beliefSnap = curBelief(); q.devSnap = Object.assign({}, S.model.dev);
  q.result = PE.analyze(S.model, lot, q, q.beliefSnap, S.model.dev);
  S.pending = q; S.lastExplain = null; renderAll();
}

/* ---------------- metrics & chart ---------------- */
function summarize(recs){
  const ev = recs.filter(r => r.event), au = ev.filter(r => r.auto);
  return {
    autoAcc: au.length ? au.filter(r => r.ok).length / au.length : null,
    autoRate: ev.length ? au.length / ev.length : null,
    topAcc: ev.length ? ev.filter(r => r.ok).length / ev.length : null,
    ped: recs.filter(r => r.lt === 'none' && r.auto && r.dec && r.dec !== 'none').length,
    walkers: recs.filter(r => r.kind === 'walker').length,
    walkersClean: recs.filter(r => r.kind === 'walker' && !r.event).length,
    missed: recs.filter(r => (r.lt === 'park' || r.lt === 'depart') && (!r.event || r.dec === 'none')).length,
    autoWrong: au.filter(r => !r.ok).length, n: recs.length, nev: ev.length, nau: au.length
  };
}
function fmt(v){ return v === null ? '—' : Math.round(v * 100) + '%'; }
function renderLog(){
  const all = S.records.filter(x => x.title).concat(S.status).sort((a, b) => (b.at || 0) - (a.at || 0)).slice(0, 25);
  $('logBox').innerHTML = all.length ? all.map(x => { const good = x.kind === 'status' ? x.ok : x.okx; return `<div class="logrow ${good === false ? 'bad' : good ? 'good' : ''}"><div class="lt">${good === false ? '✗' : good ? '✓' : '•'} ${x.title}</div><div class="small">${x.why}</div>${x.learned ? `<div class="small muted">تعلّم: ${x.learned}</div>` : ''}</div>`; }).join('') : '<p class="small muted" style="margin:0">كل تأكيد أو تصحيح منك يظهر هنا مع سببه ووش تعلّم منه النظام.</p>';
}
function renderMetrics(){
  renderLog();
  const st = S.status.slice(-30), stSure = st.filter(x => x.ok !== null), stOk = stSure.filter(x => x.ok).length;
  const none = !S.records.length && !S.status.length;
  $('hTau').parentElement.hidden = none; $('hSigma').parentElement.hidden = none;
  if (none) { $('metrics').innerHTML = `<p class="muted" style="grid-column:1/-1;margin:0">${S.cfg.real ? 'ما فيه أرقام بعد. الأرقام تبدأ من أول جلسة تأكدها أو تصححها.' : 'ما فيه أرقام بعد. شغّل جلسة محاكاة.'}</p>`; $('hTrained').textContent = 0; return; }
  const recent = summarize(S.records.slice(-50)), all = summarize(S.records);
  const sg = PE.sigmas(S.model);
  const cards = [
    [stSure.length ? Math.round(stOk / stSure.length * 100) + '%' : '—', 'توقع حالة المواقف', `آخر ${st.length} تحقق، ${st.length - stSure.length} ما كان متأكد`],
    [fmt(recent.autoAcc), 'دقة القرارات التلقائية', `آخر 50 جلسة، ${recent.autoWrong} خطأ من ${recent.nau}`],
    [fmt(recent.autoRate), 'حُسمت تلقائياً', 'والباقي طلب تأكيدك'],
    [fmt(recent.topAcc), 'الاختيار الأول صحيح', 'حتى لما طلب التأكيد'],
    [String(all.ped), 'مشاة لوّنوا مواقف', `من ${all.walkers} جلسة مشي منذ البداية`],
    [String(all.missed), 'وقوف أو مغادرة فاتت', `من ${all.n} جلسة`],
    [sg.F.toFixed(1) + ' م', 'خطأ تحديد مكان السيارة', 'بعد تصحيح الانحراف المتعلَّم']
  ];
  $('metrics').innerHTML = cards.map(c => `<div class="metric"><span class="v">${c[0]}</span><div class="l">${c[1]}</div><div class="s">${c[2]}</div></div>`).join('');
  $('hTrained').textContent = S.model.trained;
  $('hTau').textContent = pct(S.model.tau);
  $('hSigma').textContent = sg.F.toFixed(1) + ' م';
}
function renderChart(){
  const svg = $('chart'); svg.innerHTML = '';
  const Wd = svg.clientWidth || 600, H = 210, padL = 36, padR = 10, padT = 10, padB = 24;
  svg.setAttribute('viewBox', `0 0 ${Wd} ${H}`);
  const cs = getComputedStyle(document.documentElement);
  const ink2 = cs.getPropertyValue('--ink2').trim(), line = cs.getPropertyValue('--line').trim(), good = cs.getPropertyValue('--good').trim(), acc = cs.getPropertyValue('--accent').trim();
  const ev = S.records.filter(r => r.event);
  const X = i => padL + (ev.length > 1 ? i / (ev.length - 1) : 0.5) * (Wd - padL - padR), Yv = v => padT + (1 - v) * (H - padT - padB);
  [0, 0.5, 1].forEach(v => { el('line', { x1: padL, x2: Wd - padR, y1: Yv(v), y2: Yv(v), stroke: line, 'stroke-width': 1 }, svg); el('text', { x: padL - 6, y: Yv(v) + 4, 'text-anchor': 'end', 'font-size': 11, fill: ink2 }, svg).textContent = (v * 100) + '%'; });
  if (ev.length < 3) { el('text', { x: Wd / 2, y: H / 2, 'text-anchor': 'middle', 'font-size': 13, fill: ink2, direction: 'rtl' }, svg).textContent = S.cfg.real ? 'المنحنى يظهر بعد كم جلسة مؤكدة' : 'شغّل التدريب الآلي عشان يظهر المنحنى'; return; }
  const acc1 = [], rate = [];
  for (let i = 0; i < ev.length; i++) {
    const w = ev.slice(Math.max(0, i - 19), i + 1), au = w.filter(r => r.auto);
    rate.push(au.length / w.length); acc1.push(au.length ? au.filter(r => r.ok).length / au.length : null);
  }
  const pathOf = arr => { let d = '', pen = false; arr.forEach((v, i) => { if (v === null) { pen = false; return; } d += (pen ? 'L' : 'M') + X(i).toFixed(1) + ',' + Yv(v).toFixed(1); pen = true; }); return d; };
  el('path', { d: pathOf(rate), fill: 'none', stroke: acc, 'stroke-width': 2.2, 'stroke-linejoin': 'round' }, svg);
  el('path', { d: pathOf(acc1), fill: 'none', stroke: good, 'stroke-width': 2.2, 'stroke-linejoin': 'round' }, svg);
  el('text', { x: padL, y: H - 6, 'font-size': 11, fill: ink2 }, svg).textContent = '1';
  el('text', { x: Wd - padR, y: H - 6, 'text-anchor': 'end', 'font-size': 11, fill: ink2 }, svg).textContent = ev.length + ' حدث';
}

/* ---------------- replay ---------------- */
function replay(){
  const sessions = S.sessions.filter(s => s.label);
  if (!sessions.length) { $('replayOut').innerHTML = '<p class="small muted">ما فيه جلسات مسجلة بعد. شغّل وراجع بعض الجلسات أولاً.</p>'; return; }
  const fresh = PE.freshModel(); fresh.P.target = S.cfg.target;
  const run = (m, loo) => sessions.map(s => {
    const r = PE.analyze(m, lot, s, s.beliefSnap, s.devSnap || {}, loo ? s.id : undefined);
    const tid = s.label.type === 'none' ? 'none' : s.label.spot;
    return { kind: s.kind, lt: s.label.type, event: r.event, dec: r.decision || null, auto: !!(r.event && r.auto), ok: r.event ? r.decision === tid : s.label.type === 'none' };
  });
  const a = summarize(run(fresh, false)), b = summarize(run(S.model, true));
  const row = (name, x, y) => `<tr><td>${name}</td><td class="num">${x}</td><td class="num">${y}</td></tr>`;
  $('replayOut').innerHTML = `<table><thead><tr><th>على ${sessions.length} جلسة</th><th class="num">الأولي</th><th class="num">الحالي</th></tr></thead><tbody>
    ${row('دقة القرارات التلقائية', fmt(a.autoAcc), fmt(b.autoAcc))}
    ${row('حُسمت تلقائياً', fmt(a.autoRate), fmt(b.autoRate))}
    ${row('الاختيار الأول صحيح', fmt(a.topAcc), fmt(b.topAcc))}
    ${row('أخطاء تلقائية', a.autoWrong, b.autoWrong)}
    ${row('مشاة لوّنوا مواقف', a.ped, b.ped)}
    ${row('أحداث فاتت', a.missed, b.missed)}
  </tbody></table>`;
}

