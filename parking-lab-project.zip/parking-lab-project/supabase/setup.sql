-- مختبر دقة المواقف: جدول واحد، بدون حذف
-- قبل التشغيل: غيّر CHANGE_ME تحت إلى كود الفريق (نفس الكود اللي تكتبه في الصفحة)

create table if not exists public.pk_docs (
  path text primary key,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
create index if not exists pk_docs_updated on public.pk_docs (updated_at);

create or replace function public.pk_touch() returns trigger language plpgsql as $$
begin new.updated_at = clock_timestamp(); return new; end $$;
drop trigger if exists pk_touch on public.pk_docs;
create trigger pk_touch before insert or update on public.pk_docs
  for each row execute function public.pk_touch();

create or replace function public.pk_team_ok() returns boolean language sql stable as $$
  select coalesce(current_setting('request.headers', true)::json->>'x-team-key', '') = 'CHANGE_ME'
$$;

alter table public.pk_docs enable row level security;
grant select, insert, update on public.pk_docs to anon;

drop policy if exists pk_read on public.pk_docs;
create policy pk_read on public.pk_docs for select to anon using (public.pk_team_ok());
drop policy if exists pk_ins on public.pk_docs;
create policy pk_ins on public.pk_docs for insert to anon with check (public.pk_team_ok());
drop policy if exists pk_upd on public.pk_docs;
create policy pk_upd on public.pk_docs for update to anon using (public.pk_team_ok()) with check (public.pk_team_ok());
-- ما فيه صلاحية حذف: البيانات ما تنحذف من الصفحة أبداً
