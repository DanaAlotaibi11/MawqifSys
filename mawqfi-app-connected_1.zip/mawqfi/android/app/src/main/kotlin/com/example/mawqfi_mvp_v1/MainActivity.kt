package com.example.mawqfi_mvp_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
