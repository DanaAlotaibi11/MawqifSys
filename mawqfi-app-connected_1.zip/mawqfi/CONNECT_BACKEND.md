# Connecting the app to the backend

The app now reads **real data** from the Mawqfi backend instead of `assets/data/mock_data.json`.

## What changed

| File | Change |
|---|---|
| `lib/data/repositories/parking_repository.dart` | New `ApiParkingRepository` that calls the backend. `appRepository` now uses it. The old `MockParkingRepository` is still there. |
| `lib/data/models/live_occupancy.dart` | New model for the live analytics numbers. |
| `lib/ui/home/home_view_model.dart` | Free / total spots per facility come from the analytics engine (`/analytics/live`). |
| `lib/ui/facility_overview/facility_overview_view_model.dart` | Free / total spots per floor come from the analytics engine. |
| `pubspec.yaml` | Added the `http` package. |
| Android / iOS / macOS settings | Allow the app to call a local `http://` backend while developing. |

No screen (UI) was changed.

## Where each piece of data comes from

| In the app | Source |
|---|---|
| Facilities, floors, zones, spots | Backend: `GET /locations`, `/facilities`, `/floors`, `/zones`, `/spots` |
| Spot status (free / occupied / unknown) | Backend: `GET /spots` (updated by the sensors) |
| Free / total counts on home and facility screens | Backend analytics: `GET /analytics/live` |
| Sign in (phone + OTP), profile | Still local (mock) |
| "I parked here", my parking, history | Still local (mock) |

Sign in and parking stay local because the backend signs in with **email + password** and has **no parking routes** yet. The team needs to decide:
1. Sign in: change the app to email + password, or add phone sign in (needs an SMS service in Supabase).
2. Parking: add backend routes for start parking, end parking and my parkings (the database already has the table and functions).

## How to run

1. Start the backend (in the backend folder, with its `.env` filled in):
   ```
   npm install
   npm run dev
   ```
   It runs on `http://localhost:3000`.
2. In this app folder:
   ```
   flutter pub get
   flutter run -d chrome
   ```
3. Other devices need a different backend address:
   ```
   flutter run --dart-define=BACKEND_URL=http://10.0.2.2:3000        # Android emulator
   flutter run --dart-define=BACKEND_URL=http://192.168.1.20:3000    # real phone (computer IP, same Wi-Fi)
   ```

To go back to the offline mock data, change one line in `parking_repository.dart`:
```dart
final ParkingRepository appRepository = MockParkingRepository();
```

## Quick test checklist

- [ ] Home shows the facilities from Supabase, with free / total spots.
- [ ] Opening a facility shows its floors with free / total spots.
- [ ] A floor map shows the spots with their real status.
- [ ] Changing a spot in the database (or sending a sensor event) changes the app after refresh.
- [ ] With the backend stopped, the app shows its error message instead of crashing.

## Notes

- The database has no floor level, so floors are numbered in the order they were created (first = ground).
- The database has no "distance to entrance" for spots, so that value is empty.
- Disabled spots (`is_enabled = false`) are shown as unknown and are not counted in the analytics.
