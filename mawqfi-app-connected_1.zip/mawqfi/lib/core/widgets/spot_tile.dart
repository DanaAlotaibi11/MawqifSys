import 'package:flutter/material.dart';

import '../../app/theme.dart';
import '../../data/models/spot.dart';
import '../../data/models/spot_status.dart';

class SpotTile extends StatelessWidget {
  const SpotTile({super.key, required this.spot, this.selected = false, this.onTap});

  final Spot spot;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final status = spot.displayStatus();
    final (bg, border, iconColor, labelColor, icon, label) = selected
        ? (AppColors.primary, AppColors.primary, Colors.white, Colors.white,
            Icons.location_on_rounded, 'محدد')
        : switch (status) {
            SpotStatus.free => (AppColors.availableBg, AppColors.available, AppColors.available,
                AppColors.textPrimary, Icons.check_rounded, 'متاح'),
            SpotStatus.occupied => (AppColors.occupiedBg, AppColors.occupied, AppColors.occupied,
                AppColors.textPrimary, Icons.directions_car_rounded, 'مشغول'),
            SpotStatus.unknown => (AppColors.unknownBg, AppColors.unknownBorder, AppColors.unknown,
                AppColors.unknownText, Icons.help_outline_rounded, 'غير معروف'),
          };

    return Semantics(
      button: onTap != null,
      selected: selected,
      label: '${spot.code}، $label',
      excludeSemantics: true,
      child: Material(
        color: bg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.tile),
          side: BorderSide(color: border, width: selected ? 3 : 1.5),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 22, color: iconColor),
              const SizedBox(height: 2),
              Text(
                spot.code,
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: labelColor,
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
