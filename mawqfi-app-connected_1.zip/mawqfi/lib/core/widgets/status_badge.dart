import 'package:flutter/material.dart';

import '../../app/theme.dart';

enum BadgeTone { available, occupied, unknown }

class StatusBadge extends StatelessWidget {
  const StatusBadge({super.key, required this.label, required this.tone});

  final String label;
  final BadgeTone tone;

  @override
  Widget build(BuildContext context) {
    final (bg, text, dot) = switch (tone) {
      BadgeTone.available => (AppColors.availableBg, AppColors.availableText, AppColors.available),
      BadgeTone.occupied => (AppColors.occupiedBg, AppColors.occupiedText, AppColors.occupied),
      BadgeTone.unknown => (AppColors.unknownBg, AppColors.unknownText, AppColors.unknown),
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: Theme.of(context).textTheme.labelMedium?.copyWith(color: text),
          ),
          const SizedBox(width: 6),
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: dot, shape: BoxShape.circle),
          ),
        ],
      ),
    );
  }
}
