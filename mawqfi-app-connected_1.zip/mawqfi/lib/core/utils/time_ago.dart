String timeAgo(DateTime time, [DateTime? now]) {
  final s = (now ?? DateTime.now()).difference(time).inSeconds;
  if (s < 5) return 'الآن';
  if (s < 60) return 'قبل ${_count(s, 'ثانية', 'ثانيتين', 'ثوانٍ')}';
  final m = s ~/ 60;
  if (m < 60) return 'قبل ${_count(m, 'دقيقة', 'دقيقتين', 'دقائق')}';
  final h = m ~/ 60;
  if (h < 24) return 'قبل ${_count(h, 'ساعة', 'ساعتين', 'ساعات')}';
  final d = h ~/ 24;
  return 'قبل ${_count(d, 'يوم', 'يومين', 'أيام')}';
}

String _count(int n, String one, String two, String few) => switch (n) {
      1 => one,
      2 => two,
      >= 3 && <= 10 => '$n $few',
      _ => '$n $one',
    };
