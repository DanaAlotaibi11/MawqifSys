import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

Future<void> openGoogleMaps(BuildContext context, double? lat, double? lng) async {
  final messenger = ScaffoldMessenger.of(context);

  if (lat == null || lng == null) {
    messenger.showSnackBar(const SnackBar(content: Text('موقع المبنى غير متوفر')));
    return;
  }

  final url = Uri.https('www.google.com', '/maps/dir/', {
    'api': '1',
    'destination': '$lat,$lng',
    'travelmode': 'driving',
  });

  final opened = await launchUrl(url, mode: LaunchMode.externalApplication);
  if (!opened) {
    messenger.showSnackBar(const SnackBar(content: Text('تعذّر فتح Google Maps')));
  }
}
