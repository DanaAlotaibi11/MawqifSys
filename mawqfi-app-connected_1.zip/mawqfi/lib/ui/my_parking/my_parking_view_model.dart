import 'dart:async';
import 'dart:collection';

import 'package:flutter/foundation.dart';

import '../../data/models/parking_session.dart';
import '../../data/models/spot.dart';
import '../../data/repositories/parking_repository.dart';

class MyParkingViewModel extends ChangeNotifier {
  MyParkingViewModel(this._repository) {
    _repository.parkingChanges.addListener(load);
  }

  final ParkingRepository _repository;

  bool isLoading = false;
  String? error;
  ParkingSession? parking;
  Spot? spot;
  String placeLine = '';
  String zoneLine = '';

  Timer? _ticker;
  bool _disposed = false;

  bool get hasActiveParking => parking != null;

  String get startTime {
    final t = parking?.startedAt.toLocal();
    if (t == null) return '';
    final hour = t.hour % 12 == 0 ? 12 : t.hour % 12;
    final minute = t.minute.toString().padLeft(2, '0');
    return '$hour:$minute ${t.hour < 12 ? 'ص' : 'م'}';
  }

  String get elapsed {
    final d = parking?.duration() ?? Duration.zero;
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}';
  }

  Future<void> load() async {
    isLoading = true;
    error = null;
    _notify();

    try {
      final (parkings, spots, zones, floors, facilities) = await (
        _repository.getMyParkings(),
        _repository.getSpots(),
        _repository.getZones(),
        _repository.getFloors(),
        _repository.getFacilities(),
      ).wait;

      parking = parkings.where((p) => p.isActive).firstOrNull;
      final active = parking;
      if (active != null) {
        spot = spots.where((s) => s.id == active.spotId).firstOrNull;
        final zone = zones.where((z) => z.id == spot?.zoneId).firstOrNull;
        final floor = floors.where((f) => f.id == zone?.floorId).firstOrNull;
        final facility = facilities.where((f) => f.id == floor?.facilityId).firstOrNull;

        final facilityName = (facility?.name ?? '').split(' · ').first;
        placeLine = [facilityName, floor?.name ?? '']
            .where((s) => s.isNotEmpty)
            .join(' · ');

        final distance = spot?.distanceToEntranceM;
        zoneLine = distance == null
            ? (zone?.name ?? '')
            : '${zone?.name ?? ''} · $distance م من المدخل';
      }
      _startTicker();
    } catch (e) {
      debugPrint('My parking load failed: $e');
      error = 'تعذّر تحميل موقفك';
    }

    isLoading = false;
    _notify();
  }

  Future<void> endParking() async {
    final active = parking;
    if (active == null) return;
    await _repository.endParking(active.id);
  }

  void _startTicker() {
    _ticker?.cancel();
    if (parking == null) return;
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => _notify());
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _repository.parkingChanges.removeListener(load);
    _ticker?.cancel();
    super.dispose();
  }
}
