import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../core/widgets/status_badge.dart';
import '../../data/repositories/parking_repository.dart';
import '../find_my_car/find_my_car_screen.dart';
import 'my_parking_view_model.dart';

class MyParkingScreen extends StatefulWidget {
  const MyParkingScreen({super.key, this.repository});

  final ParkingRepository? repository;

  @override
  State<MyParkingScreen> createState() => _MyParkingScreenState();
}

class _MyParkingScreenState extends State<MyParkingScreen> {
  late final MyParkingViewModel _vm =
      MyParkingViewModel(widget.repository ?? appRepository)..load();

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 16, bottom: 8),
                  child: Text('موقفي', style: text.titleMedium?.copyWith(fontSize: 18)),
                ),
                Expanded(
                  child: ListenableBuilder(
                    listenable: _vm,
                    builder: (context, _) {
                      if (_vm.isLoading && !_vm.hasActiveParking) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (_vm.error != null) {
                        return _Message(
                          icon: Icons.error_outline_rounded,
                          title: _vm.error!,
                          action: OutlinedButton(
                            onPressed: _vm.load,
                            child: const Text('إعادة المحاولة'),
                          ),
                        );
                      }
                      if (!_vm.hasActiveParking) {
                        return const _Message(
                          icon: Icons.local_parking_rounded,
                          title: 'ما عندك موقف حالياً',
                          subtitle: 'اختر موقف من استكشاف وبنحفظه لك هنا',
                        );
                      }
                      return _parked(context);
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _parked(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
            children: [
              Center(
                child: Container(
                  width: 72,
                  height: 72,
                  decoration: const BoxDecoration(color: AppColors.available, shape: BoxShape.circle),
                  child: const Icon(Icons.check_rounded, color: Colors.white, size: 44),
                ),
              ),
              const SizedBox(height: 6),
              Text('تم حفظ موقفك', textAlign: TextAlign.center, style: text.headlineSmall),
              Text('بنذكّرك وين أوقفت سيارتك', textAlign: TextAlign.center, style: text.bodyMedium),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(AppRadius.card),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            _vm.spot?.code ?? '',
                            style: text.headlineSmall?.copyWith(fontSize: 28),
                          ),
                        ),
                        const StatusBadge(label: 'موقفك', tone: BadgeTone.occupied),
                      ],
                    ),
                    const SizedBox(height: 2),
                    _InfoRow(label: 'المكان', value: _vm.placeLine),
                    const Divider(),
                    _InfoRow(label: 'المنطقة', value: _vm.zoneLine),
                    const Divider(),
                    _InfoRow(label: 'بداية الوقوف', value: _vm.startTime),
                    const Divider(),
                    _InfoRow(
                      label: 'المدة',
                      value: _vm.elapsed,
                      valueColor: AppColors.primary,
                      ltr: true,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          child: Column(
            children: [
              FilledButton(
                onPressed: _openFindMyCar,
                child: const Text('وين سيارتي؟ توجّه لها'),
              ),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: _confirmEnd,
                child: const Text('إنهاء الوقوف'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void _openFindMyCar() {
    final spot = _vm.spot;
    if (spot == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => FindMyCarScreen(spotId: spot.id)),
    );
  }

  Future<void> _confirmEnd() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('إنهاء الوقوف؟'),
          content: const Text('بنشيل موقفك الحالي من موقفي.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              style: TextButton.styleFrom(foregroundColor: AppColors.occupied),
              child: const Text('إنهاء'),
            ),
          ],
        ),
      ),
    );
    if (confirmed == true) _vm.endParking();
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.label,
    required this.value,
    this.valueColor = AppColors.textPrimary,
    this.ltr = false,
  });

  final String label;
  final String value;
  final Color valueColor;
  final bool ltr;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(label, style: text.bodyMedium),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.end,
              textDirection: ltr ? TextDirection.ltr : null,
              style: text.bodyMedium?.copyWith(fontWeight: FontWeight.w600, color: valueColor),
            ),
          ),
        ],
      ),
    );
  }
}

class _Message extends StatelessWidget {
  const _Message({required this.icon, required this.title, this.subtitle, this.action});

  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 48, color: AppColors.textMuted),
            const SizedBox(height: 12),
            Text(title, textAlign: TextAlign.center, style: text.titleSmall),
            if (subtitle != null) ...[
              const SizedBox(height: 4),
              Text(subtitle!, textAlign: TextAlign.center, style: text.bodyMedium),
            ],
            if (action != null) ...[const SizedBox(height: 12), action!],
          ],
        ),
      ),
    );
  }
}
