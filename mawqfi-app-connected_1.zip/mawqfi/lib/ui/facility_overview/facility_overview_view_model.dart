import 'package:flutter/foundation.dart';

import '../../data/models/facility.dart';
import '../../data/models/floor.dart';
import '../../data/models/spot_status.dart';
import '../../data/repositories/parking_repository.dart';

class FloorSummary {
  const FloorSummary({
    required this.floor,
    required this.zoneNames,
    required this.freeCount,
    required this.totalCount,
  });

  final Floor floor;
  final List<String> zoneNames;
  final int freeCount;
  final int totalCount;

  double get freeRatio => totalCount == 0 ? 0 : freeCount / totalCount;

  String get zonesLabel {
    if (zoneNames.isEmpty) return '';
    if (zoneNames.length == 1) return 'المنطقة ${zoneNames.first}';
    if (zoneNames.length == 2) return 'المنطقتان ${zoneNames.join(' و ')}';
    return 'المناطق ${zoneNames.join(' و ')}';
  }
}

class FacilityOverviewViewModel extends ChangeNotifier {
  FacilityOverviewViewModel(this._repository, this.facilityId);

  final ParkingRepository _repository;
  final String facilityId;

  bool isLoading = false;
  String? error;
  Facility? facility;
  List<FloorSummary> floors = [];
  bool _disposed = false;

  String get facilityShortName => (facility?.name ?? '').split(' · ').first;

  int get totalSpots => floors.fold(0, (sum, f) => sum + f.totalCount);

  FloorSummary? get recommended {
    FloorSummary? best;
    for (final f in floors) {
      if (f.freeCount == 0) continue;
      if (best == null || f.freeCount > best.freeCount) best = f;
    }
    return best;
  }

  String get subtitle {
    final n = floors.length;
    final floorsLabel = switch (n) {
      1 => 'دور واحد',
      2 => 'دوران',
      _ when n <= 10 => '$n أدوار',
      _ => '$n دور',
    };
    return '$floorsLabel · $totalSpots موقف';
  }

  Future<void> load() async {
    isLoading = true;
    error = null;
    _notify();

    try {
      final (facilities, allFloors, zones, spots) = await (
        _repository.getFacilities(),
        _repository.getFloors(),
        _repository.getZones(),
        _repository.getSpots(),
      ).wait;

      facility = facilities.firstWhere((f) => f.id == facilityId);
      final myFloors = allFloors.where((f) => f.facilityId == facilityId).toList()
        ..sort((a, b) => b.level.compareTo(a.level));

      // live free / total per floor from the analytics engine (falls back to counting spots)
      final liveList = await Future.wait([
        for (final floor in myFloors) _repository.getLiveOccupancy('floor', floor.id),
      ]);
      final live = {
        for (var i = 0; i < myFloors.length; i++) myFloors[i].id: liveList[i],
      };

      floors = [
        for (final floor in myFloors)
          () {
            final floorZones = zones.where((z) => z.floorId == floor.id).toList()
              ..sort((a, b) => a.name.compareTo(b.name));
            final zoneIds = {for (final z in floorZones) z.id};
            final floorSpots = spots.where((s) => zoneIds.contains(s.zoneId)).toList();
            return FloorSummary(
              floor: floor,
              zoneNames: [for (final z in floorZones) z.name],
              freeCount: live[floor.id]?.free ??
                  floorSpots.where((s) => s.displayStatus() == SpotStatus.free).length,
              totalCount: live[floor.id]?.spots ?? floorSpots.length,
            );
          }(),
      ];
    } catch (e) {
      debugPrint('Facility overview load failed: $e');
      error = 'تعذّر تحميل المنشأة';
    }

    isLoading = false;
    _notify();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
