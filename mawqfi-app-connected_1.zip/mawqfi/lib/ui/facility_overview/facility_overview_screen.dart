import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../core/widgets/screen_header.dart';
import '../../core/widgets/status_badge.dart';
import '../../data/repositories/parking_repository.dart';
import '../floor_map/floor_map_screen.dart';
import 'facility_overview_view_model.dart';

class FacilityOverviewScreen extends StatefulWidget {
  const FacilityOverviewScreen({super.key, required this.facilityId, this.repository});

  final String facilityId;
  final ParkingRepository? repository;

  @override
  State<FacilityOverviewScreen> createState() => _FacilityOverviewScreenState();
}

class _FacilityOverviewScreenState extends State<FacilityOverviewScreen> {
  late final FacilityOverviewViewModel _vm = FacilityOverviewViewModel(
    widget.repository ?? appRepository,
    widget.facilityId,
  )..load();

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  void _openFloor(String floorId) {
    Navigator.of(context).push(
      MaterialPageRoute(
        settings: const RouteSettings(name: FloorMapScreen.routeName),
        builder: (_) => FloorMapScreen(facilityId: widget.facilityId, floorId: floorId),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _vm,
              builder: (context, _) {
                return Column(
                  children: [
                    ScreenHeader(title: _vm.facilityShortName),
                    Expanded(child: _body(context)),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _body(BuildContext context) {
    final text = Theme.of(context).textTheme;

    if (_vm.isLoading && _vm.facility == null) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_vm.facility == null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_vm.error ?? 'تعذّر تحميل المنشأة', style: text.bodyMedium),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _vm.load, child: const Text('إعادة المحاولة')),
          ],
        ),
      );
    }

    final best = _vm.recommended;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(_vm.subtitle, textAlign: TextAlign.center, style: text.bodyMedium),
              const SizedBox(height: 12),
              if (best != null) ...[
                _Recommendation(
                  title: 'ننصحك ب${best.floor.name}',
                  body: 'فيه أكثر مواقف متاحة الحين (${best.freeCount} من ${best.totalCount}).',
                  onTap: () => _openFloor(best.floor.id),
                ),
                const SizedBox(height: 12),
              ],
              Text('اختر الدور', style: text.titleSmall),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _vm.load,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              children: [
                for (final f in _vm.floors) ...[
                  _FloorCard(summary: f, onTap: () => _openFloor(f.floor.id)),
                  const SizedBox(height: 12),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _Recommendation extends StatelessWidget {
  const _Recommendation({required this.title, required this.body, required this.onTap});

  final String title;
  final String body;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Material(
      color: AppColors.availableBg,
      borderRadius: BorderRadius.circular(AppRadius.card),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              const Icon(Icons.auto_awesome_rounded, color: AppColors.availableText, size: 22),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: text.titleSmall?.copyWith(color: AppColors.availableText)),
                    Text(body, style: text.bodySmall?.copyWith(color: AppColors.availableText)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FloorCard extends StatelessWidget {
  const _FloorCard({required this.summary, required this.onTap});

  final FloorSummary summary;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final full = summary.totalCount > 0 && summary.freeCount == 0;

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(summary.floor.name, style: text.titleSmall),
                        Text(summary.zonesLabel, style: text.bodySmall),
                      ],
                    ),
                  ),
                  StatusBadge(
                    label: full ? 'ممتلئ' : '${summary.freeCount} متاح',
                    tone: full ? BadgeTone.occupied : BadgeTone.available,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(AppRadius.pill),
                child: LinearProgressIndicator(
                  value: summary.freeRatio,
                  minHeight: 6,
                  backgroundColor: AppColors.surfaceMuted,
                  color: full ? AppColors.occupied : AppColors.available,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
