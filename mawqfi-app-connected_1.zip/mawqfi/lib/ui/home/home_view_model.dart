import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../../data/models/facility.dart';
import '../../data/models/profile.dart';
import '../../data/models/spot_status.dart';
import '../../data/repositories/parking_repository.dart';

class FacilitySummary {
  const FacilitySummary({
    required this.facility,
    required this.floorCount,
    required this.firstFloorName,
    required this.freeCount,
    required this.totalCount,
    this.distanceKm,
  });

  final Facility facility;
  final int floorCount;
  final String? firstFloorName;
  final int freeCount;
  final int totalCount;
  final double? distanceKm;

  bool get isFull => totalCount > 0 && freeCount == 0;

  double get freeRatio => totalCount == 0 ? 0 : freeCount / totalCount;
}

class HomeViewModel extends ChangeNotifier {
  HomeViewModel(this._repository);

  final ParkingRepository _repository;

  static const _userLat = 24.7200;
  static const _userLng = 46.6400;

  bool isLoading = false;
  String? error;
  Profile? user;
  List<FacilitySummary> facilities = [];
  String query = '';
  bool _disposed = false;

  void search(String text) {
    query = text;
    _notify();
  }

  List<FacilitySummary> get visibleFacilities {
    final q = _normalize(query);
    if (q.isEmpty) return facilities;
    return facilities
        .where((s) => _normalize(s.facility.name).contains(q))
        .toList();
  }

  static String _normalize(String text) => text
      .trim()
      .toLowerCase()
      .replaceAll(RegExp('[أإآ]'), 'ا')
      .replaceAll('ة', 'ه')
      .replaceAll('ى', 'ي');

  String get greeting =>
      DateTime.now().hour < 12 ? 'صباح الخير' : 'مساء الخير';

  Future<void> load() async {
    isLoading = true;
    error = null;
    _notify();

    try {
      final (profile, allFacilities, floors, zones, spots) = await (
        _repository.getCurrentUser(),
        _repository.getFacilities(),
        _repository.getFloors(),
        _repository.getZones(),
        _repository.getSpots(),
      ).wait;

      final floorOfZone = {for (final z in zones) z.id: z.floorId};
      final facilityOfFloor = {for (final f in floors) f.id: f.facilityId};

      final free = <String, int>{};
      final total = <String, int>{};
      for (final spot in spots) {
        final facilityId = facilityOfFloor[floorOfZone[spot.zoneId]];

        if (facilityId == null) continue;

        total[facilityId] = (total[facilityId] ?? 0) + 1;

        if (spot.displayStatus() == SpotStatus.free) {
          free[facilityId] = (free[facilityId] ?? 0) + 1;
        }
      }

      // live free / total from the analytics engine (falls back to counting spots)
      final liveList = await Future.wait([
        for (final f in allFacilities) _repository.getLiveOccupancy('facility', f.id),
      ]);
      final live = {
        for (var i = 0; i < allFacilities.length; i++) allFacilities[i].id: liveList[i],
      };

      user = profile;
      facilities = allFacilities.map((facility) {
        final itsFloors = floors.where((f) => f.facilityId == facility.id).toList()
          ..sort((a, b) => a.level.compareTo(b.level));

        return FacilitySummary(
          facility: facility,
          floorCount: itsFloors.length,
          firstFloorName: itsFloors.isEmpty ? null : itsFloors.first.name,
          freeCount: live[facility.id]?.free ?? free[facility.id] ?? 0,
          totalCount: live[facility.id]?.spots ?? total[facility.id] ?? 0,
          distanceKm: _distanceKm(facility),
        );
      }).toList()
        ..sort((a, b) =>
            (a.distanceKm ?? double.infinity).compareTo(b.distanceKm ?? double.infinity));
    } catch (e) {
      debugPrint('Home load failed: $e');
      error = 'تعذّر تحميل المواقف';
    }

    isLoading = false;
    _notify();
  }

  double? _distanceKm(Facility f) {
    final lat = f.latitude, lng = f.longitude;
    if (lat == null || lng == null) return null;
    const r = 6371.0;
    double rad(double d) => d * math.pi / 180;
    final dLat = rad(lat - _userLat);
    final dLng = rad(lng - _userLng);
    final a = math.pow(math.sin(dLat / 2), 2) +
        math.cos(rad(_userLat)) * math.cos(rad(lat)) * math.pow(math.sin(dLng / 2), 2);
    return 2 * r * math.asin(math.sqrt(a));
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
