import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../data/models/facility.dart';
import '../../data/repositories/parking_repository.dart';
import '../facility_overview/facility_overview_screen.dart';
import '../floor_map/floor_map_screen.dart';
import 'home_view_model.dart';
import 'widgets/facility_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, this.repository, this.onFacilityTap});

  final ParkingRepository? repository;

  final ValueChanged<Facility>? onFacilityTap;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final HomeViewModel _vm =
      HomeViewModel(widget.repository ?? appRepository)..load();

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _vm,
              builder: (context, _) {
                if (_vm.isLoading && _vm.facilities.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (_vm.error != null && _vm.facilities.isEmpty) {
                  return _ErrorView(message: _vm.error!, onRetry: _vm.load);
                }
                return _content(context);
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _content(BuildContext context) {
    final text = Theme.of(context).textTheme;
    const gap = SizedBox(height: 14);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
        Row(

          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${_vm.greeting}، ${_vm.user?.name ?? ''}',
                    style: text.headlineSmall,
                  ),
                  Text('وين تبي توقف اليوم؟', style: text.bodyMedium),
                ],
              ),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.notifications_none_rounded),
              color: AppColors.textPrimary,
            ),
          ],
        ),
        gap,

        TextField(
          onChanged: _vm.search,
          textInputAction: TextInputAction.search,
          decoration: const InputDecoration(
            hintText: 'ابحث عن موقف أو منطقة',
            prefixIcon: Icon(Icons.search, color: AppColors.textSecondary),

          ),
        ),
        gap,

        Text('قريب منك', style: text.titleSmall),
        gap,
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _vm.load,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              children: [
        for (final summary in _vm.visibleFacilities) ...[
          FacilityCard(
            summary: summary,
            onTap: () => _openFacility(summary.facility, summary.floorCount),
          ),
          gap,
        ],

        if (_vm.query.trim().isNotEmpty && _vm.visibleFacilities.isEmpty) ...[
          Text('ما فيه نتائج لـ "${_vm.query.trim()}"', style: text.bodyMedium),
          gap,
        ],
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _openFacility(Facility facility, int floorCount) {
    final custom = widget.onFacilityTap;
    if (custom != null) {
      custom(facility);
      return;
    }
    Navigator.of(context).push(
      floorCount > 1
          ? MaterialPageRoute(builder: (_) => FacilityOverviewScreen(facilityId: facility.id))
          : MaterialPageRoute(
              settings: const RouteSettings(name: FloorMapScreen.routeName),
              builder: (_) => FloorMapScreen(facilityId: facility.id),
            ),
    );
  }
}


class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(message, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 12),

          OutlinedButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
        ],
      ),
    );
  }
}
