import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/widgets/status_badge.dart';
import '../home_view_model.dart';

class FacilityCard extends StatelessWidget {
  const FacilityCard({super.key, required this.summary, this.onTap});

  final FacilitySummary summary;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final s = summary;

    final barColor = s.isFull ? AppColors.occupied : AppColors.available;
    final barValue = s.isFull ? 1.0 : s.freeRatio;

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(s.facility.name, style: text.titleMedium),
                        Text(_subtitle(s), style: text.bodySmall),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  _badge(s),
                ],
              ),
              const SizedBox(height: 8),

              ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: LinearProgressIndicator(
                  value: barValue,
                  minHeight: 6,
                  backgroundColor: AppColors.surfaceMuted,
                  color: barColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _badge(FacilitySummary s) {
    if (s.totalCount == 0) {
      return const StatusBadge(label: 'غير معروف', tone: BadgeTone.unknown);
    }
    if (s.isFull) {
      return const StatusBadge(label: 'ممتلئ', tone: BadgeTone.occupied);
    }
    return StatusBadge(label: _freeLabel(s.freeCount), tone: BadgeTone.available);
  }

  static String _subtitle(FacilitySummary s) {
    final parts = <String>[
      if (s.floorCount == 1 && s.firstFloorName != null) s.firstFloorName!,
      if (s.floorCount == 2) 'دوران',
      if (s.floorCount > 2) '${s.floorCount} أدوار',
      if (s.distanceKm != null) '${s.distanceKm!.toStringAsFixed(1)} كم',
    ];
    return parts.join(' · ');
  }

  static String _freeLabel(int n) => switch (n) {
        1 => 'موقف واحد متاح',
        2 => 'موقفان متاحان',
        >= 3 && <= 10 => '$n مواقف متاحة',
        _ => '$n موقف متاح',
      };
}
