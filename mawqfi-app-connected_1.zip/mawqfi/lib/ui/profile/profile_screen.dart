import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../data/repositories/parking_repository.dart';
import '../auth/login_screen.dart';
import 'profile_view_model.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, this.repository});

  final ParkingRepository? repository;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late final ProfileViewModel _vm =
      ProfileViewModel(widget.repository ?? appRepository)..load();

  static const _appVersion = 'موقفي · نسخة Pilot 0.1';

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 16, bottom: 8),
                  child: Text('حسابي', style: text.titleMedium?.copyWith(fontSize: 18)),
                ),
                Expanded(
                  child: ListenableBuilder(
                    listenable: _vm,
                    builder: (context, _) {
                      if (_vm.isLoading && _vm.user == null) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (_vm.user == null) {
                        return Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(_vm.error ?? 'تعذّر تحميل الحساب', style: text.bodyMedium),
                              const SizedBox(height: 12),
                              OutlinedButton(onPressed: _vm.load, child: const Text('إعادة المحاولة')),
                            ],
                          ),
                        );
                      }
                      return _content(context);
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _content(BuildContext context) {
    final text = Theme.of(context).textTheme;
    const gap = SizedBox(height: 14);

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      children: [
        Row(
          children: [
            Container(
              width: 60,
              height: 60,
              alignment: Alignment.center,
              decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
              child: Text(
                _vm.initial,
                style: text.headlineSmall?.copyWith(fontSize: 24, color: Colors.white),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_vm.user!.name, style: text.headlineSmall?.copyWith(fontSize: 20)),
                  if (_vm.phone.isNotEmpty)
                    Text(
                      _vm.phone,
                      textDirection: TextDirection.ltr,
                      style: text.bodySmall,
                    ),
                ],
              ),
            ),
          ],
        ),
        gap,
        _Card(
          child: Column(
            children: [
              _SettingRow(
                icon: Icons.language_rounded,
                title: 'اللغة',
                value: 'العربية',
                onTap: () => _comingSoon(context),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              _SettingRow(
                icon: Icons.notifications_none_rounded,
                title: 'الإشعارات',
                value: _vm.notificationsOn ? 'مفعّلة' : 'متوقفة',
                valueColor: _vm.notificationsOn ? AppColors.availableText : AppColors.textSecondary,
                onTap: _vm.toggleNotifications,
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              _SettingRow(
                icon: Icons.star_border_rounded,
                title: 'المواقف المفضلة',
                value: '',
                onTap: () => _comingSoon(context),
              ),
            ],
          ),
        ),
        gap,
        _Card(
          child: _SettingRow(
            icon: Icons.logout_rounded,
            title: 'تسجيل الخروج',
            color: AppColors.occupied,
            showChevron: false,
            onTap: _logout,
          ),
        ),
        gap,
        Text(_appVersion, style: text.labelSmall?.copyWith(fontSize: 12)),
      ],
    );
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('تسجيل الخروج؟'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              style: TextButton.styleFrom(foregroundColor: AppColors.occupied),
              child: const Text('خروج'),
            ),
          ],
        ),
      ),
    );
    if (confirmed != true || !mounted) return;
    await appRepository.signOut();
    if (!mounted) return;
    Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (_) => false,
    );
  }

  void _comingSoon(BuildContext context) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(const SnackBar(content: Text('قريباً')));
  }
}

class _Card extends StatelessWidget {
  const _Card({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.card),
        side: const BorderSide(color: AppColors.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: child,
      ),
    );
  }
}

class _SettingRow extends StatelessWidget {
  const _SettingRow({
    required this.icon,
    required this.title,
    required this.onTap,
    this.value = '',
    this.valueColor = AppColors.textPrimary,
    this.color = AppColors.textPrimary,
    this.showChevron = true,
  });

  final IconData icon;
  final String title;
  final String value;
  final Color valueColor;
  final Color color;
  final bool showChevron;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            Icon(icon, size: 20, color: color),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                title,
                style: text.bodyLarge?.copyWith(fontWeight: FontWeight.w600, color: color),
              ),
            ),
            if (value.isNotEmpty)
              Text(value, style: text.bodyMedium?.copyWith(color: valueColor)),
            if (showChevron) ...[
              const SizedBox(width: 6),
              const Icon(Icons.chevron_left_rounded, size: 18, color: AppColors.textSecondary),
            ],
          ],
        ),
      ),
    );
  }
}
