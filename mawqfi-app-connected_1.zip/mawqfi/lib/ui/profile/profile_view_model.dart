import 'package:flutter/foundation.dart';

import '../../data/models/profile.dart';
import '../../data/repositories/parking_repository.dart';

class ProfileViewModel extends ChangeNotifier {
  ProfileViewModel(this._repository);

  final ParkingRepository _repository;

  bool isLoading = false;
  String? error;
  Profile? user;
  bool notificationsOn = true;

  String get initial {
    final name = user?.name.trim() ?? '';
    return name.isEmpty ? '' : name.substring(0, 1);
  }

  String get phone {
    final raw = user?.phone;
    if (raw == null || raw.isEmpty) return '';
    if (raw.startsWith('+966')) return '0${raw.substring(4)}';
    return raw;
  }

  Future<void> load() async {
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      user = await _repository.getCurrentUser();
    } catch (e) {
      debugPrint('Profile load failed: $e');
      error = 'تعذّر تحميل الحساب';
    }

    isLoading = false;
    notifyListeners();
  }

  void toggleNotifications() {
    notificationsOn = !notificationsOn;
    notifyListeners();
  }
}
