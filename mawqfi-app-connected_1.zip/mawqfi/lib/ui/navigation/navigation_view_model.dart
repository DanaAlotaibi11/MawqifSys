import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../data/models/facility.dart';
import '../../data/models/floor.dart';
import '../../data/models/spot.dart';
import '../../data/models/spot_status.dart';
import '../../data/models/zone.dart';
import '../../data/repositories/parking_repository.dart';

class NavigationViewModel extends ChangeNotifier {
  NavigationViewModel(this._repository, this.spotId);

  final ParkingRepository _repository;
  String spotId;

  static const refreshEvery = Duration(seconds: 15);

  bool isLoading = false;
  bool isParking = false;
  String? error;
  Spot? spot;
  Zone? zone;
  Floor? floor;
  Facility? facility;
  DateTime? lastCheck;

  List<Spot> _spots = [];
  List<Zone> _zones = [];
  List<Floor> _floors = [];
  List<Facility> _facilities = [];
  final Set<String> _demoTaken = {};
  Timer? _timer;
  bool _disposed = false;

  bool get isTaken {
    final s = spot;
    if (s == null) return false;
    return _demoTaken.contains(s.id) || s.displayStatus() == SpotStatus.occupied;
  }

  bool get isUnknown {
    final s = spot;
    if (s == null || isTaken) return false;
    return s.displayStatus() == SpotStatus.unknown;
  }

  String get facilityShortName => (facility?.name ?? '').split(' · ').first;

  void start() {
    load();
    _timer = Timer.periodic(refreshEvery, (_) => load(silent: true));
  }

  Future<void> load({bool silent = false}) async {
    if (!silent) {
      isLoading = true;
      error = null;
      _notify();
    }
    try {
      final (spots, zones, floors, facilities) = await (
        _repository.getSpots(),
        _repository.getZones(),
        _repository.getFloors(),
        _repository.getFacilities(),
      ).wait;
      _spots = spots;
      _zones = zones;
      _floors = floors;
      _facilities = facilities;
      _select(spotId);
      lastCheck = DateTime.now();
      error = null;
    } catch (e) {
      debugPrint('Navigation load failed: $e');
      if (!silent) error = 'تعذّر تحميل الموقف';
    }
    isLoading = false;
    _notify();
  }

  void simulateTaken() {
    if (spot == null) return;
    _demoTaken.add(spot!.id);
    _notify();
  }

  Spot? nearestFree() {
    final f = floor;
    if (f == null) return null;
    final zoneIds = {for (final z in _zones.where((z) => z.floorId == f.id)) z.id};
    final candidates = _spots
        .where((s) =>
            zoneIds.contains(s.zoneId) &&
            s.id != spotId &&
            !_demoTaken.contains(s.id) &&
            s.displayStatus() == SpotStatus.free)
        .toList()
      ..sort((a, b) => (a.distanceToEntranceM ?? 9999).compareTo(b.distanceToEntranceM ?? 9999));
    return candidates.isEmpty ? null : candidates.first;
  }

  void switchTo(Spot newSpot) {
    spotId = newSpot.id;
    _select(spotId);
    _notify();
  }

  Future<bool> parkHere() async {
    if (isParking) return false;
    isParking = true;
    _notify();
    try {
      await _repository.startParking(spotId);
      return true;
    } catch (e) {
      debugPrint('Start parking failed: $e');
      return false;
    } finally {
      isParking = false;
      _notify();
    }
  }

  void _select(String id) {
    spot = _spots.firstWhere((s) => s.id == id);
    zone = _zones.firstWhere((z) => z.id == spot!.zoneId);
    floor = _floors.firstWhere((f) => f.id == zone!.floorId);
    facility = _facilities.firstWhere((f) => f.id == floor!.facilityId);
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    super.dispose();
  }
}
