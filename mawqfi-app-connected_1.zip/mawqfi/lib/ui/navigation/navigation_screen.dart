import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/main_shell.dart';
import '../../app/theme.dart';
import '../../core/utils/maps.dart';
import '../../core/utils/time_ago.dart';
import '../../core/widgets/screen_header.dart';
import '../../core/widgets/status_badge.dart';
import '../../data/models/spot.dart';
import '../../data/repositories/parking_repository.dart';
import '../floor_map/floor_map_screen.dart';
import 'navigation_view_model.dart';

class NavigationScreen extends StatefulWidget {
  const NavigationScreen({super.key, required this.spotId, this.repository});

  final String spotId;
  final ParkingRepository? repository;

  @override
  State<NavigationScreen> createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  late final NavigationViewModel _vm = NavigationViewModel(
    widget.repository ?? appRepository,
    widget.spotId,
  )..start();

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _vm,
              builder: (context, _) {
                final code = _vm.spot?.code ?? '';
                return Column(
                  children: [
                    ScreenHeader(title: 'الملاحة إلى $code'),
                    Expanded(child: _body(context)),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _body(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final spot = _vm.spot;

    if (_vm.isLoading && spot == null) {
      return const Center(child: CircularProgressIndicator());
    }
    if (spot == null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_vm.error ?? 'تعذّر تحميل الموقف', style: text.bodyMedium),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _vm.load, child: const Text('إعادة المحاولة')),
          ],
        ),
      );
    }

    final taken = _vm.isTaken;
    final unknown = _vm.isUnknown;

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
            children: [
              if (taken) ...[
                _takenBanner(context, spot.code),
                const SizedBox(height: 12),
              ],
              if (unknown) ...[
                _unknownBanner(context),
                const SizedBox(height: 12),
              ],
              _liveStatus(context, spot.code, taken, unknown),
              const SizedBox(height: 12),
              _steps(context),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          child: taken
              ? _takenActions()
              : unknown
                  ? _unknownActions()
                  : _normalActions(),
        ),
      ],
    );
  }

  Widget _takenBanner(BuildContext context, String code) {
    final text = Theme.of(context).textTheme;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.occupiedBg,
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: AppColors.occupied),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.warning_amber_rounded, color: AppColors.occupiedText),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('انشغل الموقف $code', style: text.titleSmall?.copyWith(color: AppColors.occupiedText)),
                Text(
                  'أحد وقف فيه قبل توصل. نقدر نوجّهك لأقرب موقف متاح.',
                  style: text.bodySmall?.copyWith(color: AppColors.occupiedText),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _unknownBanner(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.unknownBg,
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: AppColors.unknownBorder),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.help_outline_rounded, color: AppColors.unknownText),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('حالة الموقف غير مؤكدة', style: text.titleSmall?.copyWith(color: AppColors.unknownText)),
                Text(
                  'ما وصلنا تحديث من السنسر من ${Spot.staleAfter.inMinutes} دقائق. ممكن يكون فاضي أو مشغول، تقدر تكمل أو تختار موقف ثاني.',
                  style: text.bodySmall?.copyWith(color: AppColors.unknownText),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _liveStatus(BuildContext context, String code, bool taken, bool unknown) {
    final text = Theme.of(context).textTheme;
    final checked = _vm.lastCheck;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text('الموقف $code', style: text.titleMedium)),
                StatusBadge(
                  label: taken ? 'مشغول' : unknown ? 'غير معروف' : 'متاح',
                  tone: taken
                      ? BadgeTone.occupied
                      : unknown
                          ? BadgeTone.unknown
                          : BadgeTone.available,
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              checked == null
                  ? 'نتابع حالة الموقف لحظياً'
                  : 'نتابع حالة الموقف لحظياً · آخر تحديث ${timeAgo(checked)}',
              style: text.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  Widget _steps(BuildContext context) {
    final floor = _vm.floor;
    final zoneName = _vm.zone?.name ?? '';
    final spot = _vm.spot!;
    final level = floor?.level ?? 0;
    final floorName = floor?.name ?? '';
    final distance = spot.distanceToEntranceM;

    final floorTitle = switch (level) {
      0 => 'ادخل $floorName',
      < 0 => 'انزل إلى $floorName',
      _ => 'اطلع إلى $floorName',
    };

    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          children: [
            _Step(
              marker: '1',
              active: true,
              title: 'توجّه إلى مدخل ${_vm.facilityShortName}',
              subtitle: 'افتح الخرائط للوصول للمدخل',
              trailing: OutlinedButton.icon(
                onPressed: () => openGoogleMaps(context, _vm.facility?.latitude, _vm.facility?.longitude),
                icon: const Icon(Icons.map_outlined, size: 18),
                label: const Text('فتح الخرائط'),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(0, 36),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  textStyle: Theme.of(context).textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w700),
                ),
              ),
            ),
            _Step(
              marker: '2',
              title: floorTitle,
              subtitle: level == 0 ? 'بعد المدخل مباشرة' : 'اتبع اللوحات',
            ),
            _Step(
              marker: '3',
              title: 'اتجه إلى المنطقة $zoneName',
              subtitle: 'اتبع لوحات المنطقة $zoneName',
            ),
            _Step(
              marker: '4',
              title: 'الموقف ${spot.code}',
              subtitle: distance == null ? 'ابحث عن رقم الموقف' : 'على بعد $distance م من المدخل',
            ),
          ],
        ),
      ),
    );
  }

  Widget _normalActions() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        FilledButton(
          onPressed: _vm.isParking ? null : _parkHere,
          child: const Text('وقفت هنا'),
        ),
      ],
    );
  }

  Widget _unknownActions() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        FilledButton(
          onPressed: _vm.isParking ? null : _parkHere,
          child: const Text('وقفت هنا'),
        ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: _reroute,
          child: const Text('وجّهني لأقرب موقف متاح'),
        ),
      ],
    );
  }

  Widget _takenActions() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        FilledButton(
          onPressed: _reroute,
          child: const Text('وجّهني لأقرب موقف متاح'),
        ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: () => Navigator.of(context).popUntil(
            (route) => route.settings.name == FloorMapScreen.routeName || route.isFirst,
          ),
          child: const Text('اختر من الخريطة'),
        ),
      ],
    );
  }

  void _reroute() {
    final next = _vm.nearestFree();
    if (next == null) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('ما فيه مواقف متاحة في هذا الدور حالياً')));
      return;
    }
    _vm.switchTo(next);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text('غيّرنا وجهتك إلى ${next.code}')));
  }

  Future<void> _parkHere() async {
    final ok = await _vm.parkHere();
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذّر حفظ موقفك، حاول مرة ثانية')),
      );
      return;
    }
    MainShell.tab.value = 1;
    Navigator.of(context).popUntil((route) => route.isFirst);
  }
}

class _Step extends StatelessWidget {
  const _Step({
    required this.marker,
    required this.title,
    required this.subtitle,
    this.active = false,
    this.trailing,
  });

  final String marker;
  final String title;
  final String subtitle;
  final bool active;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: active ? AppColors.primary : AppColors.surfaceMuted,
              shape: BoxShape.circle,
            ),
            child: Text(
              marker,
              style: text.labelMedium?.copyWith(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: active ? Colors.white : AppColors.textSecondary,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: text.bodyLarge?.copyWith(fontWeight: FontWeight.w700)),
                Text(subtitle, style: text.bodySmall?.copyWith(fontSize: 12)),
              ],
            ),
          ),
          if (trailing != null) ...[const SizedBox(width: 8), trailing!],
        ],
      ),
    );
  }
}
