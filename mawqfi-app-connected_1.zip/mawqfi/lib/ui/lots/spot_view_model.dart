import 'package:flutter/material.dart';

class SpotsViewModel extends StatefulWidget {
  const SpotsViewModel({super.key});

  @override
  State<SpotsViewModel> createState() => _SpotsViewModelState();
}

class _SpotsViewModelState extends State<SpotsViewModel> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
