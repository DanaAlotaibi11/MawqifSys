import 'package:flutter/material.dart';


class SpotsScreen extends StatefulWidget {
  const SpotsScreen({super.key});

  @override
  State<SpotsScreen> createState() => _SpotsScreenState();
}

class _SpotsScreenState extends State<SpotsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
