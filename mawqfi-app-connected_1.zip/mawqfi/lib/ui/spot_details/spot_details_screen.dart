import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../core/utils/time_ago.dart';
import '../../core/widgets/spot_tile.dart';
import '../../core/widgets/status_badge.dart';
import '../../data/models/spot.dart';
import '../../data/models/spot_status.dart';
import '../../data/repositories/parking_repository.dart';
import '../navigation/navigation_screen.dart';
import 'spot_details_view_model.dart';

class SpotDetailsScreen extends StatefulWidget {
  const SpotDetailsScreen({super.key, required this.spotId, this.repository});

  final String spotId;
  final ParkingRepository? repository;

  @override
  State<SpotDetailsScreen> createState() => _SpotDetailsScreenState();
}

class _SpotDetailsScreenState extends State<SpotDetailsScreen> {
  late final SpotDetailsViewModel _vm = SpotDetailsViewModel(
    widget.repository ?? appRepository,
    widget.spotId,
  )..start();

  static const _sensorVendor = 'OpenPark';

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _vm,
              builder: (context, _) {
                final spot = _vm.spot;
                if (_vm.isLoading && spot == null) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (spot == null) {
                  return Column(
                    children: [
                      _header(context),
                      Expanded(
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(_vm.error ?? 'الموقف غير موجود',
                                  style: Theme.of(context).textTheme.bodyMedium),
                              const SizedBox(height: 12),
                              OutlinedButton(onPressed: _vm.load, child: const Text('إعادة المحاولة')),
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                }
                final status = spot.displayStatus();
                return Column(
                  children: [
                    _header(context),
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                        children: [
                          _summaryCard(context, spot, status),
                          const SizedBox(height: 14),
                          if (status == SpotStatus.unknown) ...[
                            _unknownNotice(context),
                            const SizedBox(height: 14),
                          ],
                          _infoCard(context, spot, status),
                          const SizedBox(height: 14),
                          if (status != SpotStatus.unknown) _zoneCard(context, spot),
                        ],
                      ),
                    ),
                    _actions(context, status),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _header(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
      child: Row(
        children: [
          const BackButton(color: AppColors.textPrimary),
          Expanded(
            child: Text('تفاصيل الموقف',
                textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
          ),
          const SizedBox(width: 48),
        ],
      ),
    );
  }

  Widget _summaryCard(BuildContext context, Spot spot, SpotStatus status) {
    final text = Theme.of(context).textTheme;
    final (label, tone) = switch (status) {
      SpotStatus.free => ('متاح', BadgeTone.available),
      SpotStatus.occupied => ('مشغول', BadgeTone.occupied),
      SpotStatus.unknown => ('غير معروف', BadgeTone.unknown),
    };
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    spot.code,
                    style: text.headlineSmall?.copyWith(
                      fontSize: 30,
                      color: status == SpotStatus.unknown ? AppColors.unknownText : AppColors.textPrimary,
                    ),
                  ),
                ),
                StatusBadge(label: label, tone: tone),
              ],
            ),
            const SizedBox(height: 4),
            Text(_vm.locationLine, style: text.bodySmall),
          ],
        ),
      ),
    );
  }

  Widget _unknownNotice(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceMuted,
        borderRadius: BorderRadius.circular(AppRadius.card),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.help_outline_rounded, size: 20, color: AppColors.textSecondary),
              const SizedBox(width: 8),
              Text('حالة الموقف غير مؤكدة', style: text.titleSmall),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'السنسر ما أرسل تحديث من ${Spot.staleAfter.inMinutes} دقائق، فما نقدر نتأكد إذا الموقف فاضي. ما نحسبه ضمن المواقف المتاحة.',
            style: text.bodyMedium,
          ),
        ],
      ),
    );
  }

  Widget _infoCard(BuildContext context, Spot spot, SpotStatus status) {
    final lastSeen = spot.reportedAt == null ? 'غير معروف' : timeAgo(spot.reportedAt!);
    final rows = status == SpotStatus.unknown
        ? [
            _InfoRow(label: 'حالة السنسر', value: 'غير متصل', valueColor: AppColors.occupiedText),
            _InfoRow(label: 'آخر إشارة', value: lastSeen),
          ]
        : [
            _InfoRow(
              label: 'البعد عن المدخل',
              value: spot.distanceToEntranceM == null ? 'غير معروف' : '${spot.distanceToEntranceM} م',
            ),
            const _InfoRow(label: 'نوع الموقف', value: 'عادي'),
            const _InfoRow(
              label: 'حالة السنسر',
              value: 'متصل · $_sensorVendor',
              valueColor: AppColors.availableText,
            ),
            _InfoRow(label: 'آخر تحديث', value: lastSeen),
          ];
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: Column(
          children: [
            for (var i = 0; i < rows.length; i++) ...[
              rows[i],
              if (i < rows.length - 1) const Divider(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _zoneCard(BuildContext context, Spot selected) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('المنطقة ${_vm.zone?.name ?? ''}', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 5,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 56 / 66,
              children: [
                for (final s in _vm.zoneSpots)
                  SpotTile(
                    spot: s,
                    selected: s.id == selected.id,
                    onTap: () => _vm.selectSpot(s),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _actions(BuildContext context, SpotStatus status) {
    final canNavigate = status == SpotStatus.free;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FilledButton(
            onPressed: canNavigate
                ? () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => NavigationScreen(spotId: _vm.spot!.id),
                      ),
                    )
                : null,
            child: const Text('ابدأ الملاحة'),
          ),
          if (!canNavigate) ...[
            const SizedBox(height: 10),
            OutlinedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('اختر موقف آخر'),
            ),
          ],
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value, this.valueColor});

  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Expanded(child: Text(label, style: text.bodyMedium)),
          Text(
            value,
            style: text.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: valueColor ?? AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
