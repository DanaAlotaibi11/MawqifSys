import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../data/models/facility.dart';
import '../../data/models/floor.dart';
import '../../data/models/spot.dart';
import '../../data/models/zone.dart';
import '../../data/repositories/parking_repository.dart';

class SpotDetailsViewModel extends ChangeNotifier {
  SpotDetailsViewModel(this._repository, this.spotId);

  final ParkingRepository _repository;
  String spotId;

  static const refreshEvery = Duration(seconds: 15);

  bool isLoading = false;
  String? error;
  Spot? spot;
  Zone? zone;
  Floor? floor;
  Facility? facility;
  List<Spot> zoneSpots = [];

  List<Spot> _spots = [];
  Timer? _timer;
  bool _disposed = false;

  String get locationLine {
    final f = (facility?.name ?? '').split(' · ').first;
    return [
      if (f.isNotEmpty) f,
      if (floor != null) floor!.name,
      if (zone != null) 'المنطقة ${zone!.name}',
    ].join(' · ');
  }

  void start() {
    load();
    _timer = Timer.periodic(refreshEvery, (_) => load(silent: true));
  }

  Future<void> load({bool silent = false}) async {
    if (!silent) {
      isLoading = true;
      error = null;
      _notify();
    }
    try {
      final (spots, zones, floors, facilities) = await (
        _repository.getSpots(),
        _repository.getZones(),
        _repository.getFloors(),
        _repository.getFacilities(),
      ).wait;

      _spots = spots;
      final s = spots.firstWhere((x) => x.id == spotId);
      zone = zones.firstWhere((z) => z.id == s.zoneId);
      floor = floors.firstWhere((f) => f.id == zone!.floorId);
      facility = facilities.firstWhere((f) => f.id == floor!.facilityId);
      _select(s);
      error = null;
    } catch (e) {
      debugPrint('Spot details load failed: $e');
      if (!silent) error = 'تعذّر تحميل تفاصيل الموقف';
    }
    isLoading = false;
    _notify();
  }

  void selectSpot(Spot s) {
    if (s.id == spotId) return;
    spotId = s.id;
    _select(s);
    _notify();
  }

  void _select(Spot s) {
    spot = s;
    zoneSpots = _spots.where((x) => x.zoneId == s.zoneId).toList()
      ..sort((a, b) => a.code.compareTo(b.code));
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    super.dispose();
  }
}
