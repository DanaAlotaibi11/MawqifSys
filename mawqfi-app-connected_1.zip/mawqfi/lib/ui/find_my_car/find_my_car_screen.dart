import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../core/utils/maps.dart';
import '../../core/widgets/spot_tile.dart';
import '../../core/widgets/status_badge.dart';
import '../../data/repositories/parking_repository.dart';
import '../spot_details/spot_details_view_model.dart';

class FindMyCarScreen extends StatefulWidget {
  const FindMyCarScreen({super.key, required this.spotId, this.repository});

  final String spotId;
  final ParkingRepository? repository;

  @override
  State<FindMyCarScreen> createState() => _FindMyCarScreenState();
}

class _FindMyCarScreenState extends State<FindMyCarScreen> {
  late final SpotDetailsViewModel _vm = SpotDetailsViewModel(
    widget.repository ?? appRepository,
    widget.spotId,
  )..start();

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  String get _facilityName => (_vm.facility?.name ?? '').split(' · ').first;

  String get _toFacility {
    final name = _facilityName;
    return name.startsWith('ال') ? 'ل${name.substring(1)}' : 'ل$name';
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _vm,
              builder: (context, _) {
                return Column(
                  children: [
                    _header(context),
                    Expanded(child: _body(context)),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _header(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
      child: Row(
        children: [
          const BackButton(color: AppColors.textPrimary),
          Expanded(
            child: Text(
              'وين سيارتي؟',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 18),
            ),
          ),
          const SizedBox(width: 48),
        ],
      ),
    );
  }

  Widget _body(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final spot = _vm.spot;

    if (_vm.isLoading && spot == null) {
      return const Center(child: CircularProgressIndicator());
    }
    if (spot == null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_vm.error ?? 'تعذّر تحميل موقفك', style: text.bodyMedium),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _vm.load, child: const Text('إعادة المحاولة')),
          ],
        ),
      );
    }

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(spot.code, style: text.headlineSmall?.copyWith(fontSize: 34)),
                          ),
                          const StatusBadge(label: 'سيارتك هنا', tone: BadgeTone.occupied),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(_vm.locationLine, style: text.bodySmall),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              _miniMap(context, spot.id),
              const SizedBox(height: 12),
              _steps(context),
              const SizedBox(height: 12),
              Text(
                'Google Maps يوصلك $_toFacility، وداخل $_facilityName اتبع الدور والمنطقة ورقم الموقف.',
                style: text.labelSmall,
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          child: FilledButton(
            onPressed: _openGoogleMaps,
            child: const Text('فتح Google Maps'),
          ),
        ),
      ],
    );
  }

  Widget _miniMap(BuildContext context, String selectedId) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('المنطقة ${_vm.zone?.name ?? ''}', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            GridView.count(
              crossAxisCount: 5,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 51 / 59,
              children: [
                for (final s in _vm.zoneSpots)
                  SpotTile(spot: s, selected: s.id == selectedId),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _steps(BuildContext context) {
    final floor = _vm.floor;
    final spot = _vm.spot!;
    final distance = spot.distanceToEntranceM;

    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          children: [
            _Step(
              number: 1,
              active: true,
              title: 'ارجع $_toFacility عبر Google Maps',
              subtitle: 'يوصلك لين مدخل $_facilityName',
            ),
            _Step(
              number: 2,
              title: 'ادخل ${floor?.name ?? ''}',
              subtitle: (floor?.level ?? 0) == 0 ? 'بعد المدخل مباشرة' : 'اتبع اللوحات إلى ${floor?.name ?? ''}',
            ),
            _Step(
              number: 3,
              title: 'المنطقة ${_vm.zone?.name ?? ''} · الموقف ${spot.code}',
              subtitle: distance == null ? 'ابحث عن رقم الموقف' : 'على بعد $distance م من المدخل',
            ),
          ],
        ),
      ),
    );
  }

  void _openGoogleMaps() =>
      openGoogleMaps(context, _vm.facility?.latitude, _vm.facility?.longitude);
}

class _Step extends StatelessWidget {
  const _Step({
    required this.number,
    required this.title,
    required this.subtitle,
    this.active = false,
  });

  final int number;
  final String title;
  final String subtitle;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: active ? AppColors.primary : AppColors.surfaceMuted,
              shape: BoxShape.circle,
            ),
            child: Text(
              '$number',
              style: text.labelMedium?.copyWith(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: active ? Colors.white : AppColors.textSecondary,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: text.bodyLarge?.copyWith(fontWeight: FontWeight.w700)),
                Text(subtitle, style: text.bodySmall?.copyWith(fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
