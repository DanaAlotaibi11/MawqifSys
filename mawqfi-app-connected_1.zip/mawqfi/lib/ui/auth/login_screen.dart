import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../core/widgets/screen_header.dart';
import 'login_view_model.dart';
import 'otp_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _vm = LoginViewModel();

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  void _sendCode() {
    if (!_vm.isValid) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => OtpScreen(phone: _vm.phone)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _vm,
              builder: (context, _) {
                return Column(
                  children: [
                    ScreenHeader(title: 'تسجيل الدخول', showBack: Navigator.of(context).canPop()),
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(20, 36, 20, 16),
                        children: [
                          Text('أهلاً بك 👋', style: text.headlineSmall?.copyWith(fontSize: 26)),
                          const SizedBox(height: 12),
                          Text(
                            'أدخل رقم جوالك وبنرسل لك رمز تحقق.',
                            style: text.bodyLarge?.copyWith(color: AppColors.textSecondary),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'رقم الجوال',
                            style: text.bodyMedium?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            autofocus: true,
                            keyboardType: TextInputType.phone,
                            textDirection: TextDirection.ltr,
                            textAlign: TextAlign.right,
                            style: text.bodyLarge?.copyWith(fontSize: 16, letterSpacing: 1),
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                              LengthLimitingTextInputFormatter(10),
                            ],
                            onChanged: _vm.setPhone,
                            onSubmitted: (_) => _sendCode(),
                            decoration: const InputDecoration(
                              hintText: '05X XXX XXXX',
                              prefixIcon: Icon(Icons.smartphone_rounded, color: AppColors.textSecondary),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'بالمتابعة أنت توافق على الشروط وسياسة الخصوصية.',
                            style: text.bodySmall?.copyWith(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                      child: FilledButton(
                        onPressed: _vm.isValid ? _sendCode : null,
                        child: const Text('إرسال الرمز'),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
