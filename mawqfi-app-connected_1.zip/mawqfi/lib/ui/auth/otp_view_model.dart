import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../data/repositories/parking_repository.dart';

enum OtpResult { wrongCode, existingUser, newUser }

class OtpViewModel extends ChangeNotifier {
  OtpViewModel(this._repository, this.phone);

  final ParkingRepository _repository;
  final String phone;

  static const codeLength = 4;
  static const demoCode = '1234';
  static const resendAfter = 60;

  String code = '';
  bool hasError = false;
  bool isVerifying = false;
  int secondsLeft = resendAfter;

  Timer? _timer;
  bool _disposed = false;

  bool get isComplete => code.length == codeLength;
  bool get canResend => secondsLeft == 0;

  String get countdown {
    final m = (secondsLeft ~/ 60).toString().padLeft(2, '0');
    final s = (secondsLeft % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void start() => _startCountdown();

  void setCode(String value) {
    code = value;
    hasError = false;
    _notify();
  }

  Future<OtpResult> verify() async {
    if (!isComplete || isVerifying) return OtpResult.wrongCode;
    isVerifying = true;
    hasError = false;
    _notify();

    await Future<void>.delayed(const Duration(milliseconds: 600));

    var result = OtpResult.wrongCode;
    if (code == demoCode) {
      await _repository.signIn(phone);
      final profile = await _repository.getMyProfile();
      result = profile == null ? OtpResult.newUser : OtpResult.existingUser;
    }

    isVerifying = false;
    hasError = result == OtpResult.wrongCode;
    _notify();
    return result;
  }

  void resend() {
    if (!canResend) return;
    code = '';
    hasError = false;
    _startCountdown();
  }

  void _startCountdown() {
    _timer?.cancel();
    secondsLeft = resendAfter;
    _notify();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (secondsLeft <= 1) {
        secondsLeft = 0;
        t.cancel();
      } else {
        secondsLeft--;
      }
      _notify();
    });
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    super.dispose();
  }
}
