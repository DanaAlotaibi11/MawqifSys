import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/main_shell.dart';
import '../../app/theme.dart';
import '../../core/widgets/screen_header.dart';
import '../../data/repositories/parking_repository.dart';
import 'complete_profile_screen.dart';
import 'otp_view_model.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({super.key, required this.phone});

  final String phone;

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  late final OtpViewModel _vm = OtpViewModel(appRepository, widget.phone)..start();
  final _controller = TextEditingController();
  final _focus = FocusNode();

  @override
  void dispose() {
    _vm.dispose();
    _controller.dispose();
    _focus.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    final result = await _vm.verify();
    if (!mounted) return;
    switch (result) {
      case OtpResult.wrongCode:
        return;
      case OtpResult.newUser:
        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const CompleteProfileScreen()),
        );
      case OtpResult.existingUser:
        MainShell.tab.value = 0;
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const MainShell()),
          (_) => false,
        );
    }
  }

  void _resend() {
    _vm.resend();
    _controller.clear();
    _focus.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _vm,
              builder: (context, _) {
                return Column(
                  children: [
                    const ScreenHeader(title: 'رمز التحقق'),
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(20, 36, 20, 16),
                        children: [
                          Text('أدخل الرمز', style: text.headlineSmall?.copyWith(fontSize: 26)),
                          const SizedBox(height: 12),
                          Text.rich(
                            TextSpan(
                              text: 'أرسلنا رمز من 4 أرقام إلى ',
                              children: [
                                TextSpan(
                                  text: widget.phone,
                                  style: const TextStyle(fontWeight: FontWeight.w600),
                                ),
                              ],
                            ),
                            style: text.bodyLarge?.copyWith(color: AppColors.textSecondary),
                          ),
                          const SizedBox(height: 16),
                          _codeBoxes(context),
                          const SizedBox(height: 12),
                          if (_vm.hasError) ...[
                            _errorBox(context),
                            const SizedBox(height: 12),
                          ],
                          Center(child: _resendLabel(context)),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                      child: FilledButton(
                        onPressed: _vm.isComplete && !_vm.isVerifying ? _verify : null,
                        child: _vm.isVerifying
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                              )
                            : const Text('تحقق'),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _codeBoxes(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final code = _vm.code;

    return Stack(
      children: [
        Directionality(
          textDirection: TextDirection.ltr,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < OtpViewModel.codeLength; i++) ...[
                if (i > 0) const SizedBox(width: 12),
                Container(
                  width: 64,
                  height: 64,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: _vm.hasError ? AppColors.occupiedBg : AppColors.surface,
                    borderRadius: BorderRadius.circular(AppRadius.button),
                    border: Border.all(
                      width: 1.5,
                      color: _vm.hasError
                          ? AppColors.occupied
                          : i < code.length
                              ? AppColors.primary
                              : AppColors.border,
                    ),
                  ),
                  child: Text(
                    i < code.length ? code[i] : '',
                    style: text.headlineSmall?.copyWith(fontSize: 24),
                  ),
                ),
              ],
            ],
          ),
        ),
        Positioned.fill(
          child: Opacity(
            opacity: 0,
            child: TextField(
              controller: _controller,
              focusNode: _focus,
              autofocus: true,
              keyboardType: TextInputType.number,
              showCursor: false,
              enableInteractiveSelection: false,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(OtpViewModel.codeLength),
              ],
              onChanged: (value) {
                _vm.setCode(value);
                if (value.length == OtpViewModel.codeLength) _verify();
              },
              decoration: const InputDecoration(
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                filled: false,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _errorBox(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.occupiedBg,
        borderRadius: BorderRadius.circular(AppRadius.button),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded, size: 20, color: AppColors.occupiedText),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'الرمز غير صحيح أو منتهي. حاول مرة ثانية.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.occupiedText),
            ),
          ),
        ],
      ),
    );
  }

  Widget _resendLabel(BuildContext context) {
    final style = Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600);
    if (!_vm.canResend) {
      return Text('إعادة الإرسال بعد ${_vm.countdown}', style: style);
    }
    return TextButton(
      onPressed: _resend,
      child: const Text('إعادة إرسال الرمز'),
    );
  }
}
