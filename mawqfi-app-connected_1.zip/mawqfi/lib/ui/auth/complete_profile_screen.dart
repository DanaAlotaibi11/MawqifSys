import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/main_shell.dart';
import '../../app/theme.dart';
import '../../core/widgets/screen_header.dart';
import '../../data/repositories/parking_repository.dart';
import 'complete_profile_view_model.dart';

class CompleteProfileScreen extends StatefulWidget {
  const CompleteProfileScreen({super.key, this.repository});

  final ParkingRepository? repository;

  @override
  State<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends State<CompleteProfileScreen> {
  late final CompleteProfileViewModel _vm =
      CompleteProfileViewModel(widget.repository ?? appRepository);

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final ok = await _vm.save();
    if (!ok || !mounted) return;
    MainShell.tab.value = 0;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainShell()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _vm,
              builder: (context, _) {
                return Column(
                  children: [
                    const ScreenHeader(title: 'إنشاء حساب'),
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(20, 36, 20, 16),
                        children: [
                          Text('حيّاك في موقفي+', style: text.headlineSmall?.copyWith(fontSize: 26)),
                          const SizedBox(height: 12),
                          Text(
                            'رقمك جديد عندنا. وش نسمّيك؟',
                            style: text.bodyLarge?.copyWith(color: AppColors.textSecondary),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'الاسم',
                            style: text.bodyMedium?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            autofocus: true,
                            textCapitalization: TextCapitalization.words,
                            textInputAction: TextInputAction.done,
                            style: text.bodyLarge?.copyWith(fontSize: 16),
                            inputFormatters: [LengthLimitingTextInputFormatter(40)],
                            onChanged: _vm.setName,
                            onSubmitted: (_) => _save(),
                            decoration: const InputDecoration(
                              hintText: 'مثلاً: منار',
                              prefixIcon: Icon(Icons.person_outline_rounded, color: AppColors.textSecondary),
                            ),
                          ),
                          if (_vm.error != null) ...[
                            const SizedBox(height: 12),
                            Text(
                              _vm.error!,
                              style: text.bodyMedium?.copyWith(color: AppColors.occupiedText),
                            ),
                          ],
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                      child: FilledButton(
                        onPressed: _vm.isValid && !_vm.isSaving ? _save : null,
                        child: _vm.isSaving
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                              )
                            : const Text('متابعة'),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
