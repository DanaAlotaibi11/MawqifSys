import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import 'login_screen.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              child: Column(
                children: [
                  Expanded(
                    child: Center(
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              width: 260,
                              height: 260,
                              decoration: const BoxDecoration(
                                color: Color(0xFFE8EEF5),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.location_on_rounded, size: 110, color: AppColors.primary),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'شوف المواقف المتاحة لحظياً',
                              textAlign: TextAlign.center,
                              style: text.headlineSmall?.copyWith(fontSize: 24),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'موقفي يعرض لك المواقف الفاضية في المواقف الذكية قبل ما توصل، ويوصلك لين الموقف.',
                              textAlign: TextAlign.center,
                              style: text.bodyLarge?.copyWith(color: AppColors.textSecondary),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'نحتاج إذن الموقع عشان نعرض لك أقرب المواقف',
                              textAlign: TextAlign.center,
                              style: text.bodySmall,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  FilledButton(
                    onPressed: () => Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => const LoginScreen()),
                    ),
                    child: const Text('ابدأ'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
