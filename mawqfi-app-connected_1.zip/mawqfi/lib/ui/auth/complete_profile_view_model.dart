import 'package:flutter/foundation.dart';

import '../../data/repositories/parking_repository.dart';

class CompleteProfileViewModel extends ChangeNotifier {
  CompleteProfileViewModel(this._repository);

  final ParkingRepository _repository;

  String name = '';
  bool isSaving = false;
  String? error;

  bool get isValid => name.trim().length >= 2;

  void setName(String value) {
    name = value;
    error = null;
    notifyListeners();
  }

  Future<bool> save() async {
    if (!isValid || isSaving) return false;
    isSaving = true;
    error = null;
    notifyListeners();

    var ok = false;
    try {
      await _repository.createMyProfile(name);
      ok = true;
    } catch (e) {
      debugPrint('Create profile failed: $e');
      error = 'تعذّر حفظ الاسم، حاول مرة ثانية';
    }

    isSaving = false;
    notifyListeners();
    return ok;
  }
}
