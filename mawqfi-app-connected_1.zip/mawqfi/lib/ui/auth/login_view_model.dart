import 'package:flutter/foundation.dart';

class LoginViewModel extends ChangeNotifier {
  String phone = '';

  bool get isValid => phone.length == 10 && phone.startsWith('05');

  void setPhone(String value) {
    phone = value;
    notifyListeners();
  }
}
