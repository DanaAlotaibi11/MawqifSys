import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../auth/onboarding_screen.dart';

import '../../app/theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  static const _taglineColor = Color(0xFFC7D2E0);

  static const _introDuration = Duration(milliseconds: 1000);
  static const _holdDuration = Duration(milliseconds: 1200);
  static const _outroDuration = Duration(milliseconds: 350);

  late final AnimationController _intro =
      AnimationController(vsync: this, duration: _introDuration);
  late final AnimationController _outro =
      AnimationController(vsync: this, duration: _outroDuration);

  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _intro.forward();
    _timer = Timer(_introDuration + _holdDuration, _goNext);
  }

  Future<void> _goNext() async {
    await _outro.forward();
    if (!mounted) return;

    // بدال HomeScreen حطوا اسم الكلاس التالي (مثلاً Login) لما يجهز
    Navigator.of(context).pushReplacement(_fadeUpRoute(const OnboardingScreen()));
  }

  static Route<void> _fadeUpRoute(Widget page) => PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 500),
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, animation, __, child) {
          final curved =
              CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
          return FadeTransition(
            opacity: curved,
            child: SlideTransition(
              position: Tween(begin: const Offset(0, 0.04), end: Offset.zero)
                  .animate(curved),
              child: child,
            ),
          );
        },
      );

  Animation<double> _step(double start, double end, [Curve curve = Curves.easeOut]) =>
      CurvedAnimation(parent: _intro, curve: Interval(start, end, curve: curve));

  @override
  void dispose() {
    _timer?.cancel();
    _intro.dispose();
    _outro.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final logo = _step(0.0, 0.6, Curves.easeOutBack);
    final name = _step(0.3, 0.75);
    final tagline = _step(0.5, 1.0);
    final outro = CurvedAnimation(parent: _outro, curve: Curves.easeIn);

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: AppColors.primary,
        body: Center(
          child: FadeTransition(
            opacity: ReverseAnimation(outro),
            child: ScaleTransition(
              scale: Tween(begin: 1.0, end: 1.15).animate(outro),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    FadeTransition(
                      opacity: _step(0.0, 0.3),
                      child: ScaleTransition(
                        scale: Tween(begin: 0.6, end: 1.0).animate(logo),
                        child: Image.asset(
                          'assets/images/logo.png',
                          width: 72,
                          height: 72,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    _SlideUpFade(
                      animation: name,
                      child: const Text(
                        'موقفي',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    _SlideUpFade(
                      animation: tagline,
                      child: const Text(
                        'Mawqfi · لاقِ موقفك قبل ما توصل',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: _taglineColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _SlideUpFade extends StatelessWidget {
  const _SlideUpFade({required this.animation, required this.child});

  final Animation<double> animation;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) => Opacity(
        opacity: animation.value,
        child: Transform.translate(
          offset: Offset(0, 12 * (1 - animation.value)),
          child: child,
        ),
      ),
      child: child,
    );
  }
}
