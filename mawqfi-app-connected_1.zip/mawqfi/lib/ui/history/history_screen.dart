import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../data/models/parking_session.dart';
import '../../data/repositories/parking_repository.dart';
import 'history_detail_screen.dart';
import 'history_view_model.dart';
import 'widgets/history_tile.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key, this.repository, this.onParkingTap});

  final ParkingRepository? repository;
  final ValueChanged<ParkingSession>? onParkingTap;

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  late final HistoryViewModel _vm =
      HistoryViewModel(widget.repository ?? appRepository)..load();

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 16, bottom: 8),
                  child: Text('السجل', style: text.titleMedium),
                ),
                Expanded(
                  child: ListenableBuilder(
                    listenable: _vm,
                    builder: (context, _) {
                      if (_vm.isLoading && _vm.groups.isEmpty) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (_vm.error != null && _vm.groups.isEmpty) {
                        return _Message(
                          text: _vm.error!,
                          action: OutlinedButton(
                            onPressed: _vm.load,
                            child: const Text('إعادة المحاولة'),
                          ),
                        );
                      }
                      if (_vm.groups.isEmpty) {
                        return const _Message(text: 'ما عندك مواقف سابقة');
                      }

                      return RefreshIndicator(
                        onRefresh: _vm.load,
                        child: _list(context),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openEntry(HistoryEntry entry) {
    final custom = widget.onParkingTap;
    if (custom != null) {
      custom(entry.parking);
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => HistoryDetailScreen(entry: entry)),
    );
  }

  Widget _list(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      children: [
        for (final group in _vm.groups) ...[
          Text(group.label, style: text.bodySmall),
          const SizedBox(height: 8),
          for (final entry in group.entries) ...[
            HistoryTile(
              entry: entry,
              onTap: () => _openEntry(entry),
            ),
            const SizedBox(height: 10),
          ],
          const SizedBox(height: 8),
        ],
      ],
    );
  }
}

class _Message extends StatelessWidget {
  const _Message({required this.text, this.action});

  final String text;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(text, style: Theme.of(context).textTheme.bodyMedium),
          if (action != null) ...[const SizedBox(height: 12), action!],
        ],
      ),
    );
  }
}
