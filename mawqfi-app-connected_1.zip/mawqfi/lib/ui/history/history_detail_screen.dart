import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/screen_header.dart';
import '../spot_details/spot_details_screen.dart';
import 'history_view_model.dart';

class HistoryDetailScreen extends StatelessWidget {
  const HistoryDetailScreen({super.key, required this.entry});

  final HistoryEntry entry;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final p = entry.parking;
    final location = [
      entry.facilityName,
      if (entry.floorName.isNotEmpty) entry.floorName,
      if (entry.zoneName.isNotEmpty) 'المنطقة ${entry.zoneName}',
    ].join(' · ');

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: Column(
              children: [
                const ScreenHeader(title: 'تفاصيل الجلسة'),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                    children: [
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(entry.spotCode, style: text.headlineSmall?.copyWith(fontSize: 30)),
                              const SizedBox(height: 4),
                              Text(location, style: text.bodySmall),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                          child: Column(
                            children: [
                              _Row(label: 'التاريخ', value: formatDate(p.startedAt)),
                              const Divider(),
                              _Row(label: 'الدخول', value: formatTime(p.startedAt)),
                              const Divider(),
                              _Row(
                                label: 'الخروج',
                                value: p.endedAt == null ? 'جارٍ الآن' : formatTime(p.endedAt!),
                                valueColor: p.isActive ? AppColors.availableText : null,
                              ),
                              const Divider(),
                              _Row(label: 'المدة', value: formatDuration(p.duration())),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (!p.isActive)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                    child: FilledButton(
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => SpotDetailsScreen(spotId: p.spotId)),
                      ),
                      child: const Text('اوقف في نفس الموقف'),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({required this.label, required this.value, this.valueColor});

  final String label;
  final String value;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          Expanded(child: Text(label, style: text.bodyMedium)),
          Text(
            value,
            style: text.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: valueColor ?? AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
