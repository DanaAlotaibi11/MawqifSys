import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../data/models/parking_session.dart';
import '../../data/repositories/parking_repository.dart';

class HistoryEntry {
  const HistoryEntry({
    required this.parking,
    required this.spotCode,
    required this.facilityName,
    required this.zoneName,
    this.floorName = '',
  });

  final ParkingSession parking;
  final String spotCode;
  final String facilityName;
  final String zoneName;
  final String floorName;
}

class HistoryGroup {
  const HistoryGroup({required this.label, required this.entries});

  final String label;
  final List<HistoryEntry> entries;
}

class HistoryViewModel extends ChangeNotifier {
  HistoryViewModel(this._repository) {
    _repository.parkingChanges.addListener(load);
  }

  final ParkingRepository _repository;

  bool isLoading = false;
  String? error;
  List<HistoryGroup> groups = [];
  bool _disposed = false;

  static const _months = [
    'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
  ];

  Future<void> load() async {
    isLoading = true;
    error = null;
    _notify();

    try {
      final (parkings, spots, zones, floors, facilities) = await (
        _repository.getMyParkings(),
        _repository.getSpots(),
        _repository.getZones(),
        _repository.getFloors(),
        _repository.getFacilities(),
      ).wait;

      final spotById = {for (final s in spots) s.id: s};
      final zoneById = {for (final z in zones) z.id: z};
      final floorById = {for (final f in floors) f.id: f};
      final facilityById = {for (final f in facilities) f.id: f};

      final entries = <HistoryEntry>[];
      for (final p in parkings) {
        final spot = spotById[p.spotId];
        final zone = zoneById[spot?.zoneId];
        final floor = floorById[zone?.floorId];
        final facility = facilityById[floor?.facilityId];
        entries.add(HistoryEntry(
          parking: p,
          spotCode: spot?.code ?? '?',
          facilityName: _shortName(facility?.name ?? ''),
          zoneName: zone?.name ?? '',
          floorName: floor?.name ?? '',
        ));
      }

      final result = <HistoryGroup>[];
      for (final e in entries) {
        final label = _dayLabel(e.parking.startedAt.toLocal());
        if (result.isNotEmpty && result.last.label == label) {
          result.last.entries.add(e);
        } else {
          result.add(HistoryGroup(label: label, entries: [e]));
        }
      }
      groups = result;
    } catch (e) {
      debugPrint('History load failed: $e');
      error = 'تعذّر تحميل السجل';
    }

    isLoading = false;
    _notify();
  }

  static String _shortName(String name) => name.split(' · ').first;

  static String _dayLabel(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(date.year, date.month, date.day);
    final diff = today.difference(day).inDays;
    if (diff == 0) return 'اليوم';
    if (diff == 1) return 'أمس';
    final label = '${date.day} ${_months[date.month - 1]}';
    return date.year == now.year ? label : '$label ${date.year}';
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _repository.parkingChanges.removeListener(load);
    super.dispose();
  }
}
