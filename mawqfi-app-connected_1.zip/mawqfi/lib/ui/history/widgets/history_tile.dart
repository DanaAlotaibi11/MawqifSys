import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../history_view_model.dart';

class HistoryTile extends StatelessWidget {
  const HistoryTile({super.key, required this.entry, this.onTap});

  final HistoryEntry entry;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final p = entry.parking;
    final start = _time(p.startedAt.toLocal());
      final detail = p.isActive ? '$start · جارٍ الآن' : '$start · ${_duration(p.duration())}';

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(entry.spotCode, style: text.titleSmall),
                    Text(
                      '${entry.facilityName} · المنطقة ${entry.zoneName}',
                      style: text.bodySmall,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                detail,
                style: text.labelMedium?.copyWith(
                  fontWeight: FontWeight.w400,
                  color: p.isActive ? AppColors.availableText : AppColors.textSecondary,
                ),
              ),
              const SizedBox(width: 4),
              const Icon(Icons.chevron_left, color: AppColors.textMuted),
            ],
          ),
        ),
      ),
    );
  }

  static String _time(DateTime t) {
    final h = t.hour % 12 == 0 ? 12 : t.hour % 12;
    final m = t.minute.toString().padLeft(2, '0');
    return '$h:$m ${t.hour < 12 ? 'ص' : 'م'}';
  }

  static String _duration(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes % 60;
    if (h > 0 && m > 0) return '$h س $m د';
    if (h > 0) return '$h س';
    if (m > 0) return '$m د';
    return 'أقل من دقيقة';
  }
}
