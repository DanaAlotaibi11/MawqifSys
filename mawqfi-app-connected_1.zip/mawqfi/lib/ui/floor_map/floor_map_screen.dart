import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../core/widgets/spot_tile.dart';
import '../../core/widgets/status_badge.dart';
import '../../data/models/spot.dart';
import '../../data/repositories/parking_repository.dart';
import '../../core/utils/time_ago.dart';
import '../availability_list/availability_list_screen.dart';
import '../spot_details/spot_details_screen.dart';
import 'floor_map_view_model.dart';

class FloorMapScreen extends StatefulWidget {
  const FloorMapScreen({
    super.key,
    required this.facilityId,
    this.floorId,
    this.repository,
    this.onSpotTap,
  });

  static const routeName = 'floor-map';

  final String facilityId;
  final String? floorId;
  final ParkingRepository? repository;
  final ValueChanged<Spot>? onSpotTap;

  @override
  State<FloorMapScreen> createState() => _FloorMapScreenState();
}

class _FloorMapScreenState extends State<FloorMapScreen> {
  late final FloorMapViewModel _vm = FloorMapViewModel(
    widget.repository ?? appRepository,
    widget.facilityId,
    initialFloorId: widget.floorId,
  )..start();

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _vm,
              builder: (context, _) {
                if (_vm.isLoading && _vm.facility == null) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (_vm.error != null && _vm.facility == null) {
                  return Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_vm.error!, style: Theme.of(context).textTheme.bodyMedium),
                        const SizedBox(height: 12),
                        OutlinedButton(onPressed: _vm.load, child: const Text('إعادة المحاولة')),
                      ],
                    ),
                  );
                }
                return Column(
                  children: [
                    _header(context),
                    if (_vm.isOffline) _offlineBanner(context),
                    _summary(context),
                    Expanded(
                      child: RefreshIndicator(
                        onRefresh: _vm.load,
                        child: _content(context),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _header(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final floorName = _vm.selectedFloor?.name ?? '';
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
      child: Row(
        children: [
          const BackButton(color: AppColors.textPrimary),
          Expanded(
            child: Text(
              '${_vm.facilityShortName} · $floorName',
              textAlign: TextAlign.center,
              style: text.titleMedium,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 48),
        ],
      ),
    );
  }

  Widget _offlineBanner(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(20, 8, 20, 0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.warningBg,
        borderRadius: BorderRadius.circular(AppRadius.button),
      ),
      child: Row(
        children: [
          const Icon(Icons.wifi_off_rounded, size: 20, color: AppColors.warning),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'غير متصل · الحالات المعروضة من آخر تحديث وقد تكون تغيّرت',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.textPrimary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _summary(BuildContext context) {
    final text = Theme.of(context).textTheme;
    const gap = SizedBox(height: 14);

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 8,
          runSpacing: 8,
          children: [
            StatusBadge(label: '${_vm.freeCount} متاح', tone: BadgeTone.available),
            StatusBadge(label: '${_vm.occupiedCount} مشغول', tone: BadgeTone.occupied),
            StatusBadge(label: '${_vm.unknownCount} غير معروف', tone: BadgeTone.unknown),
          ],
        ),
        if (_vm.floors.length > 1) ...[
          gap,
          _floorPicker(),
        ],
        gap,
        Row(
          children: [
            Expanded(
              child: Text(
                _vm.lastUpdate == null ? 'آخر تحديث: غير معروف' : 'آخر تحديث: ${timeAgo(_vm.lastUpdate!)}',
                style: text.bodySmall,
              ),
            ),
            if (_vm.isOffline)
              TextButton(
                onPressed: _vm.load,
                child: const Text('إعادة المحاولة'),
              ),
            TextButton.icon(
              onPressed: _openList,
              icon: const Icon(Icons.format_list_bulleted_rounded, size: 20),
              label: const Text('عرض القائمة'),
              style: TextButton.styleFrom(
                foregroundColor: AppColors.primary,
                backgroundColor: AppColors.surfaceMuted,
                textStyle: text.labelMedium?.copyWith(fontWeight: FontWeight.w700, fontSize: 14),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.pill)),
              ),
            ),
          ],
        ),
        ],
      ),
    );
  }

  Widget _content(BuildContext context) {
    final text = Theme.of(context).textTheme;
    const gap = SizedBox(height: 14);

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
      children: [
        for (var i = 0; i < _vm.sections.length; i++) ...[
          _zoneHeader(context, _vm.sections[i]),
          const SizedBox(height: 10),
          _zoneGrid(_vm.sections[i]),
          if (i < _vm.sections.length - 1) ...[
            gap,
            const _Aisle(),
            gap,
          ],
        ],
        if (_vm.sections.isEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 40),
            child: Text('لا توجد مواقف في هذا الدور', textAlign: TextAlign.center, style: text.bodyMedium),
          )
        else ...[
          gap,
          const _Entrance(),
        ],
      ],
    );
  }

  Widget _floorPicker() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (final floor in _vm.floors) ...[
            ChoiceChip(
              label: Text(floor.name),
              selected: floor.id == _vm.selectedFloorId,
              onSelected: (_) => _vm.selectFloor(floor.id),
              selectedColor: AppColors.primary,
              labelStyle: TextStyle(
                fontWeight: FontWeight.w600,
                color: floor.id == _vm.selectedFloorId ? Colors.white : AppColors.textPrimary,
              ),
              showCheckmark: false,
              side: const BorderSide(color: AppColors.border),
              backgroundColor: AppColors.surface,
            ),
            const SizedBox(width: 8),
          ],
        ],
      ),
    );
  }

  Widget _zoneHeader(BuildContext context, ZoneSection section) {
    final text = Theme.of(context).textTheme;
    final free = section.freeCount;
    return Row(
      children: [
        Expanded(child: Text('المنطقة ${section.zone.name}', style: text.titleSmall)),
        Text(
          free == 0 ? 'ممتلئة' : '$free متاح',
          style: text.labelMedium?.copyWith(
            color: free == 0 ? AppColors.occupiedText : AppColors.availableText,
          ),
        ),
      ],
    );
  }

  Widget _zoneGrid(ZoneSection section) {
    return GridView.count(
      crossAxisCount: 5,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 62 / 72,
      children: [
        for (final spot in section.spots)
          SpotTile(
            spot: spot,
            onTap: () => _openSpot(spot),
          ),
      ],
    );
  }

  void _openList() {
    final floorId = _vm.selectedFloorId;
    if (floorId == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => AvailabilityListScreen(floorId: floorId, onSpotTap: widget.onSpotTap),
      ),
    );
  }

  void _openSpot(Spot spot) {
    final custom = widget.onSpotTap;
    if (custom != null) {
      custom(spot);
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SpotDetailsScreen(spotId: spot.id)),
    );
  }

}

class _Aisle extends StatelessWidget {
  const _Aisle();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      decoration: BoxDecoration(
        color: AppColors.surfaceMuted,
        borderRadius: BorderRadius.circular(AppRadius.tile),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.arrow_forward_rounded, size: 16, color: AppColors.textMuted),
          const SizedBox(width: 8),
          Text('ممر السيارات', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(width: 8),
          const Icon(Icons.arrow_back_rounded, size: 16, color: AppColors.textMuted),
        ],
      ),
    );
  }
}

class _Entrance extends StatelessWidget {
  const _Entrance();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.arrow_upward_rounded, size: 18, color: AppColors.primary),
        const SizedBox(width: 4),
        Text(
          'المدخل',
          style: Theme.of(context).textTheme.labelMedium?.copyWith(color: AppColors.primary),
        ),
      ],
    );
  }
}
