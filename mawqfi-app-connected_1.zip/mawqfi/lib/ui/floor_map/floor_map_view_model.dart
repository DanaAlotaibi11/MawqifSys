import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../data/models/facility.dart';
import '../../data/models/floor.dart';
import '../../data/models/spot.dart';
import '../../data/models/spot_status.dart';
import '../../data/models/zone.dart';
import '../../data/repositories/parking_repository.dart';

class ZoneSection {
  const ZoneSection({required this.zone, required this.spots});

  final Zone zone;
  final List<Spot> spots;

  int get freeCount =>
      spots.where((s) => s.displayStatus() == SpotStatus.free).length;
}

class FloorMapViewModel extends ChangeNotifier {
  FloorMapViewModel(this._repository, this.facilityId, {String? initialFloorId})
      : selectedFloorId = initialFloorId;

  final ParkingRepository _repository;
  final String facilityId;

  static const refreshEvery = Duration(seconds: 15);

  bool isLoading = false;
  String? error;
  Facility? facility;
  List<Floor> floors = [];
  String? selectedFloorId;
  List<ZoneSection> sections = [];
  int freeCount = 0;
  int occupiedCount = 0;
  int unknownCount = 0;
  DateTime? lastUpdate;
  bool isOffline = false;

  List<Zone> _zones = [];
  List<Spot> _spots = [];
  Timer? _timer;
  bool _disposed = false;

  Floor? get selectedFloor {
    for (final f in floors) {
      if (f.id == selectedFloorId) return f;
    }
    return null;
  }

  String get facilityShortName => (facility?.name ?? '').split(' · ').first;

  void start() {
    load();
    _timer = Timer.periodic(refreshEvery, (_) => load(silent: true));
  }

  Future<void> load({bool silent = false}) async {
    if (!silent) {
      isLoading = true;
      error = null;
      _notify();
    }

    try {
      final (allFacilities, allFloors, zones, spots) = await (
        _repository.getFacilities(),
        _repository.getFloors(),
        _repository.getZones(),
        _repository.getSpots(),
      ).wait;

      facility = allFacilities.firstWhere((f) => f.id == facilityId);
      floors = allFloors.where((f) => f.facilityId == facilityId).toList()
        ..sort((a, b) => a.level.compareTo(b.level));
      _zones = zones;
      _spots = spots;

      if (selectedFloor == null && floors.isNotEmpty) {
        selectedFloorId = floors
            .firstWhere((f) => f.level == 0, orElse: () => floors.first)
            .id;
      }
      _rebuild();
      error = null;
      isOffline = false;
    } catch (e) {
      debugPrint('Floor map load failed: $e');
      if (facility != null) {
        isOffline = true;
      } else if (!silent) {
        error = 'تعذّر تحميل خريطة الموقف';
      }
    }

    isLoading = false;
    _notify();
  }

  void selectFloor(String floorId) {
    if (floorId == selectedFloorId) return;
    selectedFloorId = floorId;
    _rebuild();
    _notify();
  }

  void _rebuild() {
    final floorZones = _zones.where((z) => z.floorId == selectedFloorId).toList()
      ..sort((a, b) => a.name.compareTo(b.name));

    sections = [
      for (final zone in floorZones)
        ZoneSection(
          zone: zone,
          spots: _spots.where((s) => s.zoneId == zone.id).toList()
            ..sort((a, b) => a.code.compareTo(b.code)),
        ),
    ];

    final all = [for (final s in sections) ...s.spots];
    freeCount = all.where((s) => s.displayStatus() == SpotStatus.free).length;
    occupiedCount = all.where((s) => s.displayStatus() == SpotStatus.occupied).length;
    unknownCount = all.where((s) => s.displayStatus() == SpotStatus.unknown).length;

    DateTime? latest;
    for (final s in all) {
      final t = s.reportedAt;
      if (t != null && (latest == null || t.isAfter(latest))) latest = t;
    }
    lastUpdate = latest;
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    super.dispose();
  }
}
