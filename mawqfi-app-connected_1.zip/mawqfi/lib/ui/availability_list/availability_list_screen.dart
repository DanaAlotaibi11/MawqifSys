import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';
import '../../core/widgets/status_badge.dart';
import '../../data/models/spot.dart';
import '../../data/repositories/parking_repository.dart';
import '../spot_details/spot_details_screen.dart';
import 'availability_list_view_model.dart';

class AvailabilityListScreen extends StatefulWidget {
  const AvailabilityListScreen({
    super.key,
    required this.floorId,
    this.repository,
    this.onSpotTap,
  });

  final String floorId;
  final ParkingRepository? repository;
  final ValueChanged<Spot>? onSpotTap;

  @override
  State<AvailabilityListScreen> createState() => _AvailabilityListScreenState();
}

class _AvailabilityListScreenState extends State<AvailabilityListScreen> {
  late final AvailabilityListViewModel _vm = AvailabilityListViewModel(
    widget.repository ?? appRepository,
    widget.floorId,
  )..start();

  @override
  void dispose() {
    _vm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: AppColors.background,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _vm,
              builder: (context, _) {
                return Column(
                  children: [
                    _header(context),
                    Expanded(child: _body(context)),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _header(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
      child: Row(
        children: [
          const BackButton(color: AppColors.textPrimary),
          Expanded(
            child: Text(
              'المواقف المتاحة',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 18),
            ),
          ),
          const SizedBox(width: 48),
        ],
      ),
    );
  }

  Widget _body(BuildContext context) {
    final text = Theme.of(context).textTheme;

    if (_vm.isLoading && _vm.zones.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_vm.error != null && _vm.zones.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_vm.error!, style: text.bodyMedium),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: _vm.load, child: const Text('إعادة المحاولة')),
          ],
        ),
      );
    }

    final spots = _vm.visibleSpots;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _filters(),
              const SizedBox(height: 12),
              Text(
                spots.isEmpty
                    ? 'لا توجد مواقف متاحة حالياً'
                    : '${_countLabel(spots.length)} · مرتبة حسب القرب من المدخل',
                style: text.bodySmall,
              ),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
      onRefresh: _vm.load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
        children: [
          for (var i = 0; i < spots.length; i++) ...[
            _SpotRow(
              spot: spots[i],
              subtitle: _subtitle(spots[i], isNearest: i == 0),
              onTap: () => _openSpot(spots[i]),
            ),
            const SizedBox(height: 12),
          ],
        ],
      ),
          ),
        ),
      ],
    );
  }

  Widget _filters() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          _chip('الكل', null),
          for (final zone in _vm.zones) _chip('المنطقة ${zone.name}', zone.id),
        ],
      ),
    );
  }

  Widget _chip(String label, String? zoneId) {
    final selected = _vm.selectedZoneId == zoneId;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => _vm.selectZone(zoneId),
        showCheckmark: false,
        selectedColor: AppColors.primary,
        backgroundColor: AppColors.surface,
        side: BorderSide(color: selected ? AppColors.primary : AppColors.border),
        shape: const StadiumBorder(),
        labelStyle: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: selected ? Colors.white : AppColors.textPrimary,
        ),
      ),
    );
  }

  String _subtitle(Spot spot, {required bool isNearest}) {
    final zone = 'المنطقة ${_vm.zoneName(spot.zoneId)}';
    final distance = spot.distanceToEntranceM;
    if (isNearest && distance != null) return '$zone · الأقرب للمدخل';
    if (distance != null) return '$zone · $distance م';
    return zone;
  }

  String _countLabel(int n) {
    if (n == 1) return 'موقف واحد متاح';
    if (n == 2) return 'موقفان متاحان';
    if (n <= 10) return '$n مواقف متاحة';
    return '$n موقف متاح';
  }

  void _openSpot(Spot spot) {
    final custom = widget.onSpotTap;
    if (custom != null) {
      custom(spot);
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SpotDetailsScreen(spotId: spot.id)),
    );
  }
}

class _SpotRow extends StatelessWidget {
  const _SpotRow({required this.spot, required this.subtitle, required this.onTap});

  final Spot spot;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Material(
      color: AppColors.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.button),
        side: const BorderSide(color: AppColors.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(spot.code, style: text.titleSmall),
                    Text(subtitle, style: text.bodySmall?.copyWith(fontSize: 12)),
                  ],
                ),
              ),
              const StatusBadge(label: 'متاح', tone: BadgeTone.available),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_left_rounded, size: 20, color: AppColors.textSecondary),
            ],
          ),
        ),
      ),
    );
  }
}
