import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../data/models/spot.dart';
import '../../data/models/spot_status.dart';
import '../../data/models/zone.dart';
import '../../data/repositories/parking_repository.dart';

class AvailabilityListViewModel extends ChangeNotifier {
  AvailabilityListViewModel(this._repository, this.floorId);

  final ParkingRepository _repository;
  final String floorId;

  static const refreshEvery = Duration(seconds: 15);

  bool isLoading = false;
  String? error;
  List<Zone> zones = [];
  String? selectedZoneId;

  List<Spot> _freeSpots = [];
  Timer? _timer;
  bool _disposed = false;

  List<Spot> get visibleSpots => selectedZoneId == null
      ? _freeSpots
      : _freeSpots.where((s) => s.zoneId == selectedZoneId).toList();

  String zoneName(String zoneId) {
    for (final z in zones) {
      if (z.id == zoneId) return z.name;
    }
    return '';
  }

  void start() {
    load();
    _timer = Timer.periodic(refreshEvery, (_) => load(silent: true));
  }

  Future<void> load({bool silent = false}) async {
    if (!silent) {
      isLoading = true;
      error = null;
      _notify();
    }

    try {
      final (allZones, spots) = await (
        _repository.getZones(),
        _repository.getSpots(),
      ).wait;

      zones = allZones.where((z) => z.floorId == floorId).toList()
        ..sort((a, b) => a.name.compareTo(b.name));
      final zoneIds = {for (final z in zones) z.id};

      _freeSpots = spots
          .where((s) => zoneIds.contains(s.zoneId) && s.displayStatus() == SpotStatus.free)
          .toList()
        ..sort(_byDistance);

      if (selectedZoneId != null && !zoneIds.contains(selectedZoneId)) {
        selectedZoneId = null;
      }
      error = null;
    } catch (e) {
      debugPrint('Availability list load failed: $e');
      if (!silent) error = 'تعذّر تحميل المواقف المتاحة';
    }

    isLoading = false;
    _notify();
  }

  void selectZone(String? zoneId) {
    if (zoneId == selectedZoneId) return;
    selectedZoneId = zoneId;
    _notify();
  }

  static int _byDistance(Spot a, Spot b) {
    final da = a.distanceToEntranceM;
    final db = b.distanceToEntranceM;
    if (da != null && db != null && da != db) return da.compareTo(db);
    if (da == null && db != null) return 1;
    if (da != null && db == null) return -1;
    return a.code.compareTo(b.code);
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    super.dispose();
  }
}
