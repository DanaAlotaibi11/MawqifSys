enum SpotStatus {
  free,
  occupied,
  unknown;

  static SpotStatus fromString(String? value) => switch (value?.toUpperCase()) {
        'FREE' => SpotStatus.free,
        'OCCUPIED' => SpotStatus.occupied,
        _ => SpotStatus.unknown,
      };
}
