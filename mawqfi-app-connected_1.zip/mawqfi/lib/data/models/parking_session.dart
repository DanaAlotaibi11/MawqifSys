
class ParkingSession {
  const ParkingSession({
    required this.id,
    required this.userId,
    required this.spotId,
    required this.startedAt,
    this.endedAt,
  });

  final String id;
  final String userId;
  final String spotId;
  final DateTime startedAt;
  final DateTime? endedAt;

  bool get isActive => endedAt == null;

  Duration duration([DateTime? now]) =>
      (endedAt ?? now ?? DateTime.now()).difference(startedAt);

  factory ParkingSession.fromJson(Map<String, dynamic> json) => ParkingSession(
        id: json['id'] as String,
        userId: json['user_id'] as String,
        spotId: json['spot_id'] as String,
        startedAt: DateTime.parse(json['started_at'] as String),
        endedAt: DateTime.tryParse(json['ended_at'] as String? ?? ''),
      );
}
