class Zone {
  const Zone({
    required this.id,
    required this.floorId,
    required this.name,
  });

  final String id;
  final String floorId;
  final String name;

  factory Zone.fromJson(Map<String, dynamic> json) => Zone(
        id: json['id'] as String,
        floorId: json['floor_id'] as String,
        name: json['name'] as String,
      );
}
