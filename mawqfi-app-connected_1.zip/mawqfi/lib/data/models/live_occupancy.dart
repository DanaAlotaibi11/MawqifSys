/// Live numbers from Hajar's analytics engine (backend: GET /analytics/live).
class LiveOccupancy {
  const LiveOccupancy({
    required this.spots,
    required this.busy,
    required this.free,
    required this.unknown,
    required this.busyPct,
  });

  /// enabled spots in the group (disabled spots are not counted)
  final int spots;
  final int busy;
  final int free;

  /// spots whose sensor is silent right now
  final int unknown;
  final double busyPct;

  factory LiveOccupancy.fromJson(Map<String, dynamic> json) => LiveOccupancy(
        spots: (json['spots'] as num).toInt(),
        busy: (json['busy'] as num).toInt(),
        free: (json['free'] as num).toInt(),
        unknown: (json['unknown'] as num).toInt(),
        busyPct: (json['busy_pct'] as num).toDouble(),
      );
}
