class Floor {
  const Floor({
    required this.id,
    required this.facilityId,
    required this.name,
    this.level = 0,
  });

  final String id;
  final String facilityId;
  final String name;

  /// dana
  final int level;

  factory Floor.fromJson(Map<String, dynamic> json) => Floor(
        id: json['id'] as String,
        facilityId: json['facility_id'] as String,
        name: json['name'] as String,
        level: (json['level'] as num?)?.toInt() ?? 0,
      );
}
