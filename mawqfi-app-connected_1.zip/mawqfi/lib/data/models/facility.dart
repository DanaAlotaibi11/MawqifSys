class Facility {
  const Facility({
    required this.id,
    required this.locationId,
    required this.name,
    this.latitude,
    this.longitude,
  });

  final String id;
  final String locationId;
  final String name;


  /// dana
  final double? latitude;
  final double? longitude;

  factory Facility.fromJson(Map<String, dynamic> json) => Facility(
        id: json['id'] as String,
        locationId: json['location_id'] as String,
        name: json['name'] as String,
        latitude: (json['latitude'] as num?)?.toDouble(),
        longitude: (json['longitude'] as num?)?.toDouble(),
      );
}

