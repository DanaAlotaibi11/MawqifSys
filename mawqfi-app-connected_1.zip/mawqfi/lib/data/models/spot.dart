import 'spot_status.dart';

class Spot {
  const Spot({
    required this.id,
    required this.zoneId,
    required this.code,
    required this.status,
    this.reportedAt,
    this.distanceToEntranceM,
  });

  final String id;
  final String zoneId;
  final String code;
  final SpotStatus status;
  final DateTime? reportedAt;

  /// dana
  final int? distanceToEntranceM;

  static const staleAfter = Duration(minutes: 7);

  SpotStatus displayStatus([DateTime? now]) {
    final reported = reportedAt;
    if (reported == null) return SpotStatus.unknown;
    final age = (now ?? DateTime.now()).difference(reported);
    return age > staleAfter ? SpotStatus.unknown : status;
  }

  factory Spot.fromJson(Map<String, dynamic> json) => Spot(
        id: json['id'] as String,
        zoneId: json['zone_id'] as String,
        code: json['spot_code'] as String,
        status: SpotStatus.fromString(json['status'] as String?),
        reportedAt: DateTime.tryParse(json['reported_at'] as String? ?? ''),
        distanceToEntranceM: (json['distance_to_entrance_m'] as num?)?.toInt(),
      );
}
