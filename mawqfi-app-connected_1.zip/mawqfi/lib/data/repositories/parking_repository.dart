import 'dart:async';
import 'dart:collection';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:http/http.dart' as http;

import '../models/facility.dart';
import '../models/floor.dart';
import '../models/live_occupancy.dart';
import '../models/parking_session.dart';
import '../models/profile.dart';
import '../models/spot.dart';
import '../models/zone.dart';

abstract class ParkingRepository {
  Future<void> signIn(String phone);

  Future<void> signOut();

  Future<Profile?> getMyProfile();

  Future<Profile> createMyProfile(String name);

  Future<Profile> getCurrentUser();

  Future<List<Facility>> getFacilities();

  Future<List<Floor>> getFloors();

  Future<List<Zone>> getZones();

  Future<List<Spot>> getSpots();

  /// Live free / busy numbers from the analytics engine.
  /// level: location | facility | floor | zone. Returns null when not available.
  Future<LiveOccupancy?> getLiveOccupancy(String level, String id);

  Future<List<ParkingSession>> getMyParkings();

  Future<ParkingSession> startParking(String spotId);

  Future<void> endParking(String parkingId);

  Listenable get parkingChanges;
}

/// Backend address. Change it with:  flutter run --dart-define=BACKEND_URL=http://192.168.1.20:3000
/// - Chrome / iOS simulator on the same computer: http://localhost:3000
/// - Android emulator: http://10.0.2.2:3000
/// - A real phone: the computer's IP on the same Wi-Fi, e.g. http://192.168.1.20:3000
const String backendUrl =
    String.fromEnvironment('BACKEND_URL', defaultValue: 'http://localhost:3000');

/// The app now reads real data from the backend.
/// To go back to the offline mock data, use:  MockParkingRepository()
final ParkingRepository appRepository = ApiParkingRepository();

class MockParkingRepository implements ParkingRepository {
  MockParkingRepository({this.assetPath = 'assets/data/mock_data.json'});

  final String assetPath;

  Map<String, dynamic>? _data;

  Future<List<Map<String, dynamic>>> _table(String name) async {
    _data ??= jsonDecode(await rootBundle.loadString(assetPath))
        as Map<String, dynamic>;

    return (_data![name] as List).cast<Map<String, dynamic>>();
  }

  static String? _signedInPhone;
  static final List<Profile> _createdProfiles = [];

  @override
  Future<void> signIn(String phone) async {
    _signedInPhone = _normalizePhone(phone);
  }

  @override
  Future<void> signOut() async {
    _signedInPhone = null;
  }

  @override
  Future<Profile?> getMyProfile() async {
    final phone = _signedInPhone;
    if (phone == null) return null;
    final all = [
      ...(await _table('profiles')).map(Profile.fromJson),
      ..._createdProfiles,
    ];
    return all
        .where((p) => p.phone != null && _normalizePhone(p.phone!) == phone)
        .firstOrNull;
  }

  @override
  Future<Profile> createMyProfile(String name) async {
    final phone = _signedInPhone;
    if (phone == null) throw StateError('Not signed in');
    final profile = Profile(
      id: 'user-local-${DateTime.now().millisecondsSinceEpoch}',
      name: name.trim(),
      phone: '+966${phone.substring(1)}',
    );
    _createdProfiles.add(profile);
    return profile;
  }

  @override
  Future<Profile> getCurrentUser() async {
    final me = await getMyProfile();
    if (me != null) return me;
    return Profile.fromJson((await _table('profiles')).first);
  }

  static String _normalizePhone(String phone) {
    final digits = phone.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.startsWith('966')) return '0${digits.substring(3)}';
    return digits;
  }

  @override
  Future<List<Facility>> getFacilities() async =>
      (await _table('facilities')).map(Facility.fromJson).toList();

  @override
  Future<List<Floor>> getFloors() async =>
      (await _table('floors')).map(Floor.fromJson).toList();

  @override
  Future<List<Zone>> getZones() async =>
      (await _table('zones')).map(Zone.fromJson).toList();

  @override
  Future<List<Spot>> getSpots() async {
    final now = DateTime.now();
    final silentSince = now.subtract(const Duration(minutes: 8));

    return (await _table('spots'))
        .map((row) => Spot.fromJson({
              ...row,
              'reported_at': (row['status'] == 'UNKNOWN' ? silentSince : now).toIso8601String(),
            }))
        .toList();
  }

  @override
  Future<LiveOccupancy?> getLiveOccupancy(String level, String id) async => null;

  static final _changes = ValueNotifier<int>(0);

  static Duration? _shift;

  static final List<ParkingSession> _started = [];

  static final Map<String, DateTime> _endedAt = {};

  @override
  Listenable get parkingChanges => _changes;

  @override
  Future<List<ParkingSession>> getMyParkings() async {
    final me = await getCurrentUser();

    final allSeeded = (await _table('parkings')).map(ParkingSession.fromJson).toList();
    final seeded = allSeeded.where((p) => p.userId == me.id).toList();

    final seededActive = allSeeded.where((p) => p.isActive).firstOrNull;
    _shift ??= seededActive == null
        ? Duration.zero
        : DateTime.now().subtract(const Duration(minutes: 85)).difference(seededActive.startedAt);
    final shift = _shift!;

    final all = [
      for (final p in seeded)
        ParkingSession(
          id: p.id,
          userId: p.userId,
          spotId: p.spotId,
          startedAt: p.startedAt.add(shift),
          endedAt: _endedAt[p.id] ?? p.endedAt?.add(shift),
        ),
      for (final p in _started.where((p) => p.userId == me.id))
        ParkingSession(
          id: p.id,
          userId: p.userId,
          spotId: p.spotId,
          startedAt: p.startedAt,
          endedAt: _endedAt[p.id],
        ),
    ]..sort((a, b) => b.startedAt.compareTo(a.startedAt));
    return all;
  }

  @override
  Future<ParkingSession> startParking(String spotId) async {
    final me = await getCurrentUser();
    final now = DateTime.now();

    for (final p in await getMyParkings()) {
      if (p.isActive) _endedAt[p.id] = now;
    }

    final session = ParkingSession(
      id: 'park-local-${now.millisecondsSinceEpoch}',
      userId: me.id,
      spotId: spotId,
      startedAt: now,
    );
    _started.add(session);

    _changes.value++;
    return session;
  }

  @override
  Future<void> endParking(String parkingId) async {
    _endedAt[parkingId] = DateTime.now();
    _changes.value++;
  }
}


/// Talks to the Mawqfi backend (Express + Supabase).
///
/// Real data from the backend:
///   facilities, floors, zones, spots   -> GET /locations, /facilities, /floors, /zones, /spots
///   live free / busy (analytics)       -> GET /analytics/live
///
/// Still local (mock) until the backend has matching endpoints:
///   sign in with phone + OTP, profile, "I parked here" and parking history.
///   (The backend signs in with email + password, and has no parking routes yet.)
class ApiParkingRepository implements ParkingRepository {
  ApiParkingRepository({String? baseUrl, http.Client? client, ParkingRepository? local})
      : _base = baseUrl ?? backendUrl,
        _client = client ?? http.Client(),
        _local = local ?? MockParkingRepository();

  final String _base;
  final http.Client _client;
  final ParkingRepository _local;

  static const _timeout = Duration(seconds: 10);

  Future<dynamic> _get(String path, [Map<String, String>? query]) async {
    final uri = Uri.parse('$_base$path').replace(queryParameters: query);
    final res = await _client.get(uri).timeout(_timeout);
    if (res.statusCode != 200) {
      throw Exception('GET $path failed (${res.statusCode}): ${res.body}');
    }
    return jsonDecode(utf8.decode(res.bodyBytes));
  }

  Future<List<Map<String, dynamic>>> _list(String path) async =>
      (await _get(path) as List).cast<Map<String, dynamic>>();

  static double? _number(dynamic v) {
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v);
    return null;
  }

  // ---------- buildings: database names -> app names ----------

  @override
  Future<List<Facility>> getFacilities() async {
    final (locations, facilities) = await (_list('/locations'), _list('/facilities')).wait;
    // the map coordinates are saved on the location, not on the facility
    final locationById = {for (final l in locations) l['location_id'] as String: l};
    return [
      for (final f in facilities)
        Facility.fromJson({
          'id': f['facility_id'],
          'location_id': f['location_id'],
          'name': f['name'],
          'latitude': _number(locationById[f['location_id']]?['latitude']),
          'longitude': _number(locationById[f['location_id']]?['longitude']),
        }),
    ];
  }

  @override
  Future<List<Floor>> getFloors() async {
    // the database has no floor level: the backend returns floors oldest first,
    // so the first floor of each facility is level 0 (ground), the next is 1, ...
    final rows = await _list('/floors');
    final nextLevel = <String, int>{};
    return [
      for (final r in rows)
        () {
          final facilityId = r['facility_id'] as String;
          final level = nextLevel[facilityId] ?? 0;
          nextLevel[facilityId] = level + 1;
          return Floor.fromJson({
            'id': r['floor_id'],
            'facility_id': facilityId,
            'name': r['name'],
            'level': level,
          });
        }(),
    ];
  }

  @override
  Future<List<Zone>> getZones() async => [
        for (final r in await _list('/zones'))
          Zone.fromJson({'id': r['zone_id'], 'floor_id': r['floor_id'], 'name': r['name']}),
      ];

  @override
  Future<List<Spot>> getSpots() async {
    final rows = await _list('/spots');
    final now = DateTime.now().toIso8601String();
    return [
      for (final r in rows)
        () {
          // disabled spots are shown as unknown (they are also left out of the analytics)
          final enabled = r['is_enabled'] != false;
          final status = enabled ? (r['status'] as String? ?? 'unknown') : 'unknown';
          final known = status == 'free' || status == 'occupied';
          return Spot.fromJson({
            'id': r['spot_id'],
            'zone_id': r['zone_id'],
            'spot_code': r['spot_code'],
            'status': status.toUpperCase(),
            // status_updated_at = last real change (a car can be parked for hours).
            // The backend already turns silent sensors into "unknown" after 30 min,
            // so a known status is fresh now.
            'reported_at': known ? now : r['status_updated_at'],
          });
        }(),
    ];
  }

  // ---------- live analytics (Hajar's engine) ----------

  @override
  Future<LiveOccupancy?> getLiveOccupancy(String level, String id) async {
    try {
      final json = await _get('/analytics/live', {'level': level, 'id': id});
      return LiveOccupancy.fromJson(json as Map<String, dynamic>);
    } catch (e) {
      debugPrint('Live analytics failed for $level $id: $e');
      return null;   // the screen falls back to counting the spots itself
    }
  }

  // ---------- still local until the backend supports them ----------

  @override
  Future<void> signIn(String phone) => _local.signIn(phone);

  @override
  Future<void> signOut() => _local.signOut();

  @override
  Future<Profile?> getMyProfile() => _local.getMyProfile();

  @override
  Future<Profile> createMyProfile(String name) => _local.createMyProfile(name);

  @override
  Future<Profile> getCurrentUser() => _local.getCurrentUser();

  @override
  Future<List<ParkingSession>> getMyParkings() async {
    // keep only parkings on spots that exist in the real database
    final (sessions, spots) = await (_local.getMyParkings(), getSpots()).wait;
    final realSpots = {for (final s in spots) s.id};
    return sessions.where((p) => realSpots.contains(p.spotId)).toList();
  }

  @override
  Future<ParkingSession> startParking(String spotId) => _local.startParking(spotId);

  @override
  Future<void> endParking(String parkingId) => _local.endParking(parkingId);

  @override
  Listenable get parkingChanges => _local.parkingChanges;
}
