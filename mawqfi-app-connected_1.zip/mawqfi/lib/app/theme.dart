import 'package:flutter/material.dart';

/// Mawqfi design tokens, taken from Figma "Mawqfi — Pilot Prototype".
class AppColors {
  AppColors._();

  // Brand
  static const primary = Color(0xFF1E3A5F); // navy

  // Surfaces
  static const background = Color(0xFFF7F9FB);
  static const surface = Colors.white;
  static const surfaceMuted = Color(0xFFF3F4F6); // progress track, offline banner
  static const border = Color(0xFFE5E7EB);

  // Text
  static const textPrimary = Color(0xFF111827);
  static const textSecondary = Color(0xFF6B7280);
  static const textMuted = Color(0xFF9CA3AF);

  // Spot / lot status
  // `available`, `occupied`, `unknownBorder` = Figma colors, use for borders,
  // dots, icons and progress bars (non-text, needs 3:1 contrast).
  // `*Text` = darker shades for TEXT on the light status backgrounds,
  // so badge labels pass WCAG AA (4.5:1). Figma values failed:
  // green 3.0:1, red 3.95:1, grey 4.39:1.
  static const available = Color(0xFF16A34A);
  static const availableText = Color(0xFF15803D); // 4.57:1 on availableBg
  static const availableBg = Color(0xFFDCFCE7);

  static const occupied = Color(0xFFDC2626);
  static const occupiedText = Color(0xFFB91C1C); // 5.3:1 on occupiedBg
  static const occupiedBg = Color(0xFFFEE2E2);

  static const unknown = Color(0xFF6B7280);
  static const unknownText = Color(0xFF4B5563); // 6.87:1 on unknownBg
  static const unknownBorder = Color(0xFF9CA3AF);
  static const unknownBg = Color(0xFFF3F4F6);

  // Alerts
  static const warning = Color(0xFF92400E); // 6.37:1 on warningBg, already passes
  static const warningBg = Color(0xFFFEF3C7);

  // Disabled
  static const disabledBg = Color(0xFFE5E7EB);
  static const disabledText = Color(0xFF9CA3AF);
}

class AppRadius {
  AppRadius._();
  static const tile = 10.0; // spot tiles, banners
  static const button = 12.0; // buttons, search field
  static const card = 14.0; // lot cards
  static const pill = 999.0; // status badges
}

class AppTheme {
  AppTheme._();

  static const fontFamily = 'Cairo';

  static final _textTheme = const TextTheme(
    headlineSmall: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.textPrimary), // greeting
    titleMedium: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.textPrimary), // card title
    titleSmall: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary), // section heading
    bodyLarge: TextStyle(fontSize: 15, fontWeight: FontWeight.w400, color: AppColors.textPrimary), // inputs
    bodyMedium: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: AppColors.textSecondary), // subtitles
    bodySmall: TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: AppColors.textSecondary), // card meta
    labelLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.w700), // buttons
    labelMedium: TextStyle(fontSize: 12, fontWeight: FontWeight.w600), // badges, banners
    labelSmall: TextStyle(fontSize: 11, fontWeight: FontWeight.w400, color: AppColors.textMuted), // tab labels, footnotes
  ).apply(fontFamily: fontFamily);

  static ThemeData get light => ThemeData(
        useMaterial3: true,
        fontFamily: fontFamily,
        textTheme: _textTheme,
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: const ColorScheme.light(
          primary: AppColors.primary,
          onPrimary: Colors.white,
          surface: AppColors.surface,
          onSurface: AppColors.textPrimary,
          error: AppColors.occupied,
          outline: AppColors.border,
        ),

        // Primary button: navy, 52 tall, radius 12
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
            disabledBackgroundColor: AppColors.disabledBg,
            disabledForegroundColor: AppColors.disabledText,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.button)),
            textStyle: _textTheme.labelLarge,
          ),
        ),

        // Secondary button: white with navy 1.5 border
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            backgroundColor: Colors.white,
            foregroundColor: AppColors.primary,
            minimumSize: const Size.fromHeight(52),
            side: const BorderSide(color: AppColors.primary, width: 1.5),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.button)),
            textStyle: _textTheme.labelLarge,
          ),
        ),

        // Search field: white, grey border, radius 12, height 48
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          hintStyle: _textTheme.bodyLarge?.copyWith(color: AppColors.textMuted),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(AppRadius.button),
            borderSide: const BorderSide(color: AppColors.border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(AppRadius.button),
            borderSide: const BorderSide(color: AppColors.border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(AppRadius.button),
            borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
          ),
        ),

        // Lot cards: white, 1px border, radius 14, no shadow
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.card),
            side: const BorderSide(color: AppColors.border),
          ),
        ),

        // Bottom tabs: active = navy bold, inactive = grey regular
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Colors.white,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          selectedItemColor: AppColors.primary,
          unselectedItemColor: AppColors.textMuted,
          selectedLabelStyle: TextStyle(fontFamily: fontFamily, fontSize: 11, fontWeight: FontWeight.w700),
          unselectedLabelStyle: TextStyle(fontFamily: fontFamily, fontSize: 11, fontWeight: FontWeight.w400),
        ),

        dividerTheme: const DividerThemeData(color: AppColors.border, thickness: 1, space: 1),
      );
}
