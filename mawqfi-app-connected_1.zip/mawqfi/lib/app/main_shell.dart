import 'package:flutter/material.dart';

import '../ui/history/history_screen.dart';
import '../ui/home/home_screen.dart';
import '../ui/my_parking/my_parking_screen.dart';
import '../ui/profile/profile_screen.dart';
import 'theme.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  static final tab = ValueNotifier<int>(0);

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int get _index => MainShell.tab.value;

  @override
  void initState() {
    super.initState();
    MainShell.tab.addListener(_onTabChanged);
  }

  @override
  void dispose() {
    MainShell.tab.removeListener(_onTabChanged);
    super.dispose();
  }

  void _onTabChanged() => setState(() {});

  static const _tabs = <Widget>[
    HomeScreen(),
    MyParkingScreen(),
    HistoryScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(index: _index, children: _tabs),
        bottomNavigationBar: DecoratedBox(
          decoration: const BoxDecoration(
            border: Border(top: BorderSide(color: AppColors.border)),
          ),
          child: BottomNavigationBar(
            currentIndex: _index,
            onTap: (i) => MainShell.tab.value = i,
            iconSize: 24,
            items: const [
              BottomNavigationBarItem(icon: Icon(Icons.explore_outlined), label: 'استكشاف'),
              BottomNavigationBarItem(icon: Icon(Icons.local_parking_rounded), label: 'موقفي'),
              BottomNavigationBarItem(icon: Icon(Icons.schedule_rounded), label: 'السجل'),
              BottomNavigationBarItem(icon: Icon(Icons.person_outline_rounded), label: 'حسابي'),
            ],
          ),
        ),
      ),
    );
  }
}
