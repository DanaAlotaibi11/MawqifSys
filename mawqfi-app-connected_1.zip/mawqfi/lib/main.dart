import 'package:flutter/material.dart';
import 'package:mawqfi_mvp_v1/app/theme.dart';
import 'package:mawqfi_mvp_v1/ui/home/home_screen.dart';
import 'package:mawqfi_mvp_v1/ui/splash/splash_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: const SplashScreen(),
    );
  }
}
